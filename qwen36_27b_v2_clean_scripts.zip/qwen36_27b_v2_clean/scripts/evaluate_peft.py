#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Evaluate base model + LoRA adapter directly with Transformers/PEFT.

This avoids:
1. vLLM environment compatibility issues.
2. Creating / using a full merged 27B model.
3. Modifying the original base model.

Outputs:
- predictions JSONL
- metrics JSON
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any, Dict, List

import torch
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from peft import PeftModel

from metrics_utils import (
    compute_metrics_from_records,
    extract_dataset_from_row,
    extract_json_object,
    get_gold_from_sft_row,
    get_prompt_messages,
    schema_valid,
)


def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                raise ValueError(f"Invalid JSONL at {path}, line {i}: {e}") from e
    return rows


def write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def get_gpu_count_from_visible() -> int:
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "").strip()
    if visible:
        return len([x for x in visible.split(",") if x.strip()])
    return torch.cuda.device_count()



def make_eval_prompt_messages(row):
    """
    Use the original SFT prompt, but strengthen the system instruction for evaluation.
    The goal is to prevent reasoning text and force a single compact JSON object.
    """
    messages = get_prompt_messages(row)
    strict = (
        "You are a strict annotation engine. "
        "Return ONLY one valid compact JSON object. "
        "Do not explain. Do not think step by step. Do not repeat the schema. "
        "Do not output markdown. The first character must be { and the last character must be }."
    )

    if messages and messages[0].get("role") == "system":
        messages = [dict(messages[0])] + [dict(x) for x in messages[1:]]
        messages[0]["content"] = str(messages[0].get("content", "")) + "\n\n" + strict
    else:
        messages = [{"role": "system", "content": strict}] + [dict(x) for x in messages]

    return messages


def apply_chat_template_eval(tokenizer, messages):
    """
    Qwen-style tokenizers may support enable_thinking=False.
    If unsupported, fall back safely.
    """
    try:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
    except TypeError:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base_model", type=Path, required=True)
    parser.add_argument("--adapter", type=Path, required=True)
    parser.add_argument("--test_file", type=Path, required=True)
    parser.add_argument("--output_predictions", type=Path, required=True)
    parser.add_argument("--output_metrics", type=Path, required=True)

    parser.add_argument("--max_model_len", type=int, default=2048)
    parser.add_argument("--max_new_tokens", type=int, default=128)
    parser.add_argument("--batch_size", type=int, default=8)

    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--do_sample", action="store_true")
    parser.add_argument("--trust_remote_code", action="store_true")

    parser.add_argument("--load_in_4bit", action="store_true")
    parser.add_argument("--max_memory_per_gpu", type=str, default="40GiB")
    parser.add_argument("--cpu_memory", type=str, default="120GiB")
    parser.add_argument("--offload_folder", type=Path, default=None)

    parser.add_argument("--limit", type=int, default=None, help="Debug only: evaluate first N samples.")
    args = parser.parse_args()

    args.output_predictions.parent.mkdir(parents=True, exist_ok=True)
    args.output_metrics.parent.mkdir(parents=True, exist_ok=True)

    print("[INFO] base_model:", args.base_model)
    print("[INFO] adapter:", args.adapter)
    print("[INFO] test_file:", args.test_file)
    print("[INFO] output_predictions:", args.output_predictions)
    print("[INFO] output_metrics:", args.output_metrics)
    print("[INFO] load_in_4bit:", args.load_in_4bit)
    print("[INFO] CUDA_VISIBLE_DEVICES:", os.environ.get("CUDA_VISIBLE_DEVICES"))

    if not (args.adapter / "adapter_config.json").exists():
        raise FileNotFoundError(f"Missing adapter_config.json in {args.adapter}")
    if not (args.adapter / "adapter_model.safetensors").exists():
        raise FileNotFoundError(f"Missing adapter_model.safetensors in {args.adapter}")

    rows = read_jsonl(args.test_file)
    if args.limit is not None:
        rows = rows[: args.limit]
    print("[INFO] test rows:", len(rows))

    tokenizer = AutoTokenizer.from_pretrained(
        args.base_model,
        trust_remote_code=args.trust_remote_code,
        use_fast=True,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "left"

    n_gpu = get_gpu_count_from_visible()
    max_memory = None
    if torch.cuda.is_available() and n_gpu > 0:
        max_memory = {i: args.max_memory_per_gpu for i in range(n_gpu)}
        max_memory["cpu"] = args.cpu_memory

    model_kwargs: Dict[str, Any] = {
        "trust_remote_code": args.trust_remote_code,
        "torch_dtype": torch.bfloat16,
        "device_map": "auto",
        "max_memory": max_memory,
        "low_cpu_mem_usage": True,
    }

    if args.offload_folder is not None:
        args.offload_folder.mkdir(parents=True, exist_ok=True)
        model_kwargs["offload_folder"] = str(args.offload_folder)
        model_kwargs["offload_state_dict"] = True

    if args.load_in_4bit:
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
        )
        model_kwargs["quantization_config"] = bnb_config

    print("[INFO] Loading base model...")
    base = AutoModelForCausalLM.from_pretrained(args.base_model, **model_kwargs)

    print("[INFO] Loading LoRA adapter...")
    model = PeftModel.from_pretrained(base, args.adapter)
    model.eval()

    if hasattr(model, "hf_device_map"):
        print("[INFO] hf_device_map sample:", list(model.hf_device_map.items())[:10])

    prompts: List[str] = []
    metadata: List[Dict[str, Any]] = []

    for idx, row in enumerate(rows):
        prompt_messages = make_eval_prompt_messages(row)
        prompt = apply_chat_template_eval(tokenizer, prompt_messages)
        prompts.append(prompt)

        gold = get_gold_from_sft_row(row)
        dataset = extract_dataset_from_row(row)
        metadata.append({"index": idx, "dataset": dataset, "gold": gold})

    records: List[Dict[str, Any]] = []

    # With device_map="auto", send input tensors to the model's first execution device.
    # For quantized/dispatched models this is usually safe.
    input_device = next(model.parameters()).device
    print("[INFO] input_device:", input_device)

    gen_kwargs: Dict[str, Any] = {
        "max_new_tokens": args.max_new_tokens,
        "pad_token_id": tokenizer.pad_token_id,
        "eos_token_id": tokenizer.eos_token_id,
    }
    if args.do_sample:
        gen_kwargs["do_sample"] = True
        gen_kwargs["temperature"] = args.temperature
    else:
        gen_kwargs["do_sample"] = False

    for start in tqdm(range(0, len(prompts), args.batch_size), desc="PEFT generate"):
        batch_prompts = prompts[start : start + args.batch_size]
        batch_meta = metadata[start : start + args.batch_size]

        encoded = tokenizer(
            batch_prompts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=args.max_model_len,
        )

        input_ids = encoded["input_ids"].to(input_device)
        attention_mask = encoded["attention_mask"].to(input_device)
        prompt_lens = attention_mask.sum(dim=1).tolist()

        with torch.inference_mode():
            outputs = model.generate(
                input_ids=input_ids,
                attention_mask=attention_mask,
                **gen_kwargs,
            )

        for i, output_ids in enumerate(outputs):
            # Because we use left padding, generated text starts after full input length,
            # not after prompt_lens[i].
            gen_ids = output_ids[input_ids.shape[1] :]
            pred_text = tokenizer.decode(gen_ids, skip_special_tokens=True).strip()

            meta = batch_meta[i]
            pred_obj, parse_status = extract_json_object(pred_text)
            valid = schema_valid(meta["dataset"], pred_obj)

            records.append(
                {
                    "index": meta["index"],
                    "dataset": meta["dataset"],
                    "gold": meta["gold"],
                    "prediction_text": pred_text,
                    "pred_obj": pred_obj,
                    "parse_status": parse_status,
                    "schema_valid": valid,
                }
            )

        # Incremental save, so progress is not lost if interrupted.
        write_jsonl(args.output_predictions, records)

    metrics = compute_metrics_from_records(records)
    args.output_metrics.write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print("[DONE] predictions:", args.output_predictions)
    print("[DONE] metrics:", args.output_metrics)
    print(json.dumps(metrics["global"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
