#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Clean QLoRA SFT trainer for Qwen-style chat JSONL.

Input JSONL rows must contain:
  {"messages": [{"role":"system"...}, {"role":"user"...}, {"role":"assistant"...}], ...metadata}

Only assistant tokens contribute to loss. Metadata never enters the model unless it is inside messages.
Default path is Accelerate DDP + 4-bit QLoRA. DeepSpeed is optional and disabled by default.
"""
from __future__ import annotations

import argparse
import inspect
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

import torch
from torch.utils.data import Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, Trainer, TrainingArguments, set_seed
from peft import LoraConfig, TaskType, get_peft_model, prepare_model_for_kbit_training


def encode_ids(tokenizer: Any, text: str) -> List[int]:
    out = tokenizer(text, add_special_tokens=False, truncation=False, padding=False, return_attention_mask=False)
    ids = out["input_ids"]
    if ids and isinstance(ids[0], list):
        ids = ids[0]
    return [int(x) for x in ids]


def render_chat(tokenizer: Any, messages: List[Dict[str, str]], add_generation_prompt: bool) -> str:
    try:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=add_generation_prompt,
            enable_thinking=False,
        )
    except TypeError:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=add_generation_prompt,
        )


class ChatSFTDataset(Dataset):
    def __init__(self, jsonl_path: Path, tokenizer: Any, max_seq_length: int):
        self.path = Path(jsonl_path)
        self.tokenizer = tokenizer
        self.max_seq_length = int(max_seq_length)
        self.rows = self._load_jsonl(self.path)

    @staticmethod
    def _load_jsonl(path: Path) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        with path.open("r", encoding="utf-8") as f:
            for i, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except Exception as e:
                    raise ValueError(f"Invalid JSONL at {path}, line {i}: {e}") from e
        if not rows:
            raise ValueError(f"No rows loaded from {path}")
        return rows

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        row = self.rows[idx]
        messages = row.get("messages")
        if not isinstance(messages, list) or len(messages) < 3 or messages[-1].get("role") != "assistant":
            raise ValueError(f"Row {idx} must contain messages ending with an assistant message")

        prompt_messages = messages[:-1]
        target_text = str(messages[-1].get("content", ""))

        prompt_text = render_chat(self.tokenizer, prompt_messages, add_generation_prompt=True)
        eos = self.tokenizer.eos_token or ""
        full_text = prompt_text + target_text + eos

        prompt_ids = encode_ids(self.tokenizer, prompt_text)
        full_ids = encode_ids(self.tokenizer, full_text)

        input_ids = full_ids[: self.max_seq_length]
        prompt_len = min(len(prompt_ids), len(input_ids))
        labels = [-100] * prompt_len + input_ids[prompt_len:]
        labels = labels[: len(input_ids)]

        if all(x == -100 for x in labels) and input_ids:
            labels[-1] = input_ids[-1]

        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.ones(len(input_ids), dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }


@dataclass
class CausalLMCollator:
    tokenizer: Any
    pad_to_multiple_of: int = 8

    def __call__(self, features: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        max_len = max(x["input_ids"].shape[0] for x in features)
        if self.pad_to_multiple_of:
            max_len = ((max_len + self.pad_to_multiple_of - 1) // self.pad_to_multiple_of) * self.pad_to_multiple_of

        pad_id = self.tokenizer.pad_token_id
        batch = {"input_ids": [], "attention_mask": [], "labels": []}
        for feat in features:
            n = feat["input_ids"].shape[0]
            pad = max_len - n
            batch["input_ids"].append(torch.cat([feat["input_ids"], torch.full((pad,), pad_id, dtype=torch.long)]))
            batch["attention_mask"].append(torch.cat([feat["attention_mask"], torch.zeros(pad, dtype=torch.long)]))
            batch["labels"].append(torch.cat([feat["labels"], torch.full((pad,), -100, dtype=torch.long)]))
        return {k: torch.stack(v, dim=0) for k, v in batch.items()}


def compatible_training_args(**kwargs: Any) -> TrainingArguments:
    valid = set(inspect.signature(TrainingArguments.__init__).parameters.keys())
    if "evaluation_strategy" in kwargs and "evaluation_strategy" not in valid and "eval_strategy" in valid:
        kwargs["eval_strategy"] = kwargs.pop("evaluation_strategy")
    elif "eval_strategy" in kwargs and "eval_strategy" not in valid and "evaluation_strategy" in valid:
        kwargs["evaluation_strategy"] = kwargs.pop("eval_strategy")
    filtered = {k: v for k, v in kwargs.items() if k in valid}
    dropped = sorted(set(kwargs) - set(filtered))
    if dropped:
        print(f"[WARN] Dropped unsupported TrainingArguments keys: {dropped}", flush=True)
    return TrainingArguments(**filtered)


def compatible_trainer(**kwargs: Any) -> Trainer:
    valid = set(inspect.signature(Trainer.__init__).parameters.keys())
    if "tokenizer" in kwargs and "tokenizer" not in valid and "processing_class" in valid:
        kwargs["processing_class"] = kwargs.pop("tokenizer")
    filtered = {k: v for k, v in kwargs.items() if k in valid}
    dropped = sorted(set(kwargs) - set(filtered))
    if dropped:
        print(f"[WARN] Dropped unsupported Trainer keys: {dropped}", flush=True)
    return Trainer(**filtered)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--model_name_or_path", type=Path, required=True)
    p.add_argument("--train_file", type=Path, required=True)
    p.add_argument("--validation_file", type=Path, required=True)
    p.add_argument("--output_dir", type=Path, required=True)
    p.add_argument("--max_seq_length", type=int, default=1024)
    p.add_argument("--num_train_epochs", type=float, default=3.0)
    p.add_argument("--per_device_train_batch_size", type=int, default=1)
    p.add_argument("--per_device_eval_batch_size", type=int, default=1)
    p.add_argument("--gradient_accumulation_steps", type=int, default=8)
    p.add_argument("--learning_rate", type=float, default=1e-5)
    p.add_argument("--warmup_ratio", type=float, default=0.03)
    p.add_argument("--weight_decay", type=float, default=0.01)
    p.add_argument("--lora_rank", type=int, default=16)
    p.add_argument("--lora_alpha", type=int, default=32)
    p.add_argument("--lora_dropout", type=float, default=0.05)
    p.add_argument("--target_modules", type=str, default="q_proj,k_proj,v_proj,o_proj")
    p.add_argument("--eval_steps", type=int, default=200)
    p.add_argument("--save_steps", type=int, default=200)
    p.add_argument("--logging_steps", type=int, default=10)
    p.add_argument("--save_total_limit", type=int, default=3)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--gradient_checkpointing", action="store_true")
    p.add_argument("--trust_remote_code", action="store_true")
    p.add_argument("--deepspeed", type=Path, default=None, help="Optional. Leave unset for stable QLoRA DDP.")
    p.add_argument("--attn_implementation", type=str, default="auto", choices=["auto", "flash_attention_2", "sdpa", "eager"])
    return p.parse_args()


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    if torch.cuda.is_available():
        torch.cuda.set_device(local_rank)
    if int(os.environ.get("RANK", "0")) == 0:
        print(f"[DIST] WORLD_SIZE={world_size} LOCAL_RANK={local_rank} CUDA_VISIBLE_DEVICES={os.environ.get('CUDA_VISIBLE_DEVICES')}", flush=True)

    tokenizer = AutoTokenizer.from_pretrained(args.model_name_or_path, trust_remote_code=args.trust_remote_code, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
    )
    model_kwargs: Dict[str, Any] = {
        "trust_remote_code": args.trust_remote_code,
        "dtype": torch.bfloat16,
        "low_cpu_mem_usage": True,
        "quantization_config": bnb_config,
        "device_map": {"": local_rank} if torch.cuda.is_available() else None,
    }
    if model_kwargs["device_map"] is None:
        del model_kwargs["device_map"]

    if args.attn_implementation != "auto":
        model_kwargs["attn_implementation"] = args.attn_implementation
        model = AutoModelForCausalLM.from_pretrained(args.model_name_or_path, **model_kwargs)
    else:
        try:
            model = AutoModelForCausalLM.from_pretrained(args.model_name_or_path, attn_implementation="flash_attention_2", **model_kwargs)
            print("[INFO] Loaded model with flash_attention_2", flush=True)
        except Exception as e:
            print(f"[WARN] flash_attention_2 unavailable; falling back. Reason: {e}", flush=True)
            model = AutoModelForCausalLM.from_pretrained(args.model_name_or_path, **model_kwargs)

    model.config.use_cache = False
    if args.gradient_checkpointing:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})

    model = prepare_model_for_kbit_training(model)
    target_modules = [x.strip() for x in args.target_modules.split(",") if x.strip()]
    lora_config = LoraConfig(
        r=args.lora_rank,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        target_modules=target_modules,
        bias="none",
        task_type=TaskType.CAUSAL_LM,
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    train_dataset = ChatSFTDataset(args.train_file, tokenizer, args.max_seq_length)
    eval_dataset = ChatSFTDataset(args.validation_file, tokenizer, args.max_seq_length)
    collator = CausalLMCollator(tokenizer)

    training_args = compatible_training_args(
        output_dir=str(args.output_dir),
        overwrite_output_dir=True,
        num_train_epochs=args.num_train_epochs,
        per_device_train_batch_size=args.per_device_train_batch_size,
        per_device_eval_batch_size=args.per_device_eval_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        learning_rate=args.learning_rate,
        warmup_ratio=args.warmup_ratio,
        weight_decay=args.weight_decay,
        bf16=True,
        fp16=False,
        logging_steps=args.logging_steps,
        evaluation_strategy="steps",
        eval_steps=args.eval_steps,
        save_strategy="steps",
        save_steps=args.save_steps,
        save_total_limit=args.save_total_limit,
        load_best_model_at_end=False,
        gradient_checkpointing=args.gradient_checkpointing,
        remove_unused_columns=False,
        report_to="none",
        optim="adamw_torch",
        lr_scheduler_type="cosine",
        max_grad_norm=1.0,
        dataloader_num_workers=2,
        ddp_find_unused_parameters=False,
        **({"deepspeed": str(args.deepspeed)} if args.deepspeed is not None else {}),
    )

    manifest = vars(args).copy()
    manifest.update({
        "world_size": world_size,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "effective_batch_size": world_size * args.per_device_train_batch_size * args.gradient_accumulation_steps,
        "target_modules_list": target_modules,
        "training_mode": "QLoRA 4-bit + Accelerate DDP" if args.deepspeed is None else "QLoRA 4-bit + DeepSpeed",
    })
    for k, v in list(manifest.items()):
        if isinstance(v, Path):
            manifest[k] = str(v)
    (args.output_dir / "training_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    trainer = compatible_trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        data_collator=collator,
        tokenizer=tokenizer,
    )
    trainer.train()

    final_adapter_dir = args.output_dir / "final_adapter"
    final_adapter_dir.mkdir(parents=True, exist_ok=True)
    trainer.model.save_pretrained(final_adapter_dir)
    tokenizer.save_pretrained(final_adapter_dir)
    print(f"[DONE] Saved LoRA adapter to: {final_adapter_dir}", flush=True)


if __name__ == "__main__":
    main()
