#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List

from transformers import AutoTokenizer


def read_jsonl(path: Path):
    with path.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if line.strip():
                row = json.loads(line)
                yield i, row


def render_chat(tokenizer: Any, messages: List[Dict[str, str]], add_generation_prompt: bool = False) -> str:
    try:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=add_generation_prompt,
            enable_thinking=False,
        )
    except TypeError:
        return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=add_generation_prompt)


def count_tokens(tokenizer: Any, text: str) -> int:
    out = tokenizer(text, add_special_tokens=False, return_attention_mask=False, return_token_type_ids=False)
    ids = out["input_ids"]
    if ids and isinstance(ids[0], list):
        ids = ids[0]
    return len(ids)


def percentile(xs: List[int], p: float):
    if not xs:
        return None
    xs = sorted(xs)
    k = (len(xs) - 1) * p / 100
    lo = int(k)
    hi = min(lo + 1, len(xs) - 1)
    if lo == hi:
        return xs[lo]
    return round(xs[lo] * (hi - k) + xs[hi] * (k - lo), 2)


def summarize(xs: List[int]) -> Dict[str, Any]:
    thresholds = [512, 1024, 1536, 2048, 3072, 4096]
    return {
        "n": len(xs),
        "mean": round(statistics.mean(xs), 2) if xs else None,
        "median": percentile(xs, 50),
        "p75": percentile(xs, 75),
        "p90": percentile(xs, 90),
        "p95": percentile(xs, 95),
        "p99": percentile(xs, 99),
        "max": max(xs) if xs else None,
        **{f"over_{t}": sum(x > t for x in xs) for t in thresholds},
        **{f"over_{t}_ratio": round(sum(x > t for x in xs) / len(xs), 6) if xs else None for t in thresholds},
    }


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--model", type=Path, required=True)
    p.add_argument("--files", type=Path, nargs="+", required=True)
    p.add_argument("--output_json", type=Path, required=True)
    p.add_argument("--output_csv", type=Path, required=True)
    p.add_argument("--trust_remote_code", action="store_true")
    args = p.parse_args()

    tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=args.trust_remote_code, use_fast=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token

    rows = []
    by_dataset = defaultdict(list)
    by_file = defaultdict(list)

    for fp in args.files:
        print(f"[INFO] reading {fp}", flush=True)
        for idx, row in read_jsonl(fp):
            messages = row["messages"]
            prompt_len = count_tokens(tok, render_chat(tok, messages[:-1], add_generation_prompt=True))
            full_len = count_tokens(tok, render_chat(tok, messages, add_generation_prompt=False))
            item = {
                "file": fp.name,
                "index": idx,
                "dataset": row.get("dataset", "UNKNOWN"),
                "prompt_len": prompt_len,
                "answer_len": max(0, full_len - prompt_len),
                "full_len": full_len,
            }
            rows.append(item)
            by_dataset[item["dataset"]].append(full_len)
            by_file[item["file"]].append(full_len)
            if len(rows) <= 3:
                print("[DEBUG]", item, flush=True)

    stats = {
        "model": str(args.model),
        "files": [str(x) for x in args.files],
        "overall": summarize([r["full_len"] for r in rows]),
        "by_file": {k: summarize(v) for k, v in sorted(by_file.items())},
        "by_dataset": {k: summarize(v) for k, v in sorted(by_dataset.items())},
        "top_50_longest": sorted(rows, key=lambda x: x["full_len"], reverse=True)[:50],
    }

    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", encoding="utf-8") as f:
        f.write("file,index,dataset,prompt_len,answer_len,full_len\n")
        for r in rows:
            f.write(f'{r["file"]},{r["index"]},{r["dataset"]},{r["prompt_len"]},{r["answer_len"]},{r["full_len"]}\n')

    print("[DONE]", args.output_json)
    print(json.dumps(stats["overall"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
