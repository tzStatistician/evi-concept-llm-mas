#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from pathlib import Path

from vllm import LLM, SamplingParams
from vllm.lora.request import LoRARequest
from transformers import AutoTokenizer


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--base_model",
        type=str,
        default="/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.6-27B",
        help="Path to the base Qwen model.",
    )
    parser.add_argument(
        "--adapter",
        type=str,
        default="/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.6-27B-concept-sft-human6gpu-lora/adapter",
        help="Path to the LoRA adapter folder.",
    )
    parser.add_argument(
        "--prompt",
        type=str,
        required=True,
        help="Prompt text to run inference on.",
    )
    parser.add_argument(
        "--tp_size",
        type=int,
        default=8,
        help="Tensor parallel size.",
    )
    parser.add_argument(
        "--max_model_len",
        type=int,
        default=2048,
    )
    parser.add_argument(
        "--max_tokens",
        type=int,
        default=128,
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.0,
    )
    parser.add_argument(
        "--gpu_memory_utilization",
        type=float,
        default=0.70,
        help="vLLM GPU memory utilization.",
    )
    parser.add_argument(
        "--disable_custom_all_reduce",
        action="store_true",
        help="Disable vLLM custom all-reduce.",
    )
    parser.add_argument(
        "--enforce_eager",
        action="store_true",
        help="Disable CUDA graph capture.",
    )
    parser.add_argument(
        "--lora_name",
        type=str,
        default="concept_sft",
    )
    parser.add_argument(
        "--lora_int_id",
        type=int,
        default=1,
    )

    args = parser.parse_args()

    base_model = Path(args.base_model)
    adapter = Path(args.adapter)

    if not base_model.exists():
        raise FileNotFoundError(f"Base model not found: {base_model}")

    if not adapter.exists():
        raise FileNotFoundError(f"Adapter not found: {adapter}")

    if not (adapter / "adapter_config.json").exists():
        raise FileNotFoundError(f"Missing adapter_config.json in: {adapter}")

    if not (adapter / "adapter_model.safetensors").exists():
        raise FileNotFoundError(f"Missing adapter_model.safetensors in: {adapter}")

    print("[INFO] Base model:", base_model)
    print("[INFO] LoRA adapter:", adapter)
    print("[INFO] Tensor parallel size:", args.tp_size)

    llm = LLM(
        model=str(base_model),
        enable_lora=True,
        max_lora_rank=16,
        tensor_parallel_size=args.tp_size,
        trust_remote_code=True,
        dtype="bfloat16",
        max_model_len=args.max_model_len,
        gpu_memory_utilization=args.gpu_memory_utilization,
        disable_custom_all_reduce=args.disable_custom_all_reduce,
        enforce_eager=args.enforce_eager,
    )

    sampling_params = SamplingParams(
        temperature=args.temperature,
        max_tokens=args.max_tokens,
    )

    tokenizer = AutoTokenizer.from_pretrained(
        str(base_model),
        trust_remote_code=True,
        use_fast=True,
    )

    messages = [
        {
            "role": "system",
            "content": (
                "You are a strict annotation engine. "
                "Return ONLY one valid compact JSON object. "
                "Do not explain. Do not think step by step. "
                "Do not output markdown."
            ),
        },
        {
            "role": "user",
            "content": args.prompt,
        },
    ]

    try:
        rendered_prompt = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
    except TypeError:
        rendered_prompt = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )

    outputs = llm.generate(
        [rendered_prompt],
        sampling_params,
        lora_request=LoRARequest(
            args.lora_name,
            args.lora_int_id,
            str(adapter),
        ),
    )

    print("\n========== MODEL OUTPUT ==========")
    print(outputs[0].outputs[0].text.strip())


if __name__ == "__main__":
    main()
