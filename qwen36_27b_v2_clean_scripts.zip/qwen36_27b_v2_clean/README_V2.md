# Qwen3.6-27B Concept SFT LoRA v2 clean scripts

This package reorganizes the v2 SFT workflow around clean prompts, metadata outside the prompt, 4-GPU QLoRA training, and 4-way PEFT evaluation.

Default hardware assumption:

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3
```

## Workflow

1. Create v2 SFT data from raw downloaded datasets.
2. Audit token lengths.
3. Build balanced train/validation data with GoEmotions capped at 20k and overlength training rows removed.
4. Train 4-GPU QLoRA without DeepSpeed by default.
5. Evaluate PEFT in 4 parallel shards.
6. Package final LoRA adapter.

## Main scripts

- `scripts/prepare_sft_data_v2.py`
- `scripts/token_length_audit.py`
- `scripts/build_balanced_train_val.py`
- `scripts/train_qlora.py`
- `scripts/evaluate_peft.py`
- `scripts/metrics_utils.py`
- `scripts/run_token_length_audit_v2.sh`
- `scripts/run_build_balanced_v2.sh`
- `scripts/run_train_v2_4gpu.sh`
- `scripts/run_eval_peft_v2_4gpu_parallel.sh`

## Typical commands

```bash
conda activate sft
cd /mnt/disk1/wbjtu/tzbjtu/somental/qwen36_27b_concept_sft_project

# Copy scripts from this package into the project first.

python scripts/prepare_sft_data_v2.py \
  --base_dir /mnt/disk1/wbjtu/tzbjtu/somental/data/finetune \
  --output_dir /mnt/disk1/wbjtu/tzbjtu/somental/data/finetune/qwen_sft_merged_v2 \
  --test_ratio 0.1 \
  --seed 42 \
  --save_normalized \
  --preview 2

bash scripts/run_token_length_audit_v2.sh
bash scripts/run_build_balanced_v2.sh

CUDA_VISIBLE_DEVICES=0,1,2,3 bash scripts/run_train_v2_4gpu.sh

CUDA_VISIBLE_DEVICES=0,1,2,3 bash scripts/run_eval_peft_v2_4gpu_parallel.sh
```

## Important design choices

- Dataset name, paper title, and source metadata are not included in the model prompt.
- Top-level metadata is preserved in JSONL for evaluation/debugging.
- CAMS labels are normalized to `"0.0"` through `"5.0"` during data preparation.
- DepressionEmo remains excluded.
- WellnessDimensions GPT/ChatGPT-augmented files remain excluded.
- DeepSpeed is disabled by default. The default training path is 4-bit QLoRA + Accelerate DDP.
