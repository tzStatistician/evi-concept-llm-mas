# Qwen3.6-27B Mental-Health Concept SFT Project

This project fine-tunes a local Qwen3.6-27B model with bf16 LoRA on 8×L20 GPUs, evaluates on the aggregated test set, and saves a merged vLLM-ready model.

## Paths used by default

```text
Project folder:
  /mnt/disk1/wbjtu/tzbjtu/somental/qwen36_27b_concept_sft_project

Base model:
  /mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.6-27B

Existing aggregated SFT data source:
  /mnt/disk1/wbjtu/tzbjtu/somental/data/finetune/qwen_sft_merged
```

All newly created data copies, adapters, merged model files, predictions, metrics, and logs are saved inside the project folder.

## Workflow

### 0. Copy/unzip this project into the server project root

```bash
cd /mnt/disk1/wbjtu/tzbjtu/somental
unzip qwen36_27b_concept_sft_project.zip
cd qwen36_27b_concept_sft_project
```

### 1. Prepare train/validation files inside the project folder

This copies `aggregated_train.jsonl` and `aggregated_test.jsonl` into `PROJECT_DIR/data/`, then splits `aggregated_train.jsonl` into:

```text
data/train_for_sft.jsonl
data/val_for_epoch_select.jsonl
```

Run:

```bash
bash scripts/run_prepare_train_val.sh
```

### 2. Train bf16 LoRA on 8 L20 GPUs

Run:

```bash
bash scripts/run_train_lora.sh
```

Default LoRA setup:

```text
LoRA rank: 16
LoRA alpha: 32
LoRA dropout: 0.05
Target modules: q_proj,k_proj,v_proj,o_proj
Max sequence length: 1024
Epochs: 3
Effective batch size: 8 GPUs × 1 per GPU × 4 accumulation = 32
```

Expected adapter output:

```text
outputs/adapter/qwen36_27b_lora_r16_attn/final_adapter/
```

### 3. Merge LoRA adapter into the base model

Run:

```bash
bash scripts/run_merge_lora.sh
```

Expected merged model output:

```text
outputs/merged/qwen36_27b_concept_sft_merged/
```

Use this directory for vLLM inference.

### 4. Evaluate on the untouched test set with vLLM

Default uses 4 GPUs with tensor parallel size 4.

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 TP_SIZE=4 bash scripts/run_eval_vllm.sh
```

Outputs:

```text
outputs/predictions/test_predictions.jsonl
outputs/metrics/test_metrics.json
outputs/logs/eval_vllm.log
```

Metrics include:

```text
Global:
  json_parse_rate
  schema_valid_rate
  parse_status_counts
  dataset_counts

Per dataset:
  CAMS: category metrics + interpretation exact/token-F1
  LoST: binary accuracy/macro-F1/per-label F1
  LonXplain: binary metrics + evidence-span exact/token-F1
  MultiWD: multilabel micro/macro-F1, subset accuracy, Hamming loss
  SAD: is_stressor metrics + stress_label metrics
  GoEmotions: multilabel metrics
  DepressionEmo: multilabel metrics
```

### 5. Serve merged model with vLLM

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 TP_SIZE=4 PORT=8000 bash scripts/run_vllm_server.sh
```

For two parallel inference servers on 8 GPUs, use one server on `0,1,2,3` and another on `4,5,6,7` with different ports.

## Important notes

1. The final test file is not used for checkpoint or epoch selection.
2. Epoch selection is done with `data/val_for_epoch_select.jsonl` through validation loss during SFT.
3. The training target masks system/user tokens and trains only on assistant JSON outputs.
4. The project defaults to bf16 LoRA, not QLoRA.
5. The merged model directory is designed for vLLM. If merge is too memory-heavy, vLLM can also serve LoRA adapters separately, but this project prioritizes a merged model for simpler downstream use.

## Sanity checks before training

```bash
python -m py_compile scripts/*.py
head -n 1 data/train_for_sft.jsonl | python -m json.tool
head -n 1 data/aggregated_test.jsonl | python -m json.tool
cat data/train_val_split_stats.json
```
