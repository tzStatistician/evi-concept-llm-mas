# Validation performed before packaging

Validated in the packaging environment:

1. Python syntax compilation passed for all Python scripts:
   - `scripts/prepare_train_val.py`
   - `scripts/train_lora.py`
   - `scripts/merge_lora.py`
   - `scripts/evaluate_vllm.py`
   - `scripts/metrics_utils.py`

2. Project paths are configured so new generated files are inside:
   - `/mnt/disk1/wbjtu/tzbjtu/somental/qwen36_27b_concept_sft_project/data`
   - `/mnt/disk1/wbjtu/tzbjtu/somental/qwen36_27b_concept_sft_project/outputs`

3. Training script uses bf16 LoRA and DeepSpeed ZeRO-3.

4. The training script creates `HfDeepSpeedConfig` before loading the 27B model so ZeRO-3 can partition parameters during initialization.

5. Evaluation script uses vLLM generation and computes JSON validity, schema validity, and dataset-specific metrics.

Not validated here because it requires your server/GPU environment:

1. Actual Qwen3.6-27B model loading.
2. Actual multi-GPU LoRA training.
3. Actual LoRA merge of the 27B model.
4. Actual vLLM inference speed/throughput.

Run the README commands on your server to validate the GPU path.
