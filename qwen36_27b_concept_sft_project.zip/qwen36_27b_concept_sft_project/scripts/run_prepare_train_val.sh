#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/qwen36_27b_concept_sft_project}"
AGG_DIR="${AGG_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/data/finetune/qwen_sft_merged}"

mkdir -p "${PROJECT_DIR}/data" "${PROJECT_DIR}/outputs/logs"

# Copy aggregated files into the project folder so code, data references, and outputs are project-local.
cp "${AGG_DIR}/aggregated_train.jsonl" "${PROJECT_DIR}/data/aggregated_train.jsonl"
cp "${AGG_DIR}/aggregated_test.jsonl" "${PROJECT_DIR}/data/aggregated_test.jsonl"
if [[ -f "${AGG_DIR}/dataset_stats.json" ]]; then
  cp "${AGG_DIR}/dataset_stats.json" "${PROJECT_DIR}/data/dataset_stats.original.json"
fi

python "${PROJECT_DIR}/scripts/prepare_train_val.py" \
  --input_train "${PROJECT_DIR}/data/aggregated_train.jsonl" \
  --output_train "${PROJECT_DIR}/data/train_for_sft.jsonl" \
  --output_val "${PROJECT_DIR}/data/val_for_epoch_select.jsonl" \
  --stats_path "${PROJECT_DIR}/data/train_val_split_stats.json" \
  --val_ratio 0.05 \
  --seed 42

wc -l "${PROJECT_DIR}/data/"*.jsonl | tee "${PROJECT_DIR}/outputs/logs/data_line_counts.txt"
