#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/qwen36_27b_concept_sft_project}"
MODEL_PATH="${MODEL_PATH:-/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.6-27B}"
OUTPUT_DIR="${PROJECT_DIR}/outputs/adapter/qwen36_27b_lora_r16_attn"

mkdir -p "${OUTPUT_DIR}" "${PROJECT_DIR}/outputs/logs"

export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"

accelerate launch \
  --num_processes 8 \
  "${PROJECT_DIR}/scripts/train_lora.py" \
  --model_name_or_path "${MODEL_PATH}" \
  --train_file "${PROJECT_DIR}/data/train_for_sft.jsonl" \
  --validation_file "${PROJECT_DIR}/data/val_for_epoch_select.jsonl" \
  --output_dir "${OUTPUT_DIR}" \
  --deepspeed "${PROJECT_DIR}/configs/deepspeed_zero3.json" \
  --max_seq_length 1024 \
  --num_train_epochs 3 \
  --per_device_train_batch_size 1 \
  --per_device_eval_batch_size 1 \
  --gradient_accumulation_steps 4 \
  --learning_rate 1e-5 \
  --warmup_ratio 0.03 \
  --weight_decay 0.01 \
  --lora_rank 16 \
  --lora_alpha 32 \
  --lora_dropout 0.05 \
  --target_modules q_proj,k_proj,v_proj,o_proj \
  --eval_steps 200 \
  --save_steps 200 \
  --logging_steps 10 \
  --save_total_limit 3 \
  --gradient_checkpointing \
  --trust_remote_code 2>&1 | tee "${PROJECT_DIR}/outputs/logs/train_lora.log"
