#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/qwen36_27b_concept_sft_project}"
MODEL_PATH="${MODEL_PATH:-/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.6-27B}"
ADAPTER_DIR="${ADAPTER_DIR:-${PROJECT_DIR}/outputs/adapter/qwen36_27b_lora_r16_attn/final_adapter}"
MERGED_DIR="${PROJECT_DIR}/outputs/merged/qwen36_27b_concept_sft_merged"

mkdir -p "${MERGED_DIR}" "${PROJECT_DIR}/outputs/logs"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3,4,5,6,7}"

python "${PROJECT_DIR}/scripts/merge_lora.py" \
  --base_model "${MODEL_PATH}" \
  --adapter "${ADAPTER_DIR}" \
  --output_dir "${MERGED_DIR}" \
  --max_shard_size 4GB \
  --device_map auto \
  --trust_remote_code 2>&1 | tee "${PROJECT_DIR}/outputs/logs/merge_lora.log"
