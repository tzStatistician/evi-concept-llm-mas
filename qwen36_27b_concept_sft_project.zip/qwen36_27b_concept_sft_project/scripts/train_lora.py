#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""bf16 LoRA SFT for Qwen3.6-27B using Hugging Face Trainer + DeepSpeed ZeRO-3.

Input JSONL format:
{"messages": [{"role":"system","content":"..."}, {"role":"user","content":"..."}, {"role":"assistant","content":"..."}]}

The loss is masked so the model is trained only on assistant tokens.
"""
from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

import torch
from torch.utils.data import Dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
    set_seed,
)
from transformers.integrations import HfDeepSpeedConfig
from peft import LoraConfig, get_peft_model, TaskType


class ChatSFTDataset(Dataset):
    def __init__(self, jsonl_path: Path, tokenizer: Any, max_seq_length: int):
        self.path = Path(jsonl_path)
        self.tokenizer = tokenizer
        self.max_seq_length = max_seq_length
        self.rows = self._load_jsonl(self.path)

    @staticmethod
    def _load_jsonl(path: Path) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        with path.open("r", encoding="utf-8") as f:
            for i, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except Exception as e:
                    raise ValueError(f"Invalid JSONL at {path}, line {i}: {e}") from e
        if not rows:
            raise ValueError(f"No rows loaded from {path}")
        return rows

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        row = self.rows[idx]
        messages = row["messages"]
        if len(messages) < 3 or messages[-1].get("role") != "assistant":
            raise ValueError(f"Row {idx} does not end with an assistant message")

        prompt_messages = messages[:-1]
        full_messages = messages

        prompt_ids = self.tokenizer.apply_chat_template(
            prompt_messages,
            tokenize=True,
            add_generation_prompt=True,
            truncation=True,
            max_length=self.max_seq_length,
        )
        full_ids = self.tokenizer.apply_chat_template(
            full_messages,
            tokenize=True,
            add_generation_prompt=False,
            truncation=True,
            max_length=self.max_seq_length,
        )

        # If the prompt alone is too long, no target tokens remain. Keep a minimal safe item.
        if len(full_ids) <= len(prompt_ids):
            input_ids = full_ids[: self.max_seq_length]
            labels = [-100] * len(input_ids)
            # Train on the final token to avoid all-ignored labels, but this should be rare.
            if labels:
                labels[-1] = input_ids[-1]
        else:
            input_ids = full_ids[: self.max_seq_length]
            labels = [-100] * min(len(prompt_ids), len(input_ids)) + input_ids[len(prompt_ids):]
            labels = labels[: len(input_ids)]

        attention_mask = [1] * len(input_ids)
        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }


@dataclass
class CausalLMCollator:
    tokenizer: Any
    pad_to_multiple_of: int = 8

    def __call__(self, features: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        max_len = max(x["input_ids"].size(0) for x in features)
        if self.pad_to_multiple_of:
            max_len = ((max_len + self.pad_to_multiple_of - 1) // self.pad_to_multiple_of) * self.pad_to_multiple_of

        pad_id = self.tokenizer.pad_token_id
        batch: Dict[str, List[torch.Tensor]] = {"input_ids": [], "attention_mask": [], "labels": []}
        for feat in features:
            seq_len = feat["input_ids"].size(0)
            pad_len = max_len - seq_len
            batch["input_ids"].append(torch.cat([feat["input_ids"], torch.full((pad_len,), pad_id, dtype=torch.long)]))
            batch["attention_mask"].append(torch.cat([feat["attention_mask"], torch.zeros(pad_len, dtype=torch.long)]))
            batch["labels"].append(torch.cat([feat["labels"], torch.full((pad_len,), -100, dtype=torch.long)]))
        return {k: torch.stack(v, dim=0) for k, v in batch.items()}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--model_name_or_path", type=Path, required=True)
    p.add_argument("--train_file", type=Path, required=True)
    p.add_argument("--validation_file", type=Path, required=True)
    p.add_argument("--output_dir", type=Path, required=True)
    p.add_argument("--deepspeed", type=Path, required=True)
    p.add_argument("--max_seq_length", type=int, default=1024)
    p.add_argument("--num_train_epochs", type=float, default=3.0)
    p.add_argument("--per_device_train_batch_size", type=int, default=1)
    p.add_argument("--per_device_eval_batch_size", type=int, default=1)
    p.add_argument("--gradient_accumulation_steps", type=int, default=4)
    p.add_argument("--learning_rate", type=float, default=1e-5)
    p.add_argument("--warmup_ratio", type=float, default=0.03)
    p.add_argument("--weight_decay", type=float, default=0.01)
    p.add_argument("--lora_rank", type=int, default=16)
    p.add_argument("--lora_alpha", type=int, default=32)
    p.add_argument("--lora_dropout", type=float, default=0.05)
    p.add_argument("--target_modules", type=str, default="q_proj,k_proj,v_proj,o_proj")
    p.add_argument("--eval_steps", type=int, default=200)
    p.add_argument("--save_steps", type=int, default=200)
    p.add_argument("--logging_steps", type=int, default=10)
    p.add_argument("--save_total_limit", type=int, default=3)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--gradient_checkpointing", action="store_true")
    p.add_argument("--trust_remote_code", action="store_true")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    # Important for 27B on 8×46GB GPUs: create HfDeepSpeedConfig BEFORE
    # from_pretrained so ZeRO-3 can partition parameters during initialization.
    # Keep this object alive for the whole script.
    dschf = HfDeepSpeedConfig(str(args.deepspeed))

    tokenizer = AutoTokenizer.from_pretrained(
        args.model_name_or_path,
        trust_remote_code=args.trust_remote_code,
        use_fast=True,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    model_kwargs: Dict[str, Any] = {
        "torch_dtype": torch.bfloat16,
        "trust_remote_code": args.trust_remote_code,
        "low_cpu_mem_usage": True,
    }
    try:
        model = AutoModelForCausalLM.from_pretrained(args.model_name_or_path, attn_implementation="flash_attention_2", **model_kwargs)
        print("[INFO] Loaded model with flash_attention_2")
    except Exception as e:
        print(f"[WARN] flash_attention_2 unavailable or failed: {e}")
        model = AutoModelForCausalLM.from_pretrained(args.model_name_or_path, **model_kwargs)

    model.config.use_cache = False
    if args.gradient_checkpointing:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})

    target_modules = [x.strip() for x in args.target_modules.split(",") if x.strip()]
    lora_config = LoraConfig(
        r=args.lora_rank,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        target_modules=target_modules,
        bias="none",
        task_type=TaskType.CAUSAL_LM,
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    train_dataset = ChatSFTDataset(args.train_file, tokenizer, args.max_seq_length)
    eval_dataset = ChatSFTDataset(args.validation_file, tokenizer, args.max_seq_length)
    collator = CausalLMCollator(tokenizer)

    training_args = TrainingArguments(
        output_dir=str(args.output_dir),
        overwrite_output_dir=True,
        num_train_epochs=args.num_train_epochs,
        per_device_train_batch_size=args.per_device_train_batch_size,
        per_device_eval_batch_size=args.per_device_eval_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        learning_rate=args.learning_rate,
        warmup_ratio=args.warmup_ratio,
        weight_decay=args.weight_decay,
        bf16=True,
        fp16=False,
        logging_steps=args.logging_steps,
        evaluation_strategy="steps",
        eval_steps=args.eval_steps,
        save_strategy="steps",
        save_steps=args.save_steps,
        save_total_limit=args.save_total_limit,
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        greater_is_better=False,
        gradient_checkpointing=args.gradient_checkpointing,
        remove_unused_columns=False,
        report_to="none",
        deepspeed=str(args.deepspeed),
        optim="adamw_torch",
        lr_scheduler_type="cosine",
        max_grad_norm=1.0,
        dataloader_num_workers=2,
        ddp_find_unused_parameters=False,
    )

    manifest = {
        "model_name_or_path": str(args.model_name_or_path),
        "train_file": str(args.train_file),
        "validation_file": str(args.validation_file),
        "max_seq_length": args.max_seq_length,
        "num_train_epochs": args.num_train_epochs,
        "learning_rate": args.learning_rate,
        "lora_rank": args.lora_rank,
        "lora_alpha": args.lora_alpha,
        "lora_dropout": args.lora_dropout,
        "target_modules": target_modules,
        "deepspeed": str(args.deepspeed),
    }
    (args.output_dir / "training_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        data_collator=collator,
        tokenizer=tokenizer,
    )

    trainer.train()

    final_adapter_dir = args.output_dir / "final_adapter"
    final_adapter_dir.mkdir(parents=True, exist_ok=True)
    trainer.model.save_pretrained(final_adapter_dir)
    tokenizer.save_pretrained(final_adapter_dir)
    print(f"[DONE] Saved final/best LoRA adapter to: {final_adapter_dir}")


if __name__ == "__main__":
    main()
