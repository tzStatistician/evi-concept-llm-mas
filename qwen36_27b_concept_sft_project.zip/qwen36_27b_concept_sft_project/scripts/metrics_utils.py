#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, hamming_loss, precision_recall_fscore_support
from sklearn.preprocessing import MultiLabelBinarizer

BINARY_PRESENT_ABSENT = ["absent", "present"]
MULTIWD_LABELS = ["Spiritual", "Physical", "Intellectual", "Social", "Vocational", "Emotional"]


def extract_dataset_from_messages(messages: List[Dict[str, str]]) -> str:
    user_text = next((m.get("content", "") for m in messages if m.get("role") == "user"), "")
    m = re.search(r"^Dataset:\s*(.+?)\s*$", user_text, flags=re.MULTILINE)
    return m.group(1).strip() if m else "UNKNOWN"


def get_gold_from_sft_row(row: Dict[str, Any]) -> Dict[str, Any]:
    assistant = next((m.get("content", "") for m in row.get("messages", []) if m.get("role") == "assistant"), "")
    return json.loads(assistant)


def get_prompt_messages(row: Dict[str, Any]) -> List[Dict[str, str]]:
    return [m for m in row.get("messages", []) if m.get("role") != "assistant"]


def extract_json_object(text: str) -> Tuple[Optional[Dict[str, Any]], str]:
    raw = (text or "").strip()
    if not raw:
        return None, "empty_output"
    # Remove common fenced code markers.
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.IGNORECASE).strip()
    raw = re.sub(r"\s*```$", "", raw).strip()
    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            return obj, "ok"
        return None, "json_not_object"
    except Exception:
        pass
    start = raw.find("{")
    end = raw.rfind("}")
    if start >= 0 and end > start:
        candidate = raw[start:end + 1]
        try:
            obj = json.loads(candidate)
            if isinstance(obj, dict):
                return obj, "ok_extracted"
            return None, "json_not_object_extracted"
        except Exception as e:
            return None, f"json_parse_error: {e}"
    return None, "no_json_object_found"


def normalize_present_absent(x: Any) -> Optional[str]:
    s = str(x).strip().lower()
    if s in {"present", "yes", "true", "1", "positive"}:
        return "present"
    if s in {"absent", "no", "false", "0", "negative"}:
        return "absent"
    return None


def normalize_int01(x: Any) -> Optional[int]:
    if isinstance(x, bool):
        return int(x)
    if isinstance(x, (int, float)):
        return 1 if int(x) == 1 else 0
    s = str(x).strip().lower()
    if s in {"1", "true", "yes", "present", "positive"}:
        return 1
    if s in {"0", "false", "no", "absent", "negative"}:
        return 0
    return None


def as_label_list(x: Any) -> List[str]:
    if x is None:
        return []
    if isinstance(x, list):
        return sorted({str(v).strip() for v in x if str(v).strip()})
    if isinstance(x, str):
        # Accept comma-separated fallback, but exact JSON list is preferred.
        if x.strip() == "":
            return []
        return sorted({v.strip() for v in x.split(",") if v.strip()})
    return [str(x).strip()] if str(x).strip() else []


def token_f1(gold: str, pred: str) -> float:
    def toks(s: str) -> List[str]:
        return re.findall(r"\w+", (s or "").lower())
    g = toks(gold)
    p = toks(pred)
    if not g and not p:
        return 1.0
    if not g or not p:
        return 0.0
    gc = Counter(g)
    pc = Counter(p)
    overlap = sum((gc & pc).values())
    if overlap == 0:
        return 0.0
    precision = overlap / len(p)
    recall = overlap / len(g)
    return 2 * precision * recall / (precision + recall)


def schema_valid(dataset: str, obj: Optional[Dict[str, Any]]) -> bool:
    if obj is None:
        return False
    try:
        if dataset == "LoST":
            return normalize_present_absent(obj.get("low_self_esteem")) is not None
        if dataset == "LonXplain":
            return normalize_present_absent(obj.get("lonesomeness")) is not None and "evidence_span" in obj
        if dataset == "MultiWD":
            return all(normalize_int01(obj.get(k)) is not None for k in MULTIWD_LABELS)
        if dataset == "SAD":
            return normalize_int01(obj.get("is_stressor")) is not None and "stress_label" in obj
        if dataset == "GoEmotions":
            return isinstance(obj.get("emotions"), list)
        if dataset == "DepressionEmo":
            return isinstance(obj.get("emotions"), list)
        if dataset == "CAMS":
            return "causal_category" in obj and "causal_interpretation" in obj
        return isinstance(obj, dict)
    except Exception:
        return False


def binary_metrics(y_true: List[str], y_pred: List[str], labels: Sequence[str] = BINARY_PRESENT_ABSENT) -> Dict[str, Any]:
    return {
        "n": len(y_true),
        "accuracy": accuracy_score(y_true, y_pred) if y_true else None,
        "macro_f1": f1_score(y_true, y_pred, labels=list(labels), average="macro", zero_division=0) if y_true else None,
        "per_label_f1": dict(zip(labels, f1_score(y_true, y_pred, labels=list(labels), average=None, zero_division=0).tolist())) if y_true else {},
    }


def multiclass_metrics(y_true: List[str], y_pred: List[str]) -> Dict[str, Any]:
    labels = sorted(set(y_true) | set(y_pred))
    if not y_true:
        return {"n": 0}
    f1s = f1_score(y_true, y_pred, labels=labels, average=None, zero_division=0)
    return {
        "n": len(y_true),
        "accuracy": accuracy_score(y_true, y_pred),
        "macro_f1": f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0),
        "per_label_f1": dict(zip(labels, f1s.tolist())),
    }


def multilabel_metrics(y_true: List[List[str]], y_pred: List[List[str]]) -> Dict[str, Any]:
    classes = sorted(set(x for row in y_true + y_pred for x in row))
    if not y_true:
        return {"n": 0}
    if not classes:
        return {"n": len(y_true), "micro_f1": 1.0, "macro_f1": 1.0, "subset_accuracy": 1.0, "hamming_loss": 0.0, "classes": []}
    mlb = MultiLabelBinarizer(classes=classes)
    Yt = mlb.fit_transform(y_true)
    Yp = mlb.transform(y_pred)
    per_class = f1_score(Yt, Yp, average=None, zero_division=0)
    return {
        "n": len(y_true),
        "classes": classes,
        "micro_f1": f1_score(Yt, Yp, average="micro", zero_division=0),
        "macro_f1": f1_score(Yt, Yp, average="macro", zero_division=0),
        "subset_accuracy": accuracy_score(Yt, Yp),
        "hamming_loss": hamming_loss(Yt, Yp),
        "per_label_f1": dict(zip(classes, per_class.tolist())),
    }


def compute_metrics_from_records(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    total = len(records)
    parsed = sum(1 for r in records if r.get("pred_obj") is not None)
    schema_ok = sum(1 for r in records if r.get("schema_valid") is True)

    result: Dict[str, Any] = {
        "global": {
            "n": total,
            "json_parse_rate": parsed / total if total else None,
            "schema_valid_rate": schema_ok / total if total else None,
            "parse_status_counts": dict(Counter(r.get("parse_status", "unknown") for r in records)),
            "dataset_counts": dict(Counter(r.get("dataset", "UNKNOWN") for r in records)),
        },
        "by_dataset": {},
    }

    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in records:
        grouped[r.get("dataset", "UNKNOWN")].append(r)

    for dataset, rows in sorted(grouped.items()):
        valid_rows = [r for r in rows if r.get("schema_valid")]
        ds_metrics: Dict[str, Any] = {
            "n": len(rows),
            "json_parse_rate": sum(r.get("pred_obj") is not None for r in rows) / len(rows),
            "schema_valid_rate": len(valid_rows) / len(rows),
        }

        if dataset == "LoST":
            yt, yp = [], []
            for r in valid_rows:
                yt.append(normalize_present_absent(r["gold"].get("low_self_esteem")) or "INVALID")
                yp.append(normalize_present_absent(r["pred_obj"].get("low_self_esteem")) or "INVALID")
            ds_metrics.update(binary_metrics(yt, yp))

        elif dataset == "LonXplain":
            yt, yp, exact, tf1 = [], [], [], []
            for r in valid_rows:
                yt.append(normalize_present_absent(r["gold"].get("lonesomeness")) or "INVALID")
                yp.append(normalize_present_absent(r["pred_obj"].get("lonesomeness")) or "INVALID")
                gs = str(r["gold"].get("evidence_span", "")).strip()
                ps = str(r["pred_obj"].get("evidence_span", "")).strip()
                exact.append(int(gs == ps))
                tf1.append(token_f1(gs, ps))
            ds_metrics.update({"label_metrics": binary_metrics(yt, yp), "span_exact_match": float(np.mean(exact)) if exact else None, "span_token_f1": float(np.mean(tf1)) if tf1 else None})

        elif dataset == "MultiWD":
            y_true, y_pred = [], []
            for r in valid_rows:
                y_true.append([k for k in MULTIWD_LABELS if normalize_int01(r["gold"].get(k)) == 1])
                y_pred.append([k for k in MULTIWD_LABELS if normalize_int01(r["pred_obj"].get(k)) == 1])
            ds_metrics.update(multilabel_metrics(y_true, y_pred))

        elif dataset == "SAD":
            yt, yp, lt, lp = [], [], [], []
            for r in valid_rows:
                yt.append(str(normalize_int01(r["gold"].get("is_stressor"))))
                yp.append(str(normalize_int01(r["pred_obj"].get("is_stressor"))))
                lt.append(str(r["gold"].get("stress_label", "")))
                lp.append(str(r["pred_obj"].get("stress_label", "")))
            ds_metrics.update({"is_stressor_metrics": multiclass_metrics(yt, yp), "stress_label_metrics": multiclass_metrics(lt, lp)})

        elif dataset in {"GoEmotions", "DepressionEmo"}:
            y_true, y_pred = [], []
            for r in valid_rows:
                y_true.append(as_label_list(r["gold"].get("emotions")))
                y_pred.append(as_label_list(r["pred_obj"].get("emotions")))
            ds_metrics.update(multilabel_metrics(y_true, y_pred))

        elif dataset == "CAMS":
            ct, cp, exact, tf1 = [], [], [], []
            for r in valid_rows:
                ct.append(str(r["gold"].get("causal_category", "")))
                cp.append(str(r["pred_obj"].get("causal_category", "")))
                gs = str(r["gold"].get("causal_interpretation", "")).strip()
                ps = str(r["pred_obj"].get("causal_interpretation", "")).strip()
                exact.append(int(gs == ps))
                tf1.append(token_f1(gs, ps))
            ds_metrics.update({"category_metrics": multiclass_metrics(ct, cp), "interpretation_exact_match": float(np.mean(exact)) if exact else None, "interpretation_token_f1": float(np.mean(tf1)) if tf1 else None})

        result["by_dataset"][dataset] = ds_metrics

    return result
