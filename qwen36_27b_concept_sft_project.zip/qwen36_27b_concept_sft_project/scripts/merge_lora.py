#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Merge a PEFT LoRA adapter into the base Qwen model and save a vLLM-ready model."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base_model", type=Path, required=True)
    parser.add_argument("--adapter", type=Path, required=True)
    parser.add_argument("--output_dir", type=Path, required=True)
    parser.add_argument("--max_shard_size", type=str, default="4GB")
    parser.add_argument("--trust_remote_code", action="store_true")
    parser.add_argument("--device_map", type=str, default="auto", help="Use 'auto' for multi-GPU merge, or 'cpu' if enough CPU RAM exists.")
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)

    model_kwargs: Dict[str, Any] = {
        "torch_dtype": torch.bfloat16,
        "trust_remote_code": args.trust_remote_code,
        "low_cpu_mem_usage": True,
    }
    if args.device_map.lower() != "none":
        model_kwargs["device_map"] = args.device_map

    print(f"[INFO] Loading base model: {args.base_model}")
    base = AutoModelForCausalLM.from_pretrained(args.base_model, **model_kwargs)

    print(f"[INFO] Loading adapter: {args.adapter}")
    model = PeftModel.from_pretrained(base, args.adapter)

    print("[INFO] Merging adapter into base model...")
    merged = model.merge_and_unload()
    merged.config.use_cache = True

    print(f"[INFO] Saving merged model to: {args.output_dir}")
    merged.save_pretrained(args.output_dir, safe_serialization=True, max_shard_size=args.max_shard_size)

    tokenizer = AutoTokenizer.from_pretrained(args.base_model, trust_remote_code=args.trust_remote_code, use_fast=True)
    tokenizer.save_pretrained(args.output_dir)

    manifest = {
        "base_model": str(args.base_model),
        "adapter": str(args.adapter),
        "output_dir": str(args.output_dir),
        "dtype": "bfloat16",
        "max_shard_size": args.max_shard_size,
    }
    (args.output_dir / "merge_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print("[DONE] Merged model is vLLM-ready.")


if __name__ == "__main__":
    main()
