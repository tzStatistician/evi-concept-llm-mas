#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Split aggregated_train.jsonl into train_for_sft.jsonl and val_for_epoch_select.jsonl.

The final test set remains untouched. Splitting is dataset-stratified by reading
`Dataset: ...` from the user prompt in each SFT record.
"""
from __future__ import annotations

import argparse
import json
import random
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List, Tuple


def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                raise ValueError(f"Invalid JSONL at {path}, line {i}: {e}") from e
    return rows


def write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def get_dataset(row: Dict[str, Any]) -> str:
    messages = row.get("messages", [])
    user_text = ""
    for msg in messages:
        if msg.get("role") == "user":
            user_text = msg.get("content", "")
            break
    m = re.search(r"^Dataset:\s*(.+?)\s*$", user_text, flags=re.MULTILINE)
    if not m:
        return "UNKNOWN"
    return m.group(1).strip()


def split_by_dataset(rows: List[Dict[str, Any]], val_ratio: float, seed: int) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, Any]]:
    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[get_dataset(row)].append(row)

    train_rows: List[Dict[str, Any]] = []
    val_rows: List[Dict[str, Any]] = []
    stats: Dict[str, Any] = {"by_dataset": {}}

    for dataset, items in sorted(grouped.items()):
        rng = random.Random(seed + abs(hash(dataset)) % 100000)
        items = list(items)
        rng.shuffle(items)
        n = len(items)
        if n <= 1:
            n_val = 0
        else:
            n_val = max(1, round(n * val_ratio))
            n_val = min(n_val, n - 1)
        val_part = items[:n_val]
        train_part = items[n_val:]
        train_rows.extend(train_part)
        val_rows.extend(val_part)
        stats["by_dataset"][dataset] = {
            "total_from_aggregated_train": n,
            "train_for_sft": len(train_part),
            "val_for_epoch_select": len(val_part),
            "val_ratio": round(len(val_part) / n, 6) if n else None,
        }

    rng = random.Random(seed)
    rng.shuffle(train_rows)
    rng.shuffle(val_rows)

    stats.update({
        "total_from_aggregated_train": len(rows),
        "train_for_sft": len(train_rows),
        "val_for_epoch_select": len(val_rows),
        "dataset_counts_before": dict(Counter(get_dataset(x) for x in rows)),
        "dataset_counts_train": dict(Counter(get_dataset(x) for x in train_rows)),
        "dataset_counts_val": dict(Counter(get_dataset(x) for x in val_rows)),
    })
    return train_rows, val_rows, stats


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_train", type=Path, required=True)
    parser.add_argument("--output_train", type=Path, required=True)
    parser.add_argument("--output_val", type=Path, required=True)
    parser.add_argument("--stats_path", type=Path, required=True)
    parser.add_argument("--val_ratio", type=float, default=0.05)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    rows = read_jsonl(args.input_train)
    train_rows, val_rows, stats = split_by_dataset(rows, args.val_ratio, args.seed)

    write_jsonl(args.output_train, train_rows)
    write_jsonl(args.output_val, val_rows)
    args.stats_path.parent.mkdir(parents=True, exist_ok=True)
    args.stats_path.write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"[DONE] train_for_sft: {len(train_rows)} -> {args.output_train}")
    print(f"[DONE] val_for_epoch_select: {len(val_rows)} -> {args.output_val}")
    print(f"[DONE] stats: {args.stats_path}")


if __name__ == "__main__":
    main()
