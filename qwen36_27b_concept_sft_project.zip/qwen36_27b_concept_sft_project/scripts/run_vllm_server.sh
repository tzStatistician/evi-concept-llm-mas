#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/qwen36_27b_concept_sft_project}"
MERGED_DIR="${MERGED_DIR:-${PROJECT_DIR}/outputs/merged/qwen36_27b_concept_sft_merged}"
TP_SIZE="${TP_SIZE:-4}"
PORT="${PORT:-8000}"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3}"

vllm serve "${MERGED_DIR}" \
  --tensor-parallel-size "${TP_SIZE}" \
  --dtype bfloat16 \
  --max-model-len 2048 \
  --trust-remote-code \
  --port "${PORT}"
