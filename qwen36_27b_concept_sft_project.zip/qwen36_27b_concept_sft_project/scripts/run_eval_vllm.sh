#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/qwen36_27b_concept_sft_project}"
MERGED_DIR="${MERGED_DIR:-${PROJECT_DIR}/outputs/merged/qwen36_27b_concept_sft_merged}"
TP_SIZE="${TP_SIZE:-4}"

mkdir -p "${PROJECT_DIR}/outputs/predictions" "${PROJECT_DIR}/outputs/metrics" "${PROJECT_DIR}/outputs/logs"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3}"

python "${PROJECT_DIR}/scripts/evaluate_vllm.py" \
  --model "${MERGED_DIR}" \
  --test_file "${PROJECT_DIR}/data/aggregated_test.jsonl" \
  --output_predictions "${PROJECT_DIR}/outputs/predictions/test_predictions.jsonl" \
  --output_metrics "${PROJECT_DIR}/outputs/metrics/test_metrics.json" \
  --tensor_parallel_size "${TP_SIZE}" \
  --max_model_len 2048 \
  --max_tokens 128 \
  --temperature 0 \
  --dtype bfloat16 \
  --batch_size 256 \
  --trust_remote_code 2>&1 | tee "${PROJECT_DIR}/outputs/logs/eval_vllm.log"
