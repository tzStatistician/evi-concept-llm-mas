#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Evaluate a merged SFT model with vLLM on the aggregated test JSONL.

Outputs:
- predictions.jsonl: one row per sample with gold/pred/parse status.
- metrics.json: global and per-dataset metrics.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

from tqdm import tqdm
from transformers import AutoTokenizer
from vllm import LLM, SamplingParams

from metrics_utils import (
    compute_metrics_from_records,
    extract_dataset_from_messages,
    extract_json_object,
    get_gold_from_sft_row,
    get_prompt_messages,
    schema_valid,
)


def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception as e:
                raise ValueError(f"Invalid JSONL at {path}, line {i}: {e}") from e
    return rows


def write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True, help="Merged model path or base model path for vLLM.")
    parser.add_argument("--test_file", type=Path, required=True)
    parser.add_argument("--output_predictions", type=Path, required=True)
    parser.add_argument("--output_metrics", type=Path, required=True)
    parser.add_argument("--tensor_parallel_size", type=int, default=4)
    parser.add_argument("--max_model_len", type=int, default=2048)
    parser.add_argument("--max_tokens", type=int, default=128)
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--dtype", type=str, default="bfloat16")
    parser.add_argument("--trust_remote_code", action="store_true")
    parser.add_argument("--batch_size", type=int, default=256)
    args = parser.parse_args()

    rows = read_jsonl(args.test_file)
    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=args.trust_remote_code, use_fast=True)

    prompts: List[str] = []
    metadata: List[Dict[str, Any]] = []
    for idx, row in enumerate(rows):
        prompt_messages = get_prompt_messages(row)
        prompt = tokenizer.apply_chat_template(prompt_messages, tokenize=False, add_generation_prompt=True)
        prompts.append(prompt)
        gold = get_gold_from_sft_row(row)
        dataset = extract_dataset_from_messages(row["messages"])
        metadata.append({"index": idx, "dataset": dataset, "gold": gold})

    llm = LLM(
        model=str(args.model),
        tensor_parallel_size=args.tensor_parallel_size,
        dtype=args.dtype,
        max_model_len=args.max_model_len,
        trust_remote_code=args.trust_remote_code,
    )
    sampling = SamplingParams(temperature=args.temperature, max_tokens=args.max_tokens)

    records: List[Dict[str, Any]] = []
    for start in tqdm(range(0, len(prompts), args.batch_size), desc="vLLM generate"):
        batch_prompts = prompts[start:start + args.batch_size]
        outputs = llm.generate(batch_prompts, sampling)
        for local_i, out in enumerate(outputs):
            meta = metadata[start + local_i]
            pred_text = out.outputs[0].text if out.outputs else ""
            pred_obj, parse_status = extract_json_object(pred_text)
            valid = schema_valid(meta["dataset"], pred_obj)
            records.append({
                "index": meta["index"],
                "dataset": meta["dataset"],
                "gold": meta["gold"],
                "prediction_text": pred_text,
                "pred_obj": pred_obj,
                "parse_status": parse_status,
                "schema_valid": valid,
            })

    metrics = compute_metrics_from_records(records)
    args.output_predictions.parent.mkdir(parents=True, exist_ok=True)
    args.output_metrics.parent.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.output_predictions, records)
    args.output_metrics.write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"[DONE] predictions: {args.output_predictions}")
    print(f"[DONE] metrics: {args.output_metrics}")
    print(json.dumps(metrics["global"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
