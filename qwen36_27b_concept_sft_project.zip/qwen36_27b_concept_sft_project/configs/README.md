# Configs

`deepspeed_zero3.json` is for bf16 LoRA SFT on 8 L20 GPUs with Qwen3.6-27B. It shards the frozen base model with ZeRO-3 and lets Hugging Face Trainer fill batch-size fields automatically.
