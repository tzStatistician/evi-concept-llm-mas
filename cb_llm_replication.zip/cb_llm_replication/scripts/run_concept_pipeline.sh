#!/usr/bin/env bash
set -euo pipefail

export OPENAI_API_KEY="${OPENAI_API_KEY:-EMPTY}"
export OPENAI_BASE_URL="${OPENAI_BASE_URL:-http://127.0.0.1:8000/v1}"

python -m cb_llm_replication.cli \
  --config config/suicide_labels.yaml \
  --output-dir outputs/suicide_baseline \
  --model-name Qwen/Qwen3.6-27B \
  --concepts-per-label 24
