# cb_llm_replication

A replication-oriented scaffold for the **concept extraction** stage of the paper:
**Concept Bottleneck Large Language Models** (classification side only).

This package implements the pipeline we aligned on:

1. **Per-label raw concept generation** from class labels only.
2. **Global sanity regulation** without psychology-domain knowledge.
3. **Canonical concept inventory** with provenance.
4. **Frozen concept vocabulary** ready for ACS / ACC / downstream CBM training.

## What this code does

- Generates concepts **label-by-label** using an OpenAI-compatible endpoint.
- Stores raw concepts per label.
- Runs structural sanity checks:
  - remove concepts too similar to labels
  - remove duplicates across classes
  - merge trivial wording variants
  - remove vague concepts
  - remove non-text-observable concepts
  - normalize concept names
- Exports:
  - raw concepts
  - dropped concepts + reasons
  - final canonical concepts
  - concept-to-label provenance map

## What this code does not do

- It does **not** use posts during concept generation.
- It does **not** use psychology theory or domain ontologies.
- It does **not** implement ACS / ACC / CBL training yet.

## Project layout

```text
cb_llm_replication/
├── cb_llm_replication/
│   ├── __init__.py
│   ├── cli.py
│   ├── config.py
│   ├── llm_client.py
│   ├── models.py
│   ├── pipeline.py
│   ├── prompts.py
│   ├── regulation.py
│   └── utils.py
├── config/
│   └── suicide_labels.yaml
├── examples/
│   └── raw_generation_example.json
├── scripts/
│   └── run_concept_pipeline.sh
├── requirements.txt
└── README.md
```

## Quick start

### 1) Install

```bash
pip install -r requirements.txt
```

### 2) Set an OpenAI-compatible endpoint

For a local vLLM server:

```bash
export OPENAI_API_KEY=EMPTY
export OPENAI_BASE_URL=http://127.0.0.1:8000/v1
```

### 3) Run the pipeline

```bash
python -m cb_llm_replication.cli \
  --config config/suicide_labels.yaml \
  --output-dir outputs/suicide_baseline \
  --model-name Qwen/Qwen3.6-27B \
  --concepts-per-label 24
```

## Output files

The pipeline writes:

- `raw_concepts.json`
- `dropped_concepts.json`
- `regulated_concepts.json`
- `concept_to_label_map.json`
- `run_summary.json`

## Flowchart

```text
Task + labels only
  |
  v
Per-label LLM concept generation
  |
  v
Raw label-specific concept sets
  |
  v
Global sanity regulation
  |- remove label-like concepts
  |- remove duplicates
  |- merge trivial variants
  |- remove vague concepts
  |- remove non-text-observable concepts
  |
  v
Canonical concept inventory + provenance
  |
  v
Frozen baseline concept vocabulary
```

## Suggested baseline for your task

Use the included `config/suicide_labels.yaml` as the label source.
A reasonable first run is:

- `concepts_per_label = 20–25`
- then inspect the regulated output

## Notes

- The regulation layer is **domain-agnostic quality control**, not psychology curation.
- If you later want a stricter or looser sanity filter, edit `regulation.py` thresholds and keyword lists.
