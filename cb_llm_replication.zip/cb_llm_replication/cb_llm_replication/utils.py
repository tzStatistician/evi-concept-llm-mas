from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


_NON_ALNUM_RE = re.compile(r"[^a-z0-9\s-]+")
_MULTI_SPACE_RE = re.compile(r"\s+")


def normalize_text(text: str) -> str:
    text = text.strip().lower()
    text = text.replace("_", " ")
    text = _NON_ALNUM_RE.sub(" ", text)
    text = _MULTI_SPACE_RE.sub(" ", text).strip()
    return text


def slugify(text: str) -> str:
    return normalize_text(text).replace(" ", "-")


def write_json(obj: Any, path: str | Path) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
