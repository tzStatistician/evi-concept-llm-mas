from __future__ import annotations

import argparse

from .pipeline import ConceptExtractionPipeline


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="CB-LLM concept extraction replication scaffold")
    parser.add_argument("--config", required=True, help="Path to label YAML config")
    parser.add_argument("--output-dir", required=True, help="Directory to write outputs")
    parser.add_argument("--model-name", required=True, help="Model name exposed by your OpenAI-compatible endpoint")
    parser.add_argument("--concepts-per-label", type=int, default=24, help="Number of raw concepts to request per label")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    pipeline = ConceptExtractionPipeline(
        model_name=args.model_name,
        concepts_per_label=args.concepts_per_label,
        output_dir=args.output_dir,
    )
    pipeline.run(args.config)
    print(f"Done. Outputs written to: {args.output_dir}")


if __name__ == "__main__":
    main()
