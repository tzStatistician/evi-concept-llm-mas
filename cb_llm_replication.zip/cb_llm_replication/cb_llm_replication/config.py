from __future__ import annotations

from pathlib import Path
from typing import List
import yaml

from .models import LabelSpec


class PipelineConfigError(ValueError):
    pass


def load_label_config(path: str | Path) -> List[LabelSpec]:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if not isinstance(data, dict) or "labels" not in data:
        raise PipelineConfigError("Config must contain a top-level 'labels' list.")

    labels = [LabelSpec(**item) for item in data["labels"]]
    if not labels:
        raise PipelineConfigError("Config contains no labels.")
    return labels
