from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from tqdm import tqdm

from .config import load_label_config
from .llm_client import OpenAICompatibleLLM
from .models import RawConcept, RunSummary
from .regulation import regulate_concepts
from .utils import ensure_dir, normalize_text, slugify, write_json


class ConceptExtractionPipeline:
    def __init__(self, model_name: str, concepts_per_label: int, output_dir: str | Path):
        self.model_name = model_name
        self.concepts_per_label = concepts_per_label
        self.output_dir = ensure_dir(output_dir)
        self.client = OpenAICompatibleLLM(model_name=model_name)

    def run(self, config_path: str | Path) -> None:
        labels = load_label_config(config_path)
        raw_generation_results = []
        raw_concepts: List[RawConcept] = []

        for label in tqdm(labels, desc="Generating concepts"):
            result = self.client.generate_label_concepts(label, self.concepts_per_label)
            raw_generation_results.append(result.model_dump())
            for idx, item in enumerate(result.concepts):
                concept_id = f"rc-{slugify(label.name)}-{idx+1:03d}"
                raw_concepts.append(RawConcept(
                    concept_id=concept_id,
                    concept_name=item.concept_name,
                    normalized_name=normalize_text(item.concept_name),
                    brief_definition=item.brief_definition,
                    rationale=item.rationale,
                    source_label=label.name,
                ))

        write_json(raw_generation_results, self.output_dir / "raw_generation_results.json")
        write_json([c.model_dump() for c in raw_concepts], self.output_dir / "raw_concepts.json")

        regulation_result = regulate_concepts(raw_concepts, [l.name for l in labels])

        regulated = [c.model_dump() for c in regulation_result.canonical_concepts]
        dropped = [c.model_dump() for c in regulation_result.dropped_concepts]
        concept_to_label = {
            c["canonical_id"]: {
                "primary_source_label": c["primary_source_label"],
                "all_source_labels": c["all_source_labels"],
            }
            for c in regulated
        }

        write_json(regulated, self.output_dir / "regulated_concepts.json")
        write_json(dropped, self.output_dir / "dropped_concepts.json")
        write_json(concept_to_label, self.output_dir / "concept_to_label_map.json")

        summary = RunSummary(
            model_name=self.model_name,
            concepts_per_label=self.concepts_per_label,
            num_labels=len(labels),
            num_raw_concepts=len(raw_concepts),
            num_dropped_concepts=len(regulation_result.dropped_concepts),
            num_regulated_concepts=len(regulation_result.canonical_concepts),
        )
        write_json(summary.model_dump(), self.output_dir / "run_summary.json")
