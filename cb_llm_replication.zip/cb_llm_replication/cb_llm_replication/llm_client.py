from __future__ import annotations

import json
import os
from typing import Any

from openai import OpenAI

from .models import LabelGenerationResult
from .prompts import SYSTEM_PROMPT, build_user_prompt


class OpenAICompatibleLLM:
    def __init__(self, model_name: str, temperature: float = 0.2, max_tokens: int = 4000):
        api_key = os.getenv("OPENAI_API_KEY", "EMPTY")
        base_url = os.getenv("OPENAI_BASE_URL")
        self.client = OpenAI(api_key=api_key, base_url=base_url)
        self.model_name = model_name
        self.temperature = temperature
        self.max_tokens = max_tokens

    def generate_label_concepts(self, label, concepts_per_label: int) -> LabelGenerationResult:
        user_prompt = build_user_prompt(label, concepts_per_label)

        completion = self.client.chat.completions.create(
            model=self.model_name,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
        )
        raw_text = completion.choices[0].message.content
        data: dict[str, Any] = json.loads(raw_text)
        result = LabelGenerationResult(**data)
        result.raw_response = raw_text
        return result
