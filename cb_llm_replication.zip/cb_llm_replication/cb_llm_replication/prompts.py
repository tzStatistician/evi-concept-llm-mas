from __future__ import annotations

from .models import LabelSpec


SYSTEM_PROMPT = """You are assisting with concept extraction for a text classification replication study.
Your task is to generate concise, human-readable concepts for a single class label.
The concepts must be:
- semantically specific
- text-observable in principle
- not trivial paraphrases of the label
- not overly broad umbrella categories
Return valid JSON only.
"""


def build_user_prompt(label: LabelSpec, concepts_per_label: int) -> str:
    return f"""
Task: multiclass suicide-related text classification.
Current class label: {label.name}
Label definition: {label.definition}

Generate exactly {concepts_per_label} candidate concepts for this class.

Output JSON with this schema:
{{
  "label": "{label.name}",
  "concepts": [
    {{
      "concept_name": "short canonical phrase",
      "brief_definition": "1-2 sentence explanation",
      "rationale": "why it is relevant to the label"
    }}
  ]
}}

Hard constraints:
- concept_name must be short and canonical
- do not use the label name itself as a concept
- do not output duplicates
- do not output vague terms like distress, negativity, emotional pain unless made specific
- concepts should be potentially inferable from text
- return JSON only, no markdown
""".strip()
