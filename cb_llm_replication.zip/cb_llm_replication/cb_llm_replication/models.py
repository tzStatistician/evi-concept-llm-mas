from __future__ import annotations

from typing import List, Optional
from pydantic import BaseModel, Field


class LabelSpec(BaseModel):
    name: str
    definition: str


class GenerationItem(BaseModel):
    concept_name: str = Field(..., description="Short concept phrase")
    brief_definition: str = Field(..., description="Compact explanation")
    rationale: str = Field(..., description="Why this concept is relevant to the label")


class LabelGenerationResult(BaseModel):
    label: str
    concepts: List[GenerationItem]
    raw_response: Optional[str] = None


class RawConcept(BaseModel):
    concept_id: str
    concept_name: str
    normalized_name: str
    brief_definition: str
    rationale: str
    source_label: str


class DroppedConcept(BaseModel):
    concept_id: str
    concept_name: str
    source_label: str
    reason: str
    detail: Optional[str] = None


class CanonicalConcept(BaseModel):
    canonical_id: str
    concept_name: str
    normalized_name: str
    primary_source_label: str
    all_source_labels: List[str]
    merged_concept_ids: List[str]
    merged_variants: List[str]
    short_definition: str


class RunSummary(BaseModel):
    model_name: str
    concepts_per_label: int
    num_labels: int
    num_raw_concepts: int
    num_dropped_concepts: int
    num_regulated_concepts: int
