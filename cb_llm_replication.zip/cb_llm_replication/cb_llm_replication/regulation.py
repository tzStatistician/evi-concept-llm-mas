from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple

from rapidfuzz import fuzz

from .models import CanonicalConcept, DroppedConcept, RawConcept
from .utils import normalize_text, slugify


VAGUE_TERMS = {
    "distress", "negativity", "negative emotion", "emotional pain", "mental pain",
    "crisis", "suffering", "bad feelings", "sadness", "depression", "anxiety",
    "suicidality", "risk", "severity", "mental state", "psychological pain",
}

NON_OBSERVABLE_HINTS = {
    "true risk", "actual intent", "real severity", "clinical severity", "hidden severity",
    "underlying disorder", "psychiatric deterioration", "future attempt probability",
    "real lethality", "chronic pathology",
}


def label_like(concept_name: str, labels: Iterable[str], threshold: int = 88) -> tuple[bool, str | None]:
    name = normalize_text(concept_name)
    for label in labels:
        ln = normalize_text(label)
        score = fuzz.ratio(name, ln)
        if name == ln or score >= threshold or ln in name or name in ln:
            return True, label
    return False, None


def vague(concept_name: str) -> bool:
    name = normalize_text(concept_name)
    return name in VAGUE_TERMS


def non_observable(concept_name: str, definition: str) -> bool:
    text = f"{concept_name} {definition}".lower()
    return any(term in text for term in NON_OBSERVABLE_HINTS)


def near_duplicate(a: str, b: str) -> bool:
    a_n = normalize_text(a)
    b_n = normalize_text(b)
    if a_n == b_n:
        return True
    if fuzz.ratio(a_n, b_n) >= 90:
        return True
    if fuzz.token_sort_ratio(a_n, b_n) >= 92:
        return True
    if a_n in b_n or b_n in a_n:
        shorter = min(len(a_n), len(b_n))
        longer = max(len(a_n), len(b_n))
        if shorter >= 5 and longer - shorter <= 10:
            return True
    return False


@dataclass
class RegulationResult:
    canonical_concepts: List[CanonicalConcept]
    dropped_concepts: List[DroppedConcept]


def regulate_concepts(raw_concepts: List[RawConcept], labels: List[str]) -> RegulationResult:
    dropped: List[DroppedConcept] = []
    survivors: List[RawConcept] = []

    for concept in raw_concepts:
        is_label_like, matched_label = label_like(concept.concept_name, labels)
        if is_label_like:
            dropped.append(DroppedConcept(
                concept_id=concept.concept_id,
                concept_name=concept.concept_name,
                source_label=concept.source_label,
                reason="too_similar_to_label",
                detail=f"Matched label: {matched_label}",
            ))
            continue
        if vague(concept.concept_name):
            dropped.append(DroppedConcept(
                concept_id=concept.concept_id,
                concept_name=concept.concept_name,
                source_label=concept.source_label,
                reason="too_vague",
            ))
            continue
        if non_observable(concept.concept_name, concept.brief_definition):
            dropped.append(DroppedConcept(
                concept_id=concept.concept_id,
                concept_name=concept.concept_name,
                source_label=concept.source_label,
                reason="not_text_observable",
            ))
            continue
        survivors.append(concept)

    groups: List[List[RawConcept]] = []
    assigned = [False] * len(survivors)

    for i, concept in enumerate(survivors):
        if assigned[i]:
            continue
        cluster = [concept]
        assigned[i] = True
        for j in range(i + 1, len(survivors)):
            if assigned[j]:
                continue
            other = survivors[j]
            if near_duplicate(concept.concept_name, other.concept_name):
                cluster.append(other)
                assigned[j] = True
        groups.append(cluster)

    canonical_concepts: List[CanonicalConcept] = []
    for group in groups:
        primary = group[0]
        all_source_labels = sorted({c.source_label for c in group})
        merged_ids = [c.concept_id for c in group]
        merged_names = [c.concept_name for c in group]
        canonical_name = normalize_text(primary.concept_name)
        canonical_concepts.append(CanonicalConcept(
            canonical_id=f"cc-{slugify(primary.source_label)}-{slugify(primary.concept_name)}",
            concept_name=canonical_name,
            normalized_name=canonical_name,
            primary_source_label=primary.source_label,
            all_source_labels=all_source_labels,
            merged_concept_ids=merged_ids,
            merged_variants=merged_names,
            short_definition=primary.brief_definition,
        ))

        for concept in group[1:]:
            dropped.append(DroppedConcept(
                concept_id=concept.concept_id,
                concept_name=concept.concept_name,
                source_label=concept.source_label,
                reason="duplicate_or_trivial_variant",
                detail=f"Merged into: {primary.concept_name}",
            ))

    canonical_concepts.sort(key=lambda x: (x.primary_source_label, x.concept_name))
    dropped.sort(key=lambda x: (x.reason, x.source_label, x.concept_name))
    return RegulationResult(canonical_concepts=canonical_concepts, dropped_concepts=dropped)
