from __future__ import annotations

import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

from utils.config import copy_config_used, load_config_and_paths, parse_common_args, resolve_path, write_json
from utils.io_utils import ensure_dir


def count_words(text: str) -> int:
    return len(re.findall(r"\b[\w']+\b", str(text)))


def main():
    args = parse_common_args()
    cfg, root, run_dir = load_config_and_paths(args.config, args.run_id)
    copy_config_used(args.config, run_dir)

    data_cfg = cfg['data']
    input_csv = Path(data_cfg['input_csv'])
    df = pd.read_csv(input_csv)

    text_col = data_cfg['text_col']
    if text_col not in df.columns:
        raise ValueError(f"Text column {text_col!r} not found. Columns: {df.columns.tolist()}")

    post_id_col = data_cfg.get('post_id_col')
    if post_id_col and post_id_col in df.columns:
        df['post_id'] = df[post_id_col].astype(str)
    else:
        df['post_id'] = [f'row_{i:06d}' for i in range(len(df))]

    df[text_col] = df[text_col].fillna('').astype(str)
    df = df[df[text_col].str.strip() != ''].copy()
    df['word_count'] = df[text_col].apply(count_words)

    if args.limit is not None:
        df = df.head(args.limit).copy()
    else:
        sample_size = data_cfg.get('sample_size')
        if sample_size is not None and int(sample_size) < len(df):
            label_col = data_cfg.get('label_col')
            if data_cfg.get('sample_strategy') == 'stratified_by_label_and_word_count' and label_col in df.columns:
                df['_word_bucket'] = pd.qcut(df['word_count'].rank(method='first'), q=5, labels=False, duplicates='drop')
                df['_stratum'] = df[label_col].astype(str) + '__' + df['_word_bucket'].astype(str)
                parts = []
                rng = np.random.default_rng(cfg['run'].get('seed', 42))
                for _, g in df.groupby('_stratum'):
                    n = max(1, round(len(g) / len(df) * int(sample_size)))
                    n = min(n, len(g))
                    parts.append(g.sample(n=n, random_state=int(rng.integers(0, 1_000_000))))
                df = pd.concat(parts).sample(frac=1, random_state=cfg['run'].get('seed', 42)).head(int(sample_size)).copy()
                df = df.drop(columns=['_word_bucket', '_stratum'], errors='ignore')
            else:
                df = df.sample(n=int(sample_size), random_state=cfg['run'].get('seed', 42)).copy()

    prepared_dir = ensure_dir(run_dir / 'prepared')
    out_csv = prepared_dir / 'input_prepared.csv'
    df.to_csv(out_csv, index=False)

    metadata = {
        'input_csv': str(input_csv),
        'n_rows_prepared': int(len(df)),
        'columns': df.columns.tolist(),
        'text_col': text_col,
        'word_count': {
            'mean': float(df['word_count'].mean()),
            'std': float(df['word_count'].std()),
            'min': int(df['word_count'].min()),
            'max': int(df['word_count'].max()),
            'p50': float(df['word_count'].quantile(0.50)),
            'p90': float(df['word_count'].quantile(0.90)),
            'p95': float(df['word_count'].quantile(0.95)),
            'p99': float(df['word_count'].quantile(0.99)),
        }
    }
    write_json(metadata, run_dir / 'input_metadata.json')
    print(f'Saved prepared data: {out_csv}')


if __name__ == '__main__':
    main()
