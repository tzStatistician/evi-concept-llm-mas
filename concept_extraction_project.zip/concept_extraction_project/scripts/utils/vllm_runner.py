from __future__ import annotations

from typing import Any, Dict, List

from transformers import AutoTokenizer
from vllm import LLM, SamplingParams


def load_tokenizer(model_path: str, trust_remote_code: bool = True):
    return AutoTokenizer.from_pretrained(model_path, trust_remote_code=trust_remote_code)


def messages_to_prompt(tokenizer, messages: List[Dict[str, str]], enable_thinking: bool = False) -> str:
    try:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=enable_thinking,
        )
    except TypeError:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )


def load_llm(cfg: Dict[str, Any]) -> LLM:
    m = cfg['model']
    return LLM(
        model=m['model_path'],
        tensor_parallel_size=int(m.get('tensor_parallel_size', 1)),
        max_model_len=int(m.get('max_model_len', 8192)),
        gpu_memory_utilization=float(m.get('gpu_memory_utilization', 0.90)),
        trust_remote_code=bool(m.get('trust_remote_code', True)),
        dtype=m.get('dtype', 'auto'),
    )


def build_sampling_params(cfg: Dict[str, Any]) -> SamplingParams:
    g = cfg['generation']
    return SamplingParams(
        temperature=float(g.get('temperature', 0.0)),
        top_p=float(g.get('top_p', 1.0)),
        max_tokens=int(g.get('max_tokens', 1024)),
    )
