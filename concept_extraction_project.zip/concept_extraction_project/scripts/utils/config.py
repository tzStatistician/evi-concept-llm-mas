from __future__ import annotations

import argparse
import json
import os
import shutil
from pathlib import Path
from typing import Any, Dict

import yaml


def load_yaml(path: str | Path) -> Dict[str, Any]:
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def save_yaml(obj: Dict[str, Any], path: str | Path) -> None:
    with open(path, 'w', encoding='utf-8') as f:
        yaml.safe_dump(obj, f, sort_keys=False, allow_unicode=True, width=120)


def get_project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def parse_common_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--run_id', required=True)
    parser.add_argument('--limit', type=int, default=None)
    return parser.parse_args()


def load_config_and_paths(config_path: str | Path, run_id: str):
    root = get_project_root()
    cfg = load_yaml(root / config_path if not Path(config_path).is_absolute() else config_path)
    run_name = cfg['run']['run_name']
    output_root = root / cfg['run'].get('output_root', 'outputs')
    run_dir = output_root / f'{run_name}__{run_id}'
    run_dir.mkdir(parents=True, exist_ok=True)
    cfg['_project_root'] = str(root)
    cfg['_run_id'] = run_id
    cfg['_run_dir'] = str(run_dir)
    return cfg, root, run_dir


def resolve_path(root: Path, p: str | Path) -> Path:
    p = Path(p)
    return p if p.is_absolute() else root / p


def copy_config_used(config_path: str | Path, run_dir: Path):
    src = Path(config_path)
    if not src.is_absolute():
        src = get_project_root() / src
    shutil.copy2(src, run_dir / 'config_used.yaml')


def write_json(obj: Any, path: str | Path):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
