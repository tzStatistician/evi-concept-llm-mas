from __future__ import annotations

import json
import os
from pathlib import Path

import pandas as pd
from tqdm import tqdm

from utils.config import load_config_and_paths, load_yaml, parse_common_args, resolve_path
from utils.io_utils import ensure_dir, append_jsonl
from utils.prompt_builder import build_chat_messages
from utils.vllm_runner import build_sampling_params, load_llm, load_tokenizer, messages_to_prompt


def load_groups(run_dir: Path):
    with open(run_dir / 'concept_groups_used.json', 'r', encoding='utf-8') as f:
        return json.load(f)


def main():
    args = parse_common_args()
    cfg, root, run_dir = load_config_and_paths(args.config, args.run_id)

    model_gpu_ids = cfg['model'].get('gpu_ids')
    if model_gpu_ids and 'CUDA_VISIBLE_DEVICES' not in os.environ:
        os.environ['CUDA_VISIBLE_DEVICES'] = str(model_gpu_ids)

    prepared_csv = run_dir / 'prepared/input_prepared.csv'
    df = pd.read_csv(prepared_csv)
    if args.limit is not None:
        df = df.head(args.limit).copy()

    prompt_cfg = load_yaml(resolve_path(root, cfg['prompt']['prompt_file']))
    groups_payload = load_groups(run_dir)
    normal_groups = groups_payload['normal_groups']
    long_groups = groups_payload['long_groups']
    threshold = int(cfg['concepts']['long_post_word_threshold'])
    text_col = cfg['data']['text_col']

    raw_dir = ensure_dir(run_dir / 'raw_generations')
    out_jsonl = raw_dir / 'raw_generations.jsonl'
    if out_jsonl.exists():
        out_jsonl.unlink()

    print('Loading tokenizer and model...')
    tokenizer = load_tokenizer(cfg['model']['model_path'], cfg['model'].get('trust_remote_code', True))
    llm = load_llm(cfg)
    sampling_params = build_sampling_params(cfg)
    enable_thinking = bool(cfg['generation'].get('enable_thinking', False))

    batch_size = int(cfg['runtime'].get('batch_size', 64))
    pending_prompts = []
    pending_meta = []
    total_requests = 0

    def flush():
        nonlocal pending_prompts, pending_meta, total_requests
        if not pending_prompts:
            return
        outputs = llm.generate(pending_prompts, sampling_params)
        records = []
        for meta, out in zip(pending_meta, outputs):
            text = out.outputs[0].text if out.outputs else ''
            records.append({**meta, 'raw_response': text, 'status': 'ok', 'error': None})
        append_jsonl(records, out_jsonl)
        total_requests += len(records)
        pending_prompts = []
        pending_meta = []

    for row in tqdm(df.itertuples(index=False), total=len(df), desc='Building/running prompts'):
        rowd = row._asdict()
        post_id = str(rowd['post_id'])
        post_text = str(rowd[text_col])
        word_count = int(rowd.get('word_count', 0))
        groups = long_groups if word_count > threshold else normal_groups
        group_type = 'long' if word_count > threshold else 'normal'

        for g in groups:
            messages = build_chat_messages(post_id, post_text, g['concepts'], prompt_cfg)
            prompt = messages_to_prompt(tokenizer, messages, enable_thinking=enable_thinking)
            pending_prompts.append(prompt)
            pending_meta.append({
                'post_id': post_id,
                'group_id': g['group_id'],
                'group_type': group_type,
                'concept_ids': g['concept_ids'],
                'model_name': cfg['model']['model_name'],
                'word_count': word_count,
            })
            if len(pending_prompts) >= batch_size:
                flush()
    flush()
    print(f'Saved raw generations: {out_jsonl}')
    print(f'Total requests: {total_requests}')


if __name__ == '__main__':
    main()
