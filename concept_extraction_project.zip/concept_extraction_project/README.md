# Concept Extraction Project

Offline vLLM concept extraction for suicide-risk research.

## Design

- One model per run.
- Same code for SFT and base Qwen.
- No server mode, no OpenAI API wrapper.
- Concept definitions and prompts are YAML-first.
- Outputs are timestamped for reproducibility.

## Main workflow

```bash
cd /mnt/disk1/wbjtu/tzbjtu/somental/concept_extraction_project

CUDA_VISIBLE_DEVICES=0,1,2,3 \
bash run_extraction.sh configs/sft_qwen36_27b.yaml \
  2>&1 | tee logs/sft_full_$(date +%Y%m%d_%H%M%S).log
```

For raw Qwen baseline, switch config:

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 \
bash run_extraction.sh configs/raw_qwen36_27b.yaml \
  2>&1 | tee logs/raw_sample_$(date +%Y%m%d_%H%M%S).log
```

## Sources used for concept design

- 3ST ontology: NCBO BioPortal `THREE-ST` ontology. The ontology maps classes to the 3-Step Theory of suicide factors: psychological pain, hopelessness, connectedness, and capacity for suicide. BioPortal notes that the classes are intended for NLP extraction from clinical notes; the ontology class list does not provide per-class textual definitions, so this project uses concise operational definitions faithful to the class names.
- C-SSRS: Columbia-Suicide Severity Rating Scale Lifetime/Recent clinical materials and basic scoring guide. Definitions were condensed into binary concept rules for text extraction.
- Reddit C-SSRS PLOS ONE paper: Gaur et al. (2021), `Characterization of time-variant and time-invariant assessment of suicidality on Reddit using C-SSRS`. Temporal and social-media concepts are operationalized from the paper's focus on severity, temporality, user-level modeling, supportive users/posts, and time-variant vs time-invariant Reddit evidence.

## Outputs

Each run creates:

```text
outputs/<run_name>__<timestamp>/
├── config_used.yaml
├── prepared/input_prepared.csv
├── concept_groups_used.json
├── raw_generations/raw_generations.jsonl
├── validated/validated_long.jsonl
├── validated/validation_errors.jsonl
├── validated/validation_report.json
├── matrices/concept_strength_matrix.csv
├── matrices/concept_evidence_matrix.csv
└── reports/*.csv
```

Strength coding in `concept_strength_matrix.csv`:

```text
0 = absent
1 = present
-1 = not_sure
```
