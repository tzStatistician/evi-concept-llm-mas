# Commands

## Phase 2: run the four post-hoc linear-head trials

```bash
conda activate sft
cd /mnt/disk1/wbjtu/tzbjtu/somental/qwen_cbm

python run_logreg_trials.py \
  --run_dir /mnt/disk1/wbjtu/tzbjtu/somental/qwen_cbm/outputs/run_gpu0123_3ep \
  --output_dir /mnt/disk1/wbjtu/tzbjtu/somental/qwen_cbm/outputs/run_gpu0123_3ep/logreg_trials \
  --manual_class_weights '{"Indicator":1.0,"Ideation":1.2,"Attempt":1.5,"Behavior":1.5}'
```

This is **two-phase**, not end-to-end, for the final head.
