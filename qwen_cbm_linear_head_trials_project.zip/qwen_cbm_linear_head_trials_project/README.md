# Qwen CBM Two-Phase Linear Head Trials

This revision makes the final linear head **two-phase** rather than end-to-end.

## Answer to your question

Yes — the four trials are **phase 2** training, not end-to-end joint training for the final head.

Pipeline:

1. **Phase 1:** train the text → concept predictor and save:
   - `predicted_concepts_train.npy`
   - `predicted_concepts_val.npy`
   - `predicted_concepts_test.npy`
   - prediction CSVs with true labels

2. **Phase 2:** fit four post-hoc linear/logistic heads on the saved predicted concepts.

This keeps the final map directly from concepts to labels:

$$
z = W \hat c + b
$$

so the model stays interpretable.

## Storage efficiency

This revision saves:
- arrays as `.npy`
- metrics/configs as `.json`
- coefficients/tables as `.csv`

It does **not** duplicate the same object into both `.csv` and `.npy` by default.

## Four trials

1. `balanced_l2`
2. `balanced_l1`
3. `balanced_elasticnet`
4. `manual_elasticnet`

Selection is based on **validation macro-F1**.

## Command

```bash
python run_logreg_trials.py \
  --run_dir /mnt/disk1/wbjtu/tzbjtu/somental/qwen_cbm/outputs/run_gpu0123_3ep \
  --output_dir /mnt/disk1/wbjtu/tzbjtu/somental/qwen_cbm/outputs/run_gpu0123_3ep/logreg_trials \
  --manual_class_weights '{"Indicator":1.0,"Ideation":1.2,"Attempt":1.5,"Behavior":1.5}'
```
