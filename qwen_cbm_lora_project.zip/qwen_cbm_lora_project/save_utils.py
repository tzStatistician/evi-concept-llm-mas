from __future__ import annotations

import os
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import torch

from utils import ensure_dir, save_json, to_serializable



def save_metrics(metrics: Dict, output_dir: str, filename: str) -> None:
    ensure_dir(output_dir)
    save_json(to_serializable(metrics), os.path.join(output_dir, filename))



def save_predictions_csv(
    output_path: str,
    row_indices: np.ndarray,
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: List[str],
    concept_cols: List[str],
    pred_concepts: np.ndarray,
    gold_concepts: np.ndarray,
    sample_ids: Optional[List[str]] = None,
) -> None:
    data = {
        "row_idx": row_indices.astype(int),
        "gold_label_id": y_true.astype(int),
        "pred_label_id": y_pred.astype(int),
        "gold_label_name": [class_names[int(v)] for v in y_true],
        "pred_label_name": [class_names[int(v)] for v in y_pred],
    }
    if sample_ids is not None and any(v is not None for v in sample_ids):
        data["sample_id"] = sample_ids

    for j, col in enumerate(concept_cols):
        data[f"gold__{col}"] = gold_concepts[:, j]
        data[f"pred__{col}"] = pred_concepts[:, j]

    df = pd.DataFrame(data)
    df.to_csv(output_path, index=False)



def save_linear_head(linear_layer: torch.nn.Linear, concept_cols: List[str], class_names: List[str], output_dir: str) -> None:
    ensure_dir(output_dir)
    weight = linear_layer.weight.detach().cpu().numpy()
    bias = linear_layer.bias.detach().cpu().numpy()

    np.save(os.path.join(output_dir, "linear_weight.npy"), weight)
    np.save(os.path.join(output_dir, "linear_bias.npy"), bias)

    weight_df = pd.DataFrame(weight, index=class_names, columns=concept_cols)
    weight_df.to_csv(os.path.join(output_dir, "linear_weight.csv"))

    bias_df = pd.DataFrame({"class_name": class_names, "bias": bias})
    bias_df.to_csv(os.path.join(output_dir, "linear_bias.csv"), index=False)



def save_training_history(history: Dict, output_dir: str) -> None:
    save_json(to_serializable(history), os.path.join(output_dir, "training_history.json"))
