from __future__ import annotations

import os
from typing import Dict, List, Tuple

import numpy as np
import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader
from tqdm.auto import tqdm
from transformers import get_linear_schedule_with_warmup

from config import TrainConfig
from data_utils import ConceptTextDataset, DataCollatorForConceptText, DatasetBundle
from eval_utils import compute_classification_metrics
from losses import build_total_loss
from save_utils import save_linear_head, save_metrics, save_predictions_csv, save_training_history
from utils import ensure_dir



def build_dataloaders(bundle: DatasetBundle, tokenizer, cfg: TrainConfig):
    collator = DataCollatorForConceptText(tokenizer)
    train_ds = ConceptTextDataset(
        bundle.train_df,
        tokenizer,
        cfg.text_col,
        cfg.label_col,
        bundle.concept_cols,
        cfg.max_length,
        split_name="train",
        id_col=cfg.id_col,
    )
    val_ds = ConceptTextDataset(
        bundle.val_df,
        tokenizer,
        cfg.text_col,
        cfg.label_col,
        bundle.concept_cols,
        cfg.max_length,
        split_name="val",
        id_col=cfg.id_col,
    )
    test_ds = ConceptTextDataset(
        bundle.test_df,
        tokenizer,
        cfg.text_col,
        cfg.label_col,
        bundle.concept_cols,
        cfg.max_length,
        split_name="test",
        id_col=cfg.id_col,
    )

    train_loader = DataLoader(
        train_ds,
        batch_size=cfg.train_batch_size,
        shuffle=True,
        num_workers=cfg.num_workers,
        pin_memory=cfg.pin_memory,
        collate_fn=collator,
    )
    eval_kwargs = dict(
        batch_size=cfg.eval_batch_size,
        shuffle=False,
        num_workers=cfg.num_workers,
        pin_memory=cfg.pin_memory,
        collate_fn=collator,
    )
    val_loader = DataLoader(val_ds, **eval_kwargs)
    test_loader = DataLoader(test_ds, **eval_kwargs)
    return train_loader, val_loader, test_loader



def _move_batch_to_device(batch: Dict, device: torch.device) -> Dict:
    out = {}
    for k, v in batch.items():
        if isinstance(v, torch.Tensor):
            out[k] = v.to(device)
        else:
            out[k] = v
    return out



def _get_trainable_param_groups(model: torch.nn.Module, cfg: TrainConfig):
    lora_params: List[torch.nn.Parameter] = []
    head_params: List[torch.nn.Parameter] = []
    head_keywords = ["concept_head", "linear_predictor"]

    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if any(k in name for k in head_keywords):
            head_params.append(p)
        else:
            lora_params.append(p)

    param_groups = []
    if lora_params:
        param_groups.append({"params": lora_params, "lr": cfg.lr_lora, "weight_decay": cfg.weight_decay})
    if head_params:
        param_groups.append({"params": head_params, "lr": cfg.lr_heads, "weight_decay": cfg.weight_decay})
    return param_groups


@torch.no_grad()
def predict(model: torch.nn.Module, data_loader: DataLoader, device: torch.device, class_names: List[str]) -> Tuple[Dict, Dict]:
    model.eval()
    all_logits = []
    all_y = []
    all_pred_concepts = []
    all_gold_concepts = []
    all_row_idx = []
    all_sample_ids: List[str] = []

    for batch in tqdm(data_loader, desc="Predict", leave=False):
        batch = _move_batch_to_device(batch, device)
        outputs = model(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"])
        logits = outputs["logits"].detach().float().cpu().numpy()
        pred_concepts = outputs["pred_concepts"].detach().float().cpu().numpy()

        all_logits.append(logits)
        all_y.append(batch["labels"].detach().cpu().numpy())
        all_pred_concepts.append(pred_concepts)
        all_gold_concepts.append(batch["concept_targets"].detach().cpu().numpy())
        all_row_idx.append(batch["row_idx"].detach().cpu().numpy())
        if "sample_ids" in batch:
            all_sample_ids.extend(batch["sample_ids"])

    logits = np.concatenate(all_logits, axis=0)
    y_true = np.concatenate(all_y, axis=0)
    y_pred = logits.argmax(axis=1)
    pred_concepts = np.concatenate(all_pred_concepts, axis=0)
    gold_concepts = np.concatenate(all_gold_concepts, axis=0)
    row_idx = np.concatenate(all_row_idx, axis=0)

    metrics = compute_classification_metrics(y_true, y_pred, class_names)
    payload = {
        "row_idx": row_idx,
        "y_true": y_true,
        "y_pred": y_pred,
        "logits": logits,
        "pred_concepts": pred_concepts,
        "gold_concepts": gold_concepts,
        "sample_ids": all_sample_ids if all_sample_ids else None,
    }
    return metrics, payload



def train_model(model: torch.nn.Module, tokenizer, bundle: DatasetBundle, cfg: TrainConfig, output_dir: str) -> None:
    ensure_dir(output_dir)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if cfg.load_in_4bit and torch.cuda.is_available():
        model.concept_head.to(device)
        model.linear_predictor.to(device)
    else:
        model.to(device)

    train_loader, val_loader, test_loader = build_dataloaders(bundle, tokenizer, cfg)
    class_weights = torch.tensor(bundle.class_weights, dtype=torch.float32, device=device)

    optimizer = AdamW(_get_trainable_param_groups(model, cfg))
    total_steps = (len(train_loader) * cfg.num_epochs + cfg.gradient_accumulation_steps - 1) // cfg.gradient_accumulation_steps
    warmup_steps = int(total_steps * cfg.warmup_ratio)
    scheduler = get_linear_schedule_with_warmup(optimizer, warmup_steps, total_steps)

    best_metric = -float("inf") if cfg.greater_is_better else float("inf")
    best_ckpt_dir = os.path.join(output_dir, "best_checkpoint")
    history = {"epochs": []}

    amp_dtype = torch.bfloat16 if cfg.use_bf16 and torch.cuda.is_available() else torch.float16

    for epoch in range(1, cfg.num_epochs + 1):
        model.train()
        running = {"loss": 0.0, "concept_loss": 0.0, "label_loss": 0.0, "sparsity_loss": 0.0}
        optimizer.zero_grad(set_to_none=True)

        pbar = tqdm(train_loader, desc=f"Epoch {epoch}/{cfg.num_epochs}")
        for step, batch in enumerate(pbar, start=1):
            batch = _move_batch_to_device(batch, device)
            with torch.autocast(device_type="cuda", dtype=amp_dtype, enabled=torch.cuda.is_available()):
                outputs = model(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"])
                outputs["linear_weight"] = model.linear_predictor.weight
                loss_dict = build_total_loss(
                    outputs=outputs,
                    concept_targets=batch["concept_targets"],
                    labels=batch["labels"],
                    class_weights=class_weights,
                    lambda_label=cfg.lambda_label,
                    l1_lambda=cfg.l1_lambda,
                    concept_loss_type=cfg.concept_loss_type,
                    label_smoothing=cfg.label_smoothing,
                )
                loss = loss_dict["loss"] / cfg.gradient_accumulation_steps

            loss.backward()

            if step % cfg.gradient_accumulation_steps == 0 or step == len(train_loader):
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.max_grad_norm)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad(set_to_none=True)

            running["loss"] += float(loss_dict["loss"].item())
            running["concept_loss"] += float(loss_dict["concept_loss"].item())
            running["label_loss"] += float(loss_dict["label_loss"].item())
            running["sparsity_loss"] += float(loss_dict["sparsity_loss"].item())

            avg_loss = running["loss"] / step
            avg_concept = running["concept_loss"] / step
            avg_label = running["label_loss"] / step
            pbar.set_postfix(loss=f"{avg_loss:.4f}", concept=f"{avg_concept:.4f}", label=f"{avg_label:.4f}")

        train_summary = {k: v / max(len(train_loader), 1) for k, v in running.items()}
        val_metrics, _ = predict(model, val_loader, device, bundle.label_encoder.classes_.tolist())
        current_metric = val_metrics[cfg.metric_for_best_model]

        epoch_record = {
            "epoch": epoch,
            "train": train_summary,
            "val": val_metrics,
            "lr_last": scheduler.get_last_lr(),
        }
        history["epochs"].append(epoch_record)
        save_training_history(history, output_dir)
        save_metrics(val_metrics, output_dir, f"metrics_val_epoch{epoch}.json")

        is_better = current_metric > best_metric if cfg.greater_is_better else current_metric < best_metric
        if is_better:
            best_metric = current_metric
            ensure_dir(best_ckpt_dir)
            torch.save(model.state_dict(), os.path.join(best_ckpt_dir, "model_state.pt"))
            model.backbone.save_pretrained(os.path.join(best_ckpt_dir, "lora_adapter"))
            tokenizer.save_pretrained(os.path.join(best_ckpt_dir, "tokenizer"))
            save_linear_head(model.linear_predictor, bundle.concept_cols, bundle.label_encoder.classes_.tolist(), best_ckpt_dir)

        if cfg.save_every_epoch:
            epoch_dir = os.path.join(output_dir, f"epoch_{epoch}")
            ensure_dir(epoch_dir)
            torch.save(model.state_dict(), os.path.join(epoch_dir, "model_state.pt"))
            save_linear_head(model.linear_predictor, bundle.concept_cols, bundle.label_encoder.classes_.tolist(), epoch_dir)

    # reload best checkpoint before final evaluation
    best_state_path = os.path.join(best_ckpt_dir, "model_state.pt")
    model.load_state_dict(torch.load(best_state_path, map_location=device))

    split_to_loader = {
        "train": train_loader,
        "val": val_loader,
        "test": test_loader,
    }
    split_save_flags = {
        "train": cfg.save_train_predictions,
        "val": cfg.save_val_predictions,
        "test": cfg.save_test_predictions,
    }

    final_metrics = {}
    for split_name, loader in split_to_loader.items():
        metrics, payload = predict(model, loader, device, bundle.label_encoder.classes_.tolist())
        final_metrics[split_name] = metrics
        save_metrics(metrics, output_dir, f"metrics_{split_name}.json")
        if split_save_flags[split_name]:
            save_predictions_csv(
                output_path=os.path.join(output_dir, f"predictions_{split_name}.csv"),
                row_indices=payload["row_idx"],
                y_true=payload["y_true"],
                y_pred=payload["y_pred"],
                class_names=bundle.label_encoder.classes_.tolist(),
                concept_cols=bundle.concept_cols,
                pred_concepts=payload["pred_concepts"],
                gold_concepts=payload["gold_concepts"],
                sample_ids=payload["sample_ids"],
            )
            np.save(os.path.join(output_dir, f"predicted_concepts_{split_name}.npy"), payload["pred_concepts"])
            np.save(os.path.join(output_dir, f"gold_concepts_{split_name}.npy"), payload["gold_concepts"])
            np.save(os.path.join(output_dir, f"logits_{split_name}.npy"), payload["logits"])
            np.save(os.path.join(output_dir, f"row_idx_{split_name}.npy"), payload["row_idx"])

    save_metrics(final_metrics, output_dir, "metrics_all_splits.json")
    save_linear_head(model.linear_predictor, bundle.concept_cols, bundle.label_encoder.classes_.tolist(), output_dir)
    model.backbone.save_pretrained(os.path.join(output_dir, "final_lora_adapter"))
    tokenizer.save_pretrained(os.path.join(output_dir, "final_tokenizer"))
    torch.save(model.state_dict(), os.path.join(output_dir, "final_model_state.pt"))
