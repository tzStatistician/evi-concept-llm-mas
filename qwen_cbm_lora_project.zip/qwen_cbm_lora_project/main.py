from __future__ import annotations

import argparse
import os
from dataclasses import asdict

from config import TrainConfig
from data_utils import load_and_prepare_data, save_preprocessing_artifacts
from model import build_model_and_tokenizer
from train import train_model
from utils import ensure_dir, save_json, set_seed



def parse_args() -> TrainConfig:
    parser = argparse.ArgumentParser(description="End-to-end QLoRA Concept Bottleneck training for text -> concepts -> sparse linear labels")

    # Required / common
    parser.add_argument("--csv_path", type=str, required=True)
    parser.add_argument("--text_col", type=str, default="text")
    parser.add_argument("--label_col", type=str, default="label")
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument("--model_name_or_path", type=str, required=True)

    # Data
    parser.add_argument("--concept_suffix", type=str, default="__calibrated")
    parser.add_argument("--id_col", type=str, default=None)
    parser.add_argument("--train_size", type=float, default=0.8)
    parser.add_argument("--val_size", type=float, default=0.1)
    parser.add_argument("--test_size", type=float, default=0.1)
    parser.add_argument("--random_seed", type=int, default=42)
    parser.add_argument("--max_length", type=int, default=512)
    parser.add_argument("--pooling", type=str, default="last_non_pad")
    parser.add_argument("--concept_hidden_dim", type=int, default=0)
    parser.add_argument("--dropout", type=float, default=0.1)

    # LoRA / quantization
    parser.add_argument("--load_in_4bit", action="store_true")
    parser.add_argument("--lora_r", type=int, default=16)
    parser.add_argument("--lora_alpha", type=int, default=32)
    parser.add_argument("--lora_dropout", type=float, default=0.05)
    parser.add_argument("--lora_target_modules", type=str, default="q_proj,k_proj,v_proj,o_proj,up_proj,down_proj,gate_proj")
    parser.add_argument("--bnb_4bit_quant_type", type=str, default="nf4")
    parser.add_argument("--bnb_4bit_compute_dtype", type=str, default="bfloat16")
    parser.add_argument("--bnb_4bit_use_double_quant", action="store_true")

    # Optimization
    parser.add_argument("--num_epochs", type=int, default=5)
    parser.add_argument("--train_batch_size", type=int, default=2)
    parser.add_argument("--eval_batch_size", type=int, default=4)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=8)
    parser.add_argument("--lr_lora", type=float, default=2e-4)
    parser.add_argument("--lr_heads", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=0.01)
    parser.add_argument("--warmup_ratio", type=float, default=0.05)
    parser.add_argument("--max_grad_norm", type=float, default=1.0)

    # Losses
    parser.add_argument("--lambda_label", type=float, default=0.1, help="Default 0.1 because prior runs showed label loss is roughly 10x concept loss.")
    parser.add_argument("--l1_lambda", type=float, default=1e-4)
    parser.add_argument("--concept_loss_type", type=str, default="mse")
    parser.add_argument("--class_weight_mode", type=str, default="balanced")
    parser.add_argument("--label_smoothing", type=float, default=0.0)

    # Concept preprocessing
    parser.add_argument("--standardize_concepts", action="store_true")
    parser.add_argument("--clip_concepts", action="store_true")
    parser.add_argument("--concept_clip_min", type=float, default=-5.0)
    parser.add_argument("--concept_clip_max", type=float, default=5.0)

    # Runtime / save
    parser.add_argument("--use_bf16", action="store_true")
    parser.add_argument("--save_every_epoch", action="store_true")
    parser.add_argument("--metric_for_best_model", type=str, default="macro_f1")
    parser.add_argument("--num_workers", type=int, default=2)
    parser.add_argument("--pin_memory", action="store_true")
    parser.add_argument("--save_train_predictions", action="store_true")
    parser.add_argument("--save_val_predictions", action="store_true")
    parser.add_argument("--save_test_predictions", action="store_true")

    args = parser.parse_args()
    cfg = TrainConfig(
        csv_path=args.csv_path,
        text_col=args.text_col,
        label_col=args.label_col,
        output_dir=args.output_dir,
        concept_suffix=args.concept_suffix,
        id_col=args.id_col,
        train_size=args.train_size,
        val_size=args.val_size,
        test_size=args.test_size,
        random_seed=args.random_seed,
        model_name_or_path=args.model_name_or_path,
        max_length=args.max_length,
        pooling=args.pooling,
        concept_hidden_dim=args.concept_hidden_dim,
        dropout=args.dropout,
        load_in_4bit=args.load_in_4bit,
        lora_r=args.lora_r,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        lora_target_modules=args.lora_target_modules,
        bnb_4bit_quant_type=args.bnb_4bit_quant_type,
        bnb_4bit_compute_dtype=args.bnb_4bit_compute_dtype,
        bnb_4bit_use_double_quant=args.bnb_4bit_use_double_quant,
        num_epochs=args.num_epochs,
        train_batch_size=args.train_batch_size,
        eval_batch_size=args.eval_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        lr_lora=args.lr_lora,
        lr_heads=args.lr_heads,
        weight_decay=args.weight_decay,
        warmup_ratio=args.warmup_ratio,
        max_grad_norm=args.max_grad_norm,
        lambda_label=args.lambda_label,
        l1_lambda=args.l1_lambda,
        concept_loss_type=args.concept_loss_type,
        class_weight_mode=args.class_weight_mode,
        label_smoothing=args.label_smoothing,
        standardize_concepts=args.standardize_concepts,
        clip_concepts=args.clip_concepts,
        concept_clip_min=args.concept_clip_min,
        concept_clip_max=args.concept_clip_max,
        use_bf16=args.use_bf16,
        save_every_epoch=args.save_every_epoch,
        metric_for_best_model=args.metric_for_best_model,
        num_workers=args.num_workers,
        pin_memory=args.pin_memory,
        save_train_predictions=args.save_train_predictions,
        save_val_predictions=args.save_val_predictions,
        save_test_predictions=args.save_test_predictions,
    )
    cfg.validate()
    return cfg



def main() -> None:
    cfg = parse_args()
    ensure_dir(cfg.output_dir)
    set_seed(cfg.random_seed)
    save_json(asdict(cfg), os.path.join(cfg.output_dir, "run_config.json"))

    bundle = load_and_prepare_data(cfg)
    save_preprocessing_artifacts(bundle, cfg.output_dir)

    model, tokenizer = build_model_and_tokenizer(
        cfg,
        num_concepts=len(bundle.concept_cols),
        num_classes=len(bundle.label_encoder.classes_),
    )
    train_model(model, tokenizer, bundle, cfg, cfg.output_dir)


if __name__ == "__main__":
    main()
