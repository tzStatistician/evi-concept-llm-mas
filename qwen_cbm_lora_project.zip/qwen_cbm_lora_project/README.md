# End-to-end QLoRA Concept Bottleneck for Text Classification

This project trains:

```text
text -> Qwen-3.5-9B (QLoRA) -> concept layer -> sparse linear predictor -> label
```

It is designed for a CSV where:
- the input text is in `text_col`
- the label is in `label_col`
- concept targets are all columns ending with `__calibrated`

## Method choices in this code

- **End-to-end LoRA / QLoRA** training
- **Concept regression** loss on all `__calibrated` concept columns
- **Weighted cross-entropy** for imbalanced labels
- **L1 penalty** on the final linear concept-to-label predictor for sparsity
- Default `lambda_label = 0.1`, motivated by prior observation that label loss was about 10x the concept loss

## Saved artifacts

Under `output_dir`, this code saves:

- `run_config.json`
- `data_metadata.json`
- `label_mapping.json`
- `concept_scaler.json` (if concept standardization is enabled)
- `training_history.json`
- `metrics_train.json`, `metrics_val.json`, `metrics_test.json`
- `metrics_all_splits.json`
- `predictions_train.csv`, `predictions_val.csv`, `predictions_test.csv` (when enabled)
- `predicted_concepts_*.npy`
- `gold_concepts_*.npy`
- `logits_*.npy`
- `linear_weight.npy`, `linear_weight.csv`
- `linear_bias.npy`, `linear_bias.csv`
- `final_model_state.pt`
- `final_lora_adapter/`
- `final_tokenizer/`
- `best_checkpoint/`

## Recommended run command

```bash
python main.py \
  --csv_path /mnt/disk1/wbjtu/tzbjtu/somental/data/rsd15_evidence_aware_concepts72_cleaned.csv \
  --text_col text \
  --label_col label \
  --model_name_or_path /path/to/Qwen3.5-9B \
  --output_dir /mnt/disk1/wbjtu/tzbjtu/somental/models/qwen9b_cbm_lora_rsd15k \
  --load_in_4bit \
  --bnb_4bit_use_double_quant \
  --standardize_concepts \
  --use_bf16 \
  --pin_memory \
  --save_every_epoch \
  --save_train_predictions \
  --save_val_predictions \
  --save_test_predictions \
  --num_epochs 5 \
  --train_batch_size 2 \
  --eval_batch_size 4 \
  --gradient_accumulation_steps 8 \
  --max_length 512 \
  --lambda_label 0.1 \
  --l1_lambda 1e-4 \
  --lr_lora 2e-4 \
  --lr_heads 1e-3
```

## Notes

1. If your label column is named `sentiment` instead of `label`, pass `--label_col sentiment`.
2. If your text is longer, increase `--max_length`, but memory use will rise quickly.
3. `macro_f1` is used to select the best checkpoint by default.
4. The final sparse head is a standard `nn.Linear(num_concepts, num_classes)` with L1 regularization.
5. For very imbalanced data, keep `class_weight_mode=balanced` unless you have evidence another weighting works better.
