from __future__ import annotations

from typing import Dict

import torch
import torch.nn.functional as F


def concept_regression_loss(pred: torch.Tensor, target: torch.Tensor, loss_type: str = "mse") -> torch.Tensor:
    if loss_type == "mse":
        return F.mse_loss(pred, target)
    if loss_type == "mae":
        return F.l1_loss(pred, target)
    if loss_type == "huber":
        return F.smooth_l1_loss(pred, target)
    raise ValueError(f"Unsupported concept loss type: {loss_type}")


def weighted_label_loss(
    logits: torch.Tensor,
    labels: torch.Tensor,
    class_weights: torch.Tensor,
    label_smoothing: float = 0.0,
) -> torch.Tensor:
    return F.cross_entropy(
        logits,
        labels,
        weight=class_weights,
        label_smoothing=label_smoothing,
    )


def l1_penalty(weight: torch.Tensor) -> torch.Tensor:
    return weight.abs().sum()


def build_total_loss(
    outputs: Dict[str, torch.Tensor],
    concept_targets: torch.Tensor,
    labels: torch.Tensor,
    class_weights: torch.Tensor,
    lambda_label: float,
    l1_lambda: float,
    concept_loss_type: str,
    label_smoothing: float,
) -> Dict[str, torch.Tensor]:
    c_loss = concept_regression_loss(outputs["pred_concepts"], concept_targets, loss_type=concept_loss_type)
    y_loss = weighted_label_loss(outputs["logits"], labels, class_weights, label_smoothing=label_smoothing)
    sparse_loss = l1_penalty(outputs["linear_weight"])
    total = c_loss + lambda_label * y_loss + l1_lambda * sparse_loss
    return {
        "loss": total,
        "concept_loss": c_loss.detach(),
        "label_loss": y_loss.detach(),
        "sparsity_loss": sparse_loss.detach(),
    }
