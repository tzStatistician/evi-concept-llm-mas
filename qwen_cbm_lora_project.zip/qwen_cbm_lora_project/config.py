from dataclasses import dataclass, field
from typing import Optional


@dataclass
class TrainConfig:
    # Data
    csv_path: str
    text_col: str = "text"
    label_col: str = "label"
    output_dir: str = "./outputs_qwen_cbm_lora"
    concept_suffix: str = "__calibrated"
    id_col: Optional[str] = None
    train_size: float = 0.8
    val_size: float = 0.1
    test_size: float = 0.1
    random_seed: int = 42

    # Model
    model_name_or_path: str = "Qwen/Qwen3-9B"
    max_length: int = 512
    pooling: str = "last_non_pad"  # last_non_pad | mean
    concept_hidden_dim: int = 0  # 0 => single linear head
    dropout: float = 0.1

    # QLoRA / LoRA
    load_in_4bit: bool = True
    lora_r: int = 16
    lora_alpha: int = 32
    lora_dropout: float = 0.05
    lora_target_modules: str = "q_proj,k_proj,v_proj,o_proj,up_proj,down_proj,gate_proj"
    bnb_4bit_quant_type: str = "nf4"
    bnb_4bit_compute_dtype: str = "bfloat16"  # bfloat16 | float16
    bnb_4bit_use_double_quant: bool = True

    # Optimization
    num_epochs: int = 5
    train_batch_size: int = 2
    eval_batch_size: int = 4
    gradient_accumulation_steps: int = 8
    lr_lora: float = 2e-4
    lr_heads: float = 1e-3
    weight_decay: float = 0.01
    warmup_ratio: float = 0.05
    max_grad_norm: float = 1.0

    # Losses
    lambda_label: float = 0.1
    l1_lambda: float = 1e-4
    concept_loss_type: str = "mse"  # mse | huber | mae
    class_weight_mode: str = "balanced"  # balanced | inverse_sqrt | none
    label_smoothing: float = 0.0

    # Concept preprocessing
    standardize_concepts: bool = True
    clip_concepts: bool = False
    concept_clip_min: float = -5.0
    concept_clip_max: float = 5.0

    # Runtime / checkpointing
    use_bf16: bool = True
    save_every_epoch: bool = True
    metric_for_best_model: str = "macro_f1"
    greater_is_better: bool = True
    num_workers: int = 2
    pin_memory: bool = True

    # Evaluation / save
    save_train_predictions: bool = True
    save_val_predictions: bool = True
    save_test_predictions: bool = True

    def validate(self) -> None:
        total = self.train_size + self.val_size + self.test_size
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"train/val/test sizes must sum to 1.0, got {total}")
        if self.pooling not in {"last_non_pad", "mean"}:
            raise ValueError("pooling must be one of {'last_non_pad', 'mean'}")
        if self.concept_loss_type not in {"mse", "huber", "mae"}:
            raise ValueError("concept_loss_type must be one of {'mse', 'huber', 'mae'}")
        if self.class_weight_mode not in {"balanced", "inverse_sqrt", "none"}:
            raise ValueError("class_weight_mode must be one of {'balanced', 'inverse_sqrt', 'none'}")
