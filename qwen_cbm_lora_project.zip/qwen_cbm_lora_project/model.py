from __future__ import annotations

from typing import Dict, List, Optional

import torch
import torch.nn as nn
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

from config import TrainConfig
from utils import get_torch_dtype


class ConceptHead(nn.Module):
    def __init__(self, in_dim: int, out_dim: int, hidden_dim: int = 0, dropout: float = 0.1):
        super().__init__()
        if hidden_dim and hidden_dim > 0:
            self.net = nn.Sequential(
                nn.Linear(in_dim, hidden_dim),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_dim, out_dim),
            )
        else:
            self.net = nn.Linear(in_dim, out_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class EndToEndConceptBottleneckModel(nn.Module):
    def __init__(self, backbone: nn.Module, hidden_size: int, num_concepts: int, num_classes: int, cfg: TrainConfig):
        super().__init__()
        self.backbone = backbone
        self.cfg = cfg
        self.dropout = nn.Dropout(cfg.dropout)
        self.concept_head = ConceptHead(
            in_dim=hidden_size,
            out_dim=num_concepts,
            hidden_dim=cfg.concept_hidden_dim,
            dropout=cfg.dropout,
        )
        self.linear_predictor = nn.Linear(num_concepts, num_classes)

    def _pool_hidden(self, hidden_states: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        if self.cfg.pooling == "mean":
            mask = attention_mask.unsqueeze(-1).to(hidden_states.dtype)
            summed = (hidden_states * mask).sum(dim=1)
            denom = mask.sum(dim=1).clamp_min(1e-6)
            return summed / denom

        # last_non_pad
        seq_lengths = attention_mask.long().sum(dim=1) - 1
        seq_lengths = seq_lengths.clamp_min(0)
        batch_idx = torch.arange(hidden_states.size(0), device=hidden_states.device)
        return hidden_states[batch_idx, seq_lengths]

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        outputs = self.backbone(
            input_ids=input_ids,
            attention_mask=attention_mask,
            output_hidden_states=True,
            return_dict=True,
        )
        last_hidden = outputs.hidden_states[-1]
        pooled = self._pool_hidden(last_hidden, attention_mask)
        pooled = self.dropout(pooled)
        pred_concepts = self.concept_head(pooled)
        logits = self.linear_predictor(pred_concepts)
        return {
            "pooled": pooled,
            "pred_concepts": pred_concepts,
            "logits": logits,
        }


def build_tokenizer(cfg: TrainConfig):
    tokenizer = AutoTokenizer.from_pretrained(cfg.model_name_or_path, use_fast=True, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"
    return tokenizer


def build_backbone_with_lora(cfg: TrainConfig):
    quant_config = None
    if cfg.load_in_4bit:
        quant_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type=cfg.bnb_4bit_quant_type,
            bnb_4bit_compute_dtype=get_torch_dtype(cfg.bnb_4bit_compute_dtype),
            bnb_4bit_use_double_quant=cfg.bnb_4bit_use_double_quant,
        )

    device_map = {"": 0} if (cfg.load_in_4bit and torch.cuda.is_available()) else None
    backbone = AutoModelForCausalLM.from_pretrained(
        cfg.model_name_or_path,
        quantization_config=quant_config,
        trust_remote_code=True,
        torch_dtype=get_torch_dtype(cfg.bnb_4bit_compute_dtype),
        device_map=device_map,
    )
    backbone.config.use_cache = False
    backbone.gradient_checkpointing_enable()
    backbone = prepare_model_for_kbit_training(backbone)

    lora_targets: List[str] = [m.strip() for m in cfg.lora_target_modules.split(",") if m.strip()]
    peft_config = LoraConfig(
        r=cfg.lora_r,
        lora_alpha=cfg.lora_alpha,
        lora_dropout=cfg.lora_dropout,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=lora_targets,
    )
    backbone = get_peft_model(backbone, peft_config)
    return backbone


def build_model_and_tokenizer(cfg: TrainConfig, num_concepts: int, num_classes: int):
    tokenizer = build_tokenizer(cfg)
    backbone = build_backbone_with_lora(cfg)
    hidden_size = backbone.config.hidden_size
    model = EndToEndConceptBottleneckModel(
        backbone=backbone,
        hidden_size=hidden_size,
        num_concepts=num_concepts,
        num_classes=num_classes,
        cfg=cfg,
    )
    return model, tokenizer
