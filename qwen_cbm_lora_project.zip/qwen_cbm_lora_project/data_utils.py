from __future__ import annotations

from dataclasses import asdict
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from torch.utils.data import Dataset

from config import TrainConfig
from utils import save_json, to_serializable


class ConceptTextDataset(Dataset):
    def __init__(
        self,
        df: pd.DataFrame,
        tokenizer,
        text_col: str,
        label_col: str,
        concept_cols: List[str],
        max_length: int,
        split_name: str,
        id_col: str | None = None,
    ) -> None:
        self.df = df.reset_index(drop=True).copy()
        self.tokenizer = tokenizer
        self.text_col = text_col
        self.label_col = label_col
        self.concept_cols = concept_cols
        self.max_length = max_length
        self.split_name = split_name
        self.id_col = id_col

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        row = self.df.iloc[idx]
        text = str(row[self.text_col])
        enc = self.tokenizer(
            text,
            truncation=True,
            max_length=self.max_length,
            padding=False,
            return_tensors=None,
        )
        item = {
            "input_ids": torch.tensor(enc["input_ids"], dtype=torch.long),
            "attention_mask": torch.tensor(enc["attention_mask"], dtype=torch.long),
            "labels": torch.tensor(int(row[self.label_col]), dtype=torch.long),
            "concept_targets": torch.tensor(row[self.concept_cols].astype(float).values, dtype=torch.float32),
            "row_idx": torch.tensor(int(row["__row_idx__"]), dtype=torch.long),
        }
        if self.id_col is not None:
            item["sample_id"] = str(row[self.id_col])
        return item


class DataCollatorForConceptText:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def __call__(self, features: List[Dict]) -> Dict[str, torch.Tensor]:
        sample_ids = [f.pop("sample_id", None) for f in features]
        batch = self.tokenizer.pad(features, padding=True, return_tensors="pt")
        if any(s is not None for s in sample_ids):
            batch["sample_ids"] = sample_ids
        return batch


class DatasetBundle:
    def __init__(
        self,
        train_df: pd.DataFrame,
        val_df: pd.DataFrame,
        test_df: pd.DataFrame,
        concept_cols: List[str],
        label_encoder: LabelEncoder,
        concept_scaler: StandardScaler | None,
        class_weights: np.ndarray,
        metadata: Dict,
    ) -> None:
        self.train_df = train_df
        self.val_df = val_df
        self.test_df = test_df
        self.concept_cols = concept_cols
        self.label_encoder = label_encoder
        self.concept_scaler = concept_scaler
        self.class_weights = class_weights
        self.metadata = metadata


def compute_class_weights(y_train: np.ndarray, num_classes: int, mode: str) -> np.ndarray:
    counts = np.bincount(y_train, minlength=num_classes).astype(np.float64)
    counts[counts == 0.0] = 1.0
    if mode == "balanced":
        weights = len(y_train) / (num_classes * counts)
    elif mode == "inverse_sqrt":
        weights = 1.0 / np.sqrt(counts)
        weights = weights / weights.mean()
    elif mode == "none":
        weights = np.ones(num_classes, dtype=np.float64)
    else:
        raise ValueError(f"Unsupported class_weight_mode: {mode}")
    return weights.astype(np.float32)


def load_and_prepare_data(cfg: TrainConfig) -> DatasetBundle:
    df = pd.read_csv(cfg.csv_path)
    if cfg.text_col not in df.columns:
        raise ValueError(f"text_col '{cfg.text_col}' not in CSV")
    if cfg.label_col not in df.columns:
        raise ValueError(f"label_col '{cfg.label_col}' not in CSV")

    concept_cols = [c for c in df.columns if c.endswith(cfg.concept_suffix)]
    if not concept_cols:
        raise ValueError(f"No concept columns found with suffix '{cfg.concept_suffix}'")

    required_cols = [cfg.text_col, cfg.label_col] + concept_cols
    keep_cols = required_cols + ([cfg.id_col] if cfg.id_col and cfg.id_col in df.columns else [])
    df = df[keep_cols].copy()
    df = df.dropna(subset=[cfg.text_col, cfg.label_col] + concept_cols).reset_index(drop=True)
    df["__row_idx__"] = np.arange(len(df))

    label_encoder = LabelEncoder()
    df[cfg.label_col] = label_encoder.fit_transform(df[cfg.label_col].astype(str).values)

    train_df, temp_df = train_test_split(
        df,
        train_size=cfg.train_size,
        stratify=df[cfg.label_col],
        random_state=cfg.random_seed,
    )
    relative_val = cfg.val_size / (cfg.val_size + cfg.test_size)
    val_df, test_df = train_test_split(
        temp_df,
        train_size=relative_val,
        stratify=temp_df[cfg.label_col],
        random_state=cfg.random_seed,
    )

    concept_scaler = None
    if cfg.standardize_concepts:
        concept_scaler = StandardScaler()
        train_df.loc[:, concept_cols] = concept_scaler.fit_transform(train_df[concept_cols].values)
        val_df.loc[:, concept_cols] = concept_scaler.transform(val_df[concept_cols].values)
        test_df.loc[:, concept_cols] = concept_scaler.transform(test_df[concept_cols].values)

    if cfg.clip_concepts:
        for split_df in (train_df, val_df, test_df):
            split_df.loc[:, concept_cols] = split_df[concept_cols].clip(
                lower=cfg.concept_clip_min,
                upper=cfg.concept_clip_max,
            )

    y_train = train_df[cfg.label_col].values.astype(int)
    class_weights = compute_class_weights(y_train, len(label_encoder.classes_), cfg.class_weight_mode)

    metadata = {
        "config": asdict(cfg),
        "num_samples": len(df),
        "num_train": len(train_df),
        "num_val": len(val_df),
        "num_test": len(test_df),
        "num_classes": len(label_encoder.classes_),
        "class_names": label_encoder.classes_.tolist(),
        "concept_cols": concept_cols,
        "class_weights": class_weights.tolist(),
        "train_class_counts": np.bincount(y_train, minlength=len(label_encoder.classes_)).tolist(),
        "split_row_indices": {
            "train": train_df["__row_idx__"].tolist(),
            "val": val_df["__row_idx__"].tolist(),
            "test": test_df["__row_idx__"].tolist(),
        },
    }

    return DatasetBundle(
        train_df=train_df.reset_index(drop=True),
        val_df=val_df.reset_index(drop=True),
        test_df=test_df.reset_index(drop=True),
        concept_cols=concept_cols,
        label_encoder=label_encoder,
        concept_scaler=concept_scaler,
        class_weights=class_weights,
        metadata=metadata,
    )


def save_preprocessing_artifacts(bundle: DatasetBundle, output_dir: str) -> None:
    save_json(to_serializable(bundle.metadata), f"{output_dir}/data_metadata.json")
    if bundle.concept_scaler is not None:
        scaler_state = {
            "mean": bundle.concept_scaler.mean_.tolist(),
            "scale": bundle.concept_scaler.scale_.tolist(),
            "var": bundle.concept_scaler.var_.tolist(),
            "n_features_in": int(bundle.concept_scaler.n_features_in_),
            "feature_names": bundle.concept_cols,
        }
        save_json(scaler_state, f"{output_dir}/concept_scaler.json")
    label_state = {
        "classes": bundle.label_encoder.classes_.tolist(),
        "label_to_id": {c: int(i) for i, c in enumerate(bundle.label_encoder.classes_.tolist())},
    }
    save_json(label_state, f"{output_dir}/label_mapping.json")
