# mental_sft_qwen

A compact Qwen SFT pipeline for 4-class suicide-risk classification.

## Folder layout

- `main.py` — single entrypoint
- `utils/data_utils.py` — CSV -> train/test JSONL conversion
- `utils/model_utils.py` — tokenizer/model/LoRA loading
- `utils/train_utils.py` — TRL SFT trainer construction and training
- `utils/eval_utils.py` — batched generation + exact-label evaluation
- `configs/suicide_risk_cls.yaml` — prompt config

## Recommended usage

### 1) Install

```bash
pip install -r requirements.txt
```

### 2) Full run from raw CSV

```bash
python main.py \
  --mode full \
  --input_csv /mnt/disk1/wbjtu/tzbjtu/somental/data/anonymizing_sentiment_cleaned.csv \
  --model_path /path/to/Qwen3.5-9B \
  --prompt_yaml configs/suicide_risk_cls.yaml \
  --text_col text \
  --label_col sentiment \
  --gpus 0 \
  --num_train_epochs 3 \
  --learning_rate 1e-4 \
  --per_device_train_batch_size 1 \
  --gradient_accumulation_steps 8 \
  --max_seq_length 1024
```

### 3) Prepare only

```bash
python main.py \
  --mode prepare \
  --input_csv /mnt/disk1/wbjtu/tzbjtu/somental/data/rsd500.csv \
  --model_path /path/to/Qwen3.5-9B \
  --prompt_yaml configs/suicide_risk_cls.yaml
```

### 4) Train only from existing JSONL

```bash
python main.py \
  --mode train \
  --train_jsonl /path/to/train_sft.jsonl \
  --model_path /path/to/Qwen3.5-9B \
  --prompt_yaml configs/suicide_risk_cls.yaml \
  --gpus 0
```

### 5) Eval only

For eval-only mode, `--model_path` should point to the saved adapter/model directory created by training.

```bash
python main.py \
  --mode eval \
  --test_jsonl /path/to/test_sft.jsonl \
  --model_path /path/to/run_dir/model \
  --prompt_yaml configs/suicide_risk_cls.yaml \
  --gpus 0
```

## Notes

- The prepare step performs a stratified train/test split by label.
- Exact duplicate `(text, label)` rows are removed.
- Same `text` with conflicting labels is dropped before the split.
- Eval canonicalizes labels case-insensitively and counts `UNKNOWN` predictions.
- The eval code uses left padding and slices generated output using the shared padded prompt length.
- For single-label generation, `max_new_tokens=8` is the default.

## Important runtime expectation

This project is intentionally simple:
- It works best for 1-process runs.
- `--gpus 0,1,2,3` controls visible devices for the current process.
- With `device_map="auto"`, larger models may shard across visible GPUs.
- For clean multi-process distributed SFT, launch with `accelerate` or `torchrun` and adapt the script accordingly.
