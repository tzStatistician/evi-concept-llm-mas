from __future__ import annotations

import argparse
import os
from pathlib import Path

from utils.io_utils import load_yaml, make_run_dir, save_json
from utils.data_utils import prepare_train_test_jsonl


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Qwen SFT pipeline for suicide-risk classification")
    parser.add_argument("--mode", choices=["prepare", "train", "eval", "full"], default="full")

    parser.add_argument("--input_csv", type=str, default=None)
    parser.add_argument("--prompt_yaml", type=str, default="configs/suicide_risk_cls.yaml")
    parser.add_argument("--train_jsonl", type=str, default=None)
    parser.add_argument("--test_jsonl", type=str, default=None)

    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--output_root", type=str, default="./outputs")
    parser.add_argument("--run_dir", type=str, default=None)

    parser.add_argument("--text_col", type=str, default="text")
    parser.add_argument("--label_col", type=str, default="sentiment")
    parser.add_argument("--test_size", type=float, default=0.2)
    parser.add_argument("--random_state", type=int, default=42)
    parser.add_argument("--gpus", type=str, default=None)

    parser.add_argument("--use_4bit", action="store_true")
    parser.add_argument("--no_use_4bit", action="store_true")
    parser.add_argument("--bf16", action="store_true")
    parser.add_argument("--no_bf16", action="store_true")
    parser.add_argument("--num_train_epochs", type=float, default=3.0)
    parser.add_argument("--learning_rate", type=float, default=1e-4)
    parser.add_argument("--per_device_train_batch_size", type=int, default=1)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=8)
    parser.add_argument("--max_seq_length", type=int, default=1024)
    parser.add_argument("--logging_steps", type=int, default=10)
    parser.add_argument("--save_steps", type=int, default=100)
    parser.add_argument("--warmup_ratio", type=float, default=0.03)
    parser.add_argument("--lora_r", type=int, default=16)
    parser.add_argument("--lora_alpha", type=int, default=32)
    parser.add_argument("--lora_dropout", type=float, default=0.05)

    parser.add_argument("--eval_batch_size", type=int, default=4)
    parser.add_argument("--eval_max_new_tokens", type=int, default=8)
    return parser.parse_args()



def resolve_flags(args: argparse.Namespace) -> tuple[bool, bool]:
    use_4bit = True
    bf16 = True
    if args.use_4bit:
        use_4bit = True
    if args.no_use_4bit:
        use_4bit = False
    if args.bf16:
        bf16 = True
    if args.no_bf16:
        bf16 = False
    return use_4bit, bf16



def ensure_run_dir(args: argparse.Namespace) -> str:
    if args.run_dir:
        run_dir = args.run_dir
        Path(run_dir).mkdir(parents=True, exist_ok=True)
        return run_dir

    source_name = args.input_csv or args.train_jsonl or "dataset"
    return make_run_dir(args.output_root, source_name=source_name, model_name=args.model_path)



def main() -> None:
    args = parse_args()

    if args.gpus:
        os.environ["CUDA_VISIBLE_DEVICES"] = args.gpus

    use_4bit, bf16 = resolve_flags(args)
    run_dir = ensure_run_dir(args)
    prompt_cfg = load_yaml(args.prompt_yaml)

    train_jsonl = args.train_jsonl
    test_jsonl = args.test_jsonl

    if args.mode in {"prepare", "full"}:
        if not args.input_csv:
            raise ValueError("--input_csv is required for mode=prepare/full")

        train_jsonl = train_jsonl or str(Path(run_dir) / "train_sft.jsonl")
        test_jsonl = test_jsonl or str(Path(run_dir) / "test_sft.jsonl")

        summary, train_df, test_df, conflict_rows = prepare_train_test_jsonl(
            input_csv=args.input_csv,
            prompt_cfg=prompt_cfg,
            train_out=train_jsonl,
            test_out=test_jsonl,
            text_col=args.text_col,
            label_col=args.label_col,
            test_size=args.test_size,
            random_state=args.random_state,
            drop_conflicting_texts=True,
        )
        save_json(summary.__dict__, Path(run_dir) / "prepare_summary.json")
        if len(conflict_rows) > 0:
            conflict_rows.to_csv(Path(run_dir) / "conflicting_texts.csv", index=False)
        print(f"[prepare] saved train jsonl: {train_jsonl}")
        print(f"[prepare] saved test jsonl: {test_jsonl}")

    if args.mode in {"train", "full"}:
        if not train_jsonl:
            raise ValueError("train jsonl is missing. pass --train_jsonl or use mode=prepare/full")

        from utils.train_utils import train_and_save

        model_out = str(Path(run_dir) / "model")
        _, _, train_metrics = train_and_save(
            model_path=args.model_path,
            train_jsonl=train_jsonl,
            test_jsonl=None,
            output_dir=model_out,
            use_4bit=use_4bit,
            bf16=bf16,
            learning_rate=args.learning_rate,
            num_train_epochs=args.num_train_epochs,
            per_device_train_batch_size=args.per_device_train_batch_size,
            gradient_accumulation_steps=args.gradient_accumulation_steps,
            max_seq_length=args.max_seq_length,
            logging_steps=args.logging_steps,
            save_steps=args.save_steps,
            warmup_ratio=args.warmup_ratio,
            lora_r=args.lora_r,
            lora_alpha=args.lora_alpha,
            lora_dropout=args.lora_dropout,
        )
        print(f"[train] saved model/adapters to: {model_out}")
        print(f"[train] train metrics saved to: {Path(model_out) / 'train_metrics.json'}")

    if args.mode in {"eval", "full"}:
        if not test_jsonl:
            raise ValueError("test jsonl is missing. pass --test_jsonl or use mode=prepare/full")
        eval_model_dir = str(Path(run_dir) / "model") if args.mode == "full" else args.model_path

        from utils.eval_utils import evaluate_model

        metrics = evaluate_model(
            model_dir=eval_model_dir,
            test_jsonl=test_jsonl,
            labels=list(prompt_cfg["labels"]),
            output_dir=str(Path(run_dir) / "eval"),
            batch_size=args.eval_batch_size,
            max_new_tokens=args.eval_max_new_tokens,
        )
        print(f"[eval] macro_f1={metrics['macro_f1']:.4f} accuracy={metrics['accuracy']:.4f}")
        print(f"[eval] metrics saved to: {Path(run_dir) / 'eval' / 'metrics.json'}")

    print(f"[done] run dir: {run_dir}")


if __name__ == "__main__":
    main()
