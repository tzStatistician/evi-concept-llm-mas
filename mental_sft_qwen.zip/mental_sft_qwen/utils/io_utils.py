from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

import yaml


def load_yaml(path: str | os.PathLike) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def save_json(obj: Dict[str, Any], path: str | os.PathLike) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def write_jsonl(records: list[dict], path: str | os.PathLike) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for rec in records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def read_jsonl(path: str | os.PathLike) -> list[dict]:
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def slugify(text: str) -> str:
    allowed = []
    for ch in text.lower():
        if ch.isalnum():
            allowed.append(ch)
        elif ch in {"-", "_"}:
            allowed.append(ch)
        else:
            allowed.append("_")
    out = "".join(allowed)
    while "__" in out:
        out = out.replace("__", "_")
    return out.strip("_")


def timestamp_now() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def make_run_dir(output_root: str | os.PathLike, source_name: str, model_name: str) -> str:
    source_slug = slugify(Path(source_name).stem)
    model_slug = slugify(Path(model_name).name)
    run_dir = Path(output_root) / f"{timestamp_now()}_{source_slug}_{model_slug}"
    run_dir.mkdir(parents=True, exist_ok=True)
    return str(run_dir)
