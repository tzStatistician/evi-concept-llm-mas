from __future__ import annotations

from pathlib import Path

from datasets import load_dataset
from trl import SFTConfig, SFTTrainer

from .io_utils import save_json
from .model_utils import build_lora_config, load_model, load_tokenizer



def build_trainer(
    model_path: str,
    train_jsonl: str,
    output_dir: str,
    test_jsonl: str | None = None,
    use_4bit: bool = True,
    bf16: bool = True,
    learning_rate: float = 1e-4,
    num_train_epochs: float = 3.0,
    per_device_train_batch_size: int = 1,
    gradient_accumulation_steps: int = 8,
    max_seq_length: int = 1024,
    logging_steps: int = 10,
    save_steps: int = 100,
    warmup_ratio: float = 0.03,
    lora_r: int = 16,
    lora_alpha: int = 32,
    lora_dropout: float = 0.05,
):
    tokenizer = load_tokenizer(model_path)
    model = load_model(model_path=model_path, use_4bit=use_4bit, bf16=bf16)
    peft_config = build_lora_config(r=lora_r, alpha=lora_alpha, dropout=lora_dropout)

    data_files = {"train": train_jsonl}
    if test_jsonl:
        data_files["test"] = test_jsonl
    ds = load_dataset("json", data_files=data_files)

    args = SFTConfig(
        output_dir=output_dir,
        learning_rate=learning_rate,
        num_train_epochs=num_train_epochs,
        per_device_train_batch_size=per_device_train_batch_size,
        gradient_accumulation_steps=gradient_accumulation_steps,
        max_length=max_seq_length,
        logging_steps=logging_steps,
        save_steps=save_steps,
        warmup_ratio=warmup_ratio,
        bf16=bf16,
        fp16=not bf16,
        assistant_only_loss=True,
        report_to="none",
        save_total_limit=2,
        remove_unused_columns=False,
    )

    trainer = SFTTrainer(
        model=model,
        args=args,
        train_dataset=ds["train"],
        eval_dataset=ds["test"] if "test" in ds else None,
        processing_class=tokenizer,
        peft_config=peft_config,
    )

    return trainer, tokenizer



def train_and_save(**kwargs):
    output_dir = kwargs["output_dir"]
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    trainer, tokenizer = build_trainer(**kwargs)
    train_result = trainer.train()

    trainer.save_model(output_dir)
    tokenizer.save_pretrained(output_dir)

    metrics = dict(train_result.metrics)
    save_json(metrics, Path(output_dir) / "train_metrics.json")
    return trainer, tokenizer, metrics
