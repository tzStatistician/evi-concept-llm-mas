from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, List

import pandas as pd
import torch
from datasets import load_dataset
from sklearn.metrics import accuracy_score, classification_report, f1_score, precision_recall_fscore_support
from peft import AutoPeftModelForCausalLM
from transformers import AutoModelForCausalLM

from .io_utils import save_json
from .model_utils import load_tokenizer



def canonicalize_label(text: str, allowed_labels: list[str]) -> str:
    if text is None:
        return "UNKNOWN"
    raw = str(text).strip()
    if not raw:
        return "UNKNOWN"

    lowered = raw.lower()
    canonical_map = {x.lower(): x for x in allowed_labels}
    if lowered in canonical_map:
        return canonical_map[lowered]

    # try exact word search in generated text
    for lbl in allowed_labels:
        if lbl.lower() in lowered:
            return lbl
    return "UNKNOWN"



def extract_gold_label(example: dict) -> str:
    messages = example["messages"]
    for msg in reversed(messages):
        if msg.get("role") == "assistant":
            return str(msg.get("content", "")).strip()
    return "UNKNOWN"



def build_eval_prompt(messages: list[dict], tokenizer) -> str:
    prompt_messages = [m for m in messages if m.get("role") != "assistant"]
    try:
        return tokenizer.apply_chat_template(
            prompt_messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
    except TypeError:
        return tokenizer.apply_chat_template(
            prompt_messages,
            tokenize=False,
            add_generation_prompt=True,
        )



def batched(iterable: List[dict], batch_size: int):
    for i in range(0, len(iterable), batch_size):
        yield iterable[i : i + batch_size]



def evaluate_model(
    model_dir: str,
    test_jsonl: str,
    labels: list[str],
    output_dir: str,
    batch_size: int = 4,
    max_new_tokens: int = 8,
):
    tokenizer = load_tokenizer(model_dir)
    torch_dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
    try:
        model = AutoPeftModelForCausalLM.from_pretrained(
            model_dir,
            trust_remote_code=True,
            device_map="auto",
            torch_dtype=torch_dtype,
        )
    except Exception:
        model = AutoModelForCausalLM.from_pretrained(
            model_dir,
            trust_remote_code=True,
            device_map="auto",
            torch_dtype=torch_dtype,
        )
    model.eval()

    ds = load_dataset("json", data_files={"test": test_jsonl})["test"]
    rows = [dict(x) for x in ds]

    golds, preds, prompt_texts = [], [], []
    for batch in batched(rows, batch_size):
        prompts = [build_eval_prompt(x["messages"], tokenizer) for x in batch]
        gold_batch = [canonicalize_label(extract_gold_label(x), labels) for x in batch]

        inputs = tokenizer(
            prompts,
            return_tensors="pt",
            padding=True,
            truncation=True,
        ).to(model.device)

        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=False,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )

        prompt_len = inputs["input_ids"].shape[1]
        gen_ids = outputs[:, prompt_len:]
        decoded = tokenizer.batch_decode(gen_ids, skip_special_tokens=True)
        pred_batch = [canonicalize_label(x, labels) for x in decoded]

        golds.extend(gold_batch)
        preds.extend(pred_batch)
        prompt_texts.extend(prompts)

    metrics = {
        "accuracy": accuracy_score(golds, preds),
        "macro_f1": f1_score(golds, preds, average="macro", labels=labels),
        "weighted_f1": f1_score(golds, preds, average="weighted", labels=labels),
        "labels": labels,
    }

    p, r, f1, support = precision_recall_fscore_support(golds, preds, labels=labels, zero_division=0)
    per_class = {}
    for lbl, pp, rr, ff, ss in zip(labels, p, r, f1, support):
        per_class[lbl] = {
            "precision": float(pp),
            "recall": float(rr),
            "f1": float(ff),
            "support": int(ss),
        }
    metrics["per_class"] = per_class
    metrics["classification_report"] = classification_report(golds, preds, labels=labels, output_dict=True, zero_division=0)
    metrics["unknown_predictions"] = int(sum(1 for x in preds if x == "UNKNOWN"))

    Path(output_dir).mkdir(parents=True, exist_ok=True)
    save_json(metrics, Path(output_dir) / "metrics.json")

    pred_df = pd.DataFrame(
        {
            "gold": golds,
            "pred": preds,
            "prompt": prompt_texts,
        }
    )
    pred_df.to_csv(Path(output_dir) / "predictions.csv", index=False)
    return metrics
