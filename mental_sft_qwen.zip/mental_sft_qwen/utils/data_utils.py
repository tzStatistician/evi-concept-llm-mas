from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import pandas as pd
from sklearn.model_selection import train_test_split

from .io_utils import write_jsonl


@dataclass
class PrepareSummary:
    raw_rows: int
    rows_after_clean: int
    rows_after_exact_dedup: int
    invalid_label_rows: int
    dropped_conflict_texts: int
    rows_used_for_split: int
    train_rows: int
    test_rows: int
    train_path: str
    test_path: str
    train_label_distribution: Dict[str, int]
    test_label_distribution: Dict[str, int]


DEFAULT_LABEL_MAP = {
    "indicator": "Indicator",
    "ideation": "Ideation",
    "behavior": "Behavior",
    "attempt": "Attempt",
    "Indicator": "Indicator",
    "Ideation": "Ideation",
    "Behavior": "Behavior",
    "Attempt": "Attempt",
}


def build_system_prompt(prompt_cfg: dict) -> str:
    return str(prompt_cfg["system_prompt"]).strip()


def build_user_prompt(prompt_cfg: dict, text: str) -> str:
    tmpl = str(prompt_cfg["user_prompt_template"]).strip()
    return tmpl.format(text=text)



def _normalize_df(df: pd.DataFrame, text_col: str, label_col: str, label_map: Dict[str, str]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    work = df[[text_col, label_col]].copy()
    work[text_col] = work[text_col].astype(str).str.strip()
    work[label_col] = work[label_col].astype(str).str.strip()

    work = work[
        work[text_col].notna()
        & work[label_col].notna()
        & (work[text_col] != "")
        & (work[label_col] != "")
        & (work[text_col].str.lower() != "nan")
        & (work[label_col].str.lower() != "nan")
    ].copy()

    work["label"] = work[label_col].map(label_map)
    invalid = work[work["label"].isna()].copy()
    work = work[work["label"].notna()].copy()
    work = work.rename(columns={text_col: "text"})
    return work, invalid



def _messages_record(text: str, label: str, system_prompt: str, user_prompt_template_cfg: dict) -> dict:
    return {
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": build_user_prompt(user_prompt_template_cfg, text)},
            {"role": "assistant", "content": label},
        ]
    }



def prepare_train_test_jsonl(
    input_csv: str,
    prompt_cfg: dict,
    train_out: str,
    test_out: str,
    text_col: str = "text",
    label_col: str = "sentiment",
    test_size: float = 0.2,
    random_state: int = 42,
    drop_conflicting_texts: bool = True,
) -> tuple[PrepareSummary, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    raw_df = pd.read_csv(input_csv)
    raw_rows = len(raw_df)

    valid_labels = set(prompt_cfg["labels"])
    label_map = {**DEFAULT_LABEL_MAP}
    for x in valid_labels:
        label_map[x] = x
        label_map[str(x).lower()] = x

    df, invalid = _normalize_df(raw_df, text_col=text_col, label_col=label_col, label_map=label_map)
    rows_after_clean = len(df)

    df = df[df["label"].isin(valid_labels)].copy()
    before_dedup = len(df)
    df = df.drop_duplicates(subset=["text", "label"]).reset_index(drop=True)
    after_dedup = len(df)

    conflict_df = df.groupby("text")["label"].nunique().reset_index(name="n_unique_labels")
    conflict_texts = set(conflict_df.loc[conflict_df["n_unique_labels"] > 1, "text"])
    conflict_rows = df[df["text"].isin(conflict_texts)].sort_values(["text", "label"]).copy()

    if drop_conflicting_texts and conflict_texts:
        df = df[~df["text"].isin(conflict_texts)].copy().reset_index(drop=True)

    unique_df = df.drop_duplicates(subset=["text"]).copy().reset_index(drop=True)

    train_df, test_df = train_test_split(
        unique_df,
        test_size=test_size,
        random_state=random_state,
        stratify=unique_df["label"],
    )
    train_df = train_df.reset_index(drop=True)
    test_df = test_df.reset_index(drop=True)

    system_prompt = build_system_prompt(prompt_cfg)
    train_records = [_messages_record(r["text"], r["label"], system_prompt, prompt_cfg) for _, r in train_df.iterrows()]
    test_records = [_messages_record(r["text"], r["label"], system_prompt, prompt_cfg) for _, r in test_df.iterrows()]

    write_jsonl(train_records, train_out)
    write_jsonl(test_records, test_out)

    summary = PrepareSummary(
        raw_rows=raw_rows,
        rows_after_clean=rows_after_clean,
        rows_after_exact_dedup=after_dedup,
        invalid_label_rows=len(invalid),
        dropped_conflict_texts=len(conflict_texts),
        rows_used_for_split=len(unique_df),
        train_rows=len(train_df),
        test_rows=len(test_df),
        train_path=str(Path(train_out)),
        test_path=str(Path(test_out)),
        train_label_distribution=train_df["label"].value_counts().to_dict(),
        test_label_distribution=test_df["label"].value_counts().to_dict(),
    )
    return summary, train_df, test_df, conflict_rows
