from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch
from peft import LoraConfig
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig


@dataclass
class ModelBundle:
    tokenizer: object
    model: object



def load_tokenizer(model_path: str):
    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    return tokenizer



def build_quant_config(use_4bit: bool, bnb_compute_dtype: str = "bfloat16") -> Optional[BitsAndBytesConfig]:
    if not use_4bit:
        return None
    compute_dtype = getattr(torch, bnb_compute_dtype)
    return BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True,
        bnb_4bit_compute_dtype=compute_dtype,
    )



def load_model(model_path: str, use_4bit: bool = True, bf16: bool = True):
    quant_cfg = build_quant_config(use_4bit=use_4bit, bnb_compute_dtype="bfloat16" if bf16 else "float16")
    model_kwargs = {
        "trust_remote_code": True,
        "device_map": "auto",
    }
    if quant_cfg is not None:
        model_kwargs["quantization_config"] = quant_cfg
    else:
        model_kwargs["torch_dtype"] = torch.bfloat16 if bf16 else torch.float16

    model = AutoModelForCausalLM.from_pretrained(model_path, **model_kwargs)
    return model



def build_lora_config(
    r: int = 16,
    alpha: int = 32,
    dropout: float = 0.05,
    bias: str = "none",
):
    return LoraConfig(
        r=r,
        lora_alpha=alpha,
        lora_dropout=dropout,
        bias=bias,
        task_type="CAUSAL_LM",
        target_modules="all-linear",
    )
