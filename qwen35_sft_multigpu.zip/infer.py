from __future__ import annotations

import argparse

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

DEFAULT_SYSTEM_PROMPT = """You are a suicide risk classifier.

Classify the given social media post into exactly one label from:
- Indicator
- Ideation
- Behavior
- Attempt

Definitions:
- Attempt: an actual suicide attempt.
- Behavior: suicidal or self-harm-related action, but not a clear suicide attempt.
- Ideation: suicidal thoughts or desire for death, but no action.
- Indicator: none of the above.

Priority if multiple seem possible:
Attempt > Behavior > Ideation > Indicator

Rules:
1. Output exactly one label only.
2. Do not explain.
3. Do not output JSON.
4. Use only one of: Indicator, Ideation, Behavior, Attempt"""

DEFAULT_USER_TEMPLATE = """Text:
{text}

Return exactly one label.
Label:"""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base_model", type=str, required=True)
    parser.add_argument("--adapter_path", type=str, required=True)
    parser.add_argument("--text", type=str, required=True)
    parser.add_argument("--max_new_tokens", type=int, default=16)
    parser.add_argument("--enable_thinking", action="store_true", default=False)
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    tokenizer = AutoTokenizer.from_pretrained(args.base_model, use_fast=False, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        args.base_model,
        torch_dtype=torch.bfloat16,
        trust_remote_code=True,
        attn_implementation="flash_attention_2",
        device_map="auto",
    )
    model = PeftModel.from_pretrained(model, args.adapter_path)
    model.eval()

    messages = [
        {"role": "system", "content": DEFAULT_SYSTEM_PROMPT},
        {"role": "user", "content": DEFAULT_USER_TEMPLATE.format(text=args.text)},
    ]
    prompt = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=args.enable_thinking,
    )

    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=args.max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    new_tokens = outputs[0][inputs["input_ids"].shape[1]:]
    pred = tokenizer.decode(new_tokens, skip_special_tokens=True).strip()
    print(pred)


if __name__ == "__main__":
    main()
