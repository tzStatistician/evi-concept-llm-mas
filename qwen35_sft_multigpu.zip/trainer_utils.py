from __future__ import annotations

import json
import os
from typing import Sequence

from trl import SFTConfig, SFTTrainer

from data_utils import save_label_list


def build_trainer(args, model, tokenizer, train_dataset, eval_dataset):
    train_args = SFTConfig(
        output_dir=args.output_dir,
        do_train=True,
        do_eval=True,
        max_length=args.max_length,
        max_prompt_length=args.max_prompt_length,
        packing=args.packing,
        completion_only_loss=True,
        per_device_train_batch_size=args.per_device_train_batch_size,
        per_device_eval_batch_size=args.per_device_eval_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        num_train_epochs=args.num_train_epochs,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        warmup_ratio=args.warmup_ratio,
        lr_scheduler_type=args.lr_scheduler_type,
        max_grad_norm=args.max_grad_norm,
        logging_steps=args.logging_steps,
        eval_strategy=args.eval_strategy,
        save_strategy=args.save_strategy,
        save_total_limit=args.save_total_limit,
        bf16=args.use_bf16,
        fp16=not args.use_bf16,
        gradient_checkpointing=args.gradient_checkpointing,
        gradient_checkpointing_kwargs={"use_reentrant": False},
        deepspeed=args.deepspeed,
        report_to="none",
        load_best_model_at_end=True,
        metric_for_best_model=args.metric_for_best_model,
        greater_is_better=args.greater_is_better,
        remove_unused_columns=False,
        dataloader_pin_memory=True,
        dataloader_num_workers=args.dataloader_num_workers,
        logging_first_step=True,
        save_safetensors=True,
    )

    trainer = SFTTrainer(
        model=model,
        args=train_args,
        processing_class=tokenizer,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
    )
    return trainer


def save_artifacts(args, tokenizer, label_list: Sequence[str]) -> None:
    tokenizer.save_pretrained(args.output_dir)
    save_label_list(os.path.join(args.output_dir, "labels.json"), list(label_list))

    with open(os.path.join(args.output_dir, "train_config.json"), "w", encoding="utf-8") as f:
        json.dump(vars(args), f, ensure_ascii=False, indent=2)
