from __future__ import annotations

import json
from typing import List, Tuple

import pandas as pd
from datasets import Dataset
from sklearn.model_selection import train_test_split


def normalize_text(x: object) -> str:
    if x is None:
        return ""
    return " ".join(str(x).strip().split())


def parse_label_list(label_csv: str) -> List[str]:
    labels = [x.strip() for x in label_csv.split(",") if x.strip()]
    if len(labels) < 2:
        raise ValueError("Need at least two labels")
    if len(set(labels)) != len(labels):
        raise ValueError("Labels must be unique")
    return labels


def load_csv(args) -> Tuple[pd.DataFrame, List[str]]:
    df = pd.read_csv(args.csv_path)

    required = [args.text_col, args.label_col]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    df = df[[args.text_col, args.label_col]].copy()
    df[args.text_col] = df[args.text_col].map(normalize_text)
    df[args.label_col] = df[args.label_col].astype(str).str.strip()
    df = df[(df[args.text_col] != "") & (df[args.label_col] != "")].dropna().reset_index(drop=True)

    label_list = parse_label_list(args.labels)
    bad_labels = sorted(set(df[args.label_col].unique()) - set(label_list))
    if bad_labels:
        raise ValueError(f"Found labels not listed in --labels: {bad_labels}")

    return df, label_list


def build_prompt(text: str, tokenizer, args) -> str:
    messages = [
        {"role": "system", "content": args.system_prompt},
        {"role": "user", "content": args.user_template.format(text=text)},
    ]
    prompt = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=args.enable_thinking,
    )
    return prompt


def format_example(example: dict, tokenizer, args) -> dict:
    prompt = build_prompt(example[args.text_col], tokenizer, args)
    return {
        "prompt": prompt,
        "completion": example[args.label_col],
    }


def load_and_prepare_datasets(args, tokenizer):
    df, label_list = load_csv(args)

    stratify_col = df[args.label_col] if args.stratify else None
    train_df, val_df = train_test_split(
        df,
        train_size=args.train_size,
        test_size=args.val_size,
        random_state=args.seed,
        stratify=stratify_col,
    )

    train_ds = Dataset.from_pandas(train_df.reset_index(drop=True), preserve_index=False)
    val_ds = Dataset.from_pandas(val_df.reset_index(drop=True), preserve_index=False)

    train_ds = train_ds.map(
        lambda x: format_example(x, tokenizer, args),
        remove_columns=train_ds.column_names,
        desc="Formatting train set",
    )
    val_ds = val_ds.map(
        lambda x: format_example(x, tokenizer, args),
        remove_columns=val_ds.column_names,
        desc="Formatting val set",
    )

    return train_ds, val_ds, label_list


def save_label_list(path: str, label_list: list[str]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"labels": label_list}, f, ensure_ascii=False, indent=2)
