from __future__ import annotations

import os

from transformers import set_seed

from config import build_parser, validate_args
from data_utils import load_and_prepare_datasets
from model_utils import load_model_and_tokenizer
from trainer_utils import build_trainer, save_artifacts


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    validate_args(args)

    os.makedirs(args.output_dir, exist_ok=True)
    set_seed(args.seed)

    tokenizer, model = load_model_and_tokenizer(args)
    train_dataset, eval_dataset, label_list = load_and_prepare_datasets(args, tokenizer)

    trainer = build_trainer(
        args=args,
        model=model,
        tokenizer=tokenizer,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
    )

    trainer.train(resume_from_checkpoint=args.resume_from_checkpoint)
    trainer.save_model(args.output_dir)
    save_artifacts(args, tokenizer, label_list)


if __name__ == "__main__":
    main()
