#!/usr/bin/env bash
set -euo pipefail

export CUDA_VISIBLE_DEVICES=0,1,2,3
export TOKENIZERS_PARALLELISM=false

accelerate launch --num_processes 4 main.py \
  --csv_path /path/to/train.csv \
  --model_name_or_path /path/to/Qwen3.5-27B \
  --output_dir /path/to/output_qwen35_cls \
  --text_col text \
  --label_col sentiment \
  --labels Indicator,Ideation,Behavior,Attempt \
  --train_size 0.9 \
  --val_size 0.1 \
  --max_length 2048 \
  --max_prompt_length 2032 \
  --per_device_train_batch_size 1 \
  --per_device_eval_batch_size 1 \
  --gradient_accumulation_steps 16 \
  --num_train_epochs 3 \
  --learning_rate 1e-4 \
  --lora_r 64 \
  --lora_alpha 128 \
  --lora_dropout 0.05 \
  --deepspeed deepspeed_zero3.json
