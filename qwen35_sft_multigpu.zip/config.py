from __future__ import annotations

import argparse
import os

DEFAULT_SYSTEM_PROMPT = """You are a suicide risk classifier.

Classify the given social media post into exactly one label from:
- Indicator
- Ideation
- Behavior
- Attempt

Definitions:
- Attempt: an actual suicide attempt.
- Behavior: suicidal or self-harm-related action, but not a clear suicide attempt.
- Ideation: suicidal thoughts or desire for death, but no action.
- Indicator: none of the above.

Priority if multiple seem possible:
Attempt > Behavior > Ideation > Indicator

Rules:
1. Output exactly one label only.
2. Do not explain.
3. Do not output JSON.
4. Use only one of: Indicator, Ideation, Behavior, Attempt"""

DEFAULT_USER_TEMPLATE = """Text:
{text}

Return exactly one label.
Label:"""

DEFAULT_LABELS = "Indicator,Ideation,Behavior,Attempt"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Multi-GPU Qwen3.5 SFT with LoRA")

    parser.add_argument("--csv_path", type=str, required=True)
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument("--model_name_or_path", type=str, required=True)
    parser.add_argument("--resume_from_checkpoint", type=str, default=None)

    parser.add_argument("--text_col", type=str, default="text")
    parser.add_argument("--label_col", type=str, default="sentiment")
    parser.add_argument("--system_prompt", type=str, default=DEFAULT_SYSTEM_PROMPT)
    parser.add_argument("--user_template", type=str, default=DEFAULT_USER_TEMPLATE)
    parser.add_argument("--labels", type=str, default=DEFAULT_LABELS)

    parser.add_argument("--train_size", type=float, default=0.9)
    parser.add_argument("--val_size", type=float, default=0.1)
    parser.add_argument("--stratify", action="store_true", default=True)
    parser.add_argument("--no_stratify", dest="stratify", action="store_false")
    parser.add_argument("--seed", type=int, default=42)

    parser.add_argument("--max_length", type=int, default=2048)
    parser.add_argument("--max_prompt_length", type=int, default=2032)
    parser.add_argument("--enable_thinking", action="store_true", default=False)

    parser.add_argument("--lora_r", type=int, default=64)
    parser.add_argument("--lora_alpha", type=int, default=128)
    parser.add_argument("--lora_dropout", type=float, default=0.05)
    parser.add_argument(
        "--target_modules",
        type=str,
        default="q_proj,k_proj,v_proj,o_proj,up_proj,down_proj,gate_proj",
    )

    parser.add_argument("--num_train_epochs", type=float, default=3.0)
    parser.add_argument("--per_device_train_batch_size", type=int, default=1)
    parser.add_argument("--per_device_eval_batch_size", type=int, default=1)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=16)
    parser.add_argument("--learning_rate", type=float, default=1e-4)
    parser.add_argument("--weight_decay", type=float, default=0.01)
    parser.add_argument("--warmup_ratio", type=float, default=0.03)
    parser.add_argument("--lr_scheduler_type", type=str, default="cosine")
    parser.add_argument("--max_grad_norm", type=float, default=1.0)

    parser.add_argument("--gradient_checkpointing", action="store_true", default=True)
    parser.add_argument("--no_gradient_checkpointing", dest="gradient_checkpointing", action="store_false")
    parser.add_argument("--use_bf16", action="store_true", default=True)
    parser.add_argument("--no_bf16", dest="use_bf16", action="store_false")
    parser.add_argument("--use_tf32", action="store_true", default=True)
    parser.add_argument("--no_tf32", dest="use_tf32", action="store_false")
    parser.add_argument("--attn_implementation", type=str, default="flash_attention_2")

    parser.add_argument("--logging_steps", type=int, default=10)
    parser.add_argument("--eval_strategy", type=str, default="epoch")
    parser.add_argument("--save_strategy", type=str, default="epoch")
    parser.add_argument("--save_total_limit", type=int, default=2)
    parser.add_argument("--metric_for_best_model", type=str, default="eval_loss")
    parser.add_argument("--greater_is_better", action="store_true", default=False)

    parser.add_argument("--deepspeed", type=str, default="deepspeed_zero3.json")
    parser.add_argument("--dataloader_num_workers", type=int, default=4)
    parser.add_argument("--packing", action="store_true", default=False)

    return parser


def validate_args(args: argparse.Namespace) -> None:
    if not os.path.exists(args.csv_path):
        raise FileNotFoundError(f"CSV not found: {args.csv_path}")

    if args.train_size <= 0 or args.val_size <= 0:
        raise ValueError("train_size and val_size must both be > 0")

    if abs((args.train_size + args.val_size) - 1.0) > 1e-8:
        raise ValueError("train_size + val_size must equal 1.0")

    if args.max_length < 64:
        raise ValueError("max_length is too small")

    if args.max_prompt_length >= args.max_length:
        raise ValueError("max_prompt_length must be smaller than max_length")
