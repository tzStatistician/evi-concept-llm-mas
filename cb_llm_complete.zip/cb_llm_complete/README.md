# CB-LLMs Replication Baseline (Complete)

This project implements a clean end-to-end replication-oriented baseline for the **classification** pipeline in *Concept Bottleneck Large Language Models*.

## What is included

1. **Concept generation with local Qwen 3.6 27B via vLLM Python API**
2. **Concept regulation**
3. **Automatic Concept Scoring (ACS)** with sentence embeddings
4. **Automatic Concept Correction (ACC)**
5. **Concept Bottleneck Layer (CBL) training** with a text backbone
6. **Linear head training / inference**
7. **Evaluation**

## Important design note

- **Qwen/vLLM is used for concept generation**.
- The **actual classifier** is a separate trainable text backbone + CBL + linear head, as in the paper's classification pipeline.
- This means the model used for concept generation and the model used for classification **do not have to be the same**.

## Folder structure

- `01_concepts/`: concept generation and regulation
- `02_targets/`: ACS and ACC target construction
- `03_cbl/`: CBL model and training
- `04_classifier/`: linear-head training and prediction
- `05_eval/`: evaluation utilities
- `common/`: shared IO, config, schemas, helpers
- `config/`: example YAML configs
- `scripts/`: runnable shell scripts

## Typical workflow

### Stage 1: Generate and regulate concepts
```bash
python 01_concepts/generate_concepts.py --config config/pipeline.yaml
python 01_concepts/regulate_concepts.py --config config/pipeline.yaml
```

### Stage 2: Build ACS and ACC targets
```bash
python 02_targets/build_targets.py --config config/pipeline.yaml
```

### Stage 3: Train the backbone + CBL
```bash
python 03_cbl/train_cbl.py --config config/pipeline.yaml
```

### Stage 4: Train the linear classifier
```bash
python 04_classifier/train_linear_head.py --config config/pipeline.yaml
```

### Stage 5: Evaluate
```bash
python 05_eval/evaluate.py --config config/pipeline.yaml
```

## Core input expectations

The input CSV should contain:
- a text column, e.g. `text`
- a label column, e.g. `sentiment`

## Outputs

Main outputs are written under the configured `output_root`.

## Environment

You will usually want two environments or one sufficiently provisioned environment:
- one with **vLLM** for concept generation
- one with **Transformers / PyTorch / sentence-transformers** for ACS and classifier training

This code keeps everything in one codebase, but the stages are separate so you can run them in different environments if needed.
