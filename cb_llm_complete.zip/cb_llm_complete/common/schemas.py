from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class ConceptCandidate:
    label: str
    concept: str
    definition: str = ""
    rationale: str = ""
    lexical_cues: List[str] = field(default_factory=list)
    raw_source: Optional[str] = None


@dataclass
class RegulatedConcept:
    concept_id: str
    concept_name: str
    source_labels: List[str]
    merged_from: List[str] = field(default_factory=list)
    drop_reason: Optional[str] = None
    definition: str = ""
    lexical_cues: List[str] = field(default_factory=list)


@dataclass
class ExampleRecord:
    text: str
    label: str
    split: str
    example_id: str


@dataclass
class PredictionRecord:
    example_id: str
    gold_label: str
    pred_label: str
    logits: Dict[str, float]



def to_dict(obj: Any) -> Dict[str, Any]:
    return asdict(obj)
