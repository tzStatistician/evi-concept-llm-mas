from __future__ import annotations

import hashlib
import os
import random
import re
from pathlib import Path
from typing import Iterable, List

import numpy as np
import torch


NON_TEXT_OBSERVABLE_PATTERNS = [
    r"\bseverity\b",
    r"\btrue risk\b",
    r"\bactual intent\b",
    r"\blong-term\b",
    r"\bdiagnosis\b",
    r"\bpsychiatric\b",
]

VAGUE_PATTERNS = [
    r"\bdistress\b",
    r"\bnegativity\b",
    r"\bbad emotion\b",
    r"\bmental pain\b",
    r"\bpsychological crisis\b",
    r"\bsuicidality\b",
]


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)



def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")



def concept_id(text: str) -> str:
    h = hashlib.md5(text.strip().lower().encode("utf-8")).hexdigest()[:10]
    return f"concept_{slugify(text)[:32]}_{h}"



def normalize_concept(text: str) -> str:
    text = text.strip().lower()
    text = re.sub(r"\s+", " ", text)
    text = text.replace("feeling ", "")
    text = text.replace("expressing ", "")
    text = text.replace("thoughts of ", "")
    return text.strip()



def is_label_like(concept: str, labels: Iterable[str]) -> bool:
    c = normalize_concept(concept)
    for label in labels:
        l = normalize_concept(label)
        if c == l or c in l or l in c:
            return True
    return False



def is_vague(concept: str) -> bool:
    c = normalize_concept(concept)
    return any(re.search(p, c) for p in VAGUE_PATTERNS)



def is_non_text_observable(concept: str) -> bool:
    c = normalize_concept(concept)
    return any(re.search(p, c) for p in NON_TEXT_OBSERVABLE_PATTERNS)



def jaccard_tokens(a: str, b: str) -> float:
    sa = set(normalize_concept(a).split())
    sb = set(normalize_concept(b).split())
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)



def choose_device() -> str:
    return "cuda" if torch.cuda.is_available() else "cpu"
