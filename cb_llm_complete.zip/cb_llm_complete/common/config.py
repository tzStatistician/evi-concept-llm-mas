from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

from common.io import load_yaml


@dataclass
class PipelineConfig:
    raw: Dict

    @classmethod
    def from_yaml(cls, path: str | Path) -> "PipelineConfig":
        return cls(load_yaml(path))

    @property
    def output_root(self) -> Path:
        return Path(self.raw["output_root"])

    @property
    def dataset_path(self) -> Path:
        return Path(self.raw["dataset"]["path"])

    @property
    def text_col(self) -> str:
        return self.raw["dataset"]["text_col"]

    @property
    def label_col(self) -> str:
        return self.raw["dataset"]["label_col"]

    @property
    def split_col(self) -> str:
        return self.raw["dataset"].get("split_col", "split")

    @property
    def labels(self) -> List[str]:
        return list(self.raw["labels"])
