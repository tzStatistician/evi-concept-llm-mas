from __future__ import annotations

import argparse
import numpy as np

from common.config import PipelineConfig
from common.io import load_json


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()

    cfg = PipelineConfig.from_yaml(args.config)
    clf_metrics = load_json(cfg.output_root / "04_classifier" / "test_metrics.json")
    print("Classifier metrics:")
    print(clf_metrics)


if __name__ == "__main__":
    main()
