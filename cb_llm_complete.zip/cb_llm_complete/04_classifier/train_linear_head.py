from __future__ import annotations

import argparse
import json

import numpy as np
import pandas as pd
from sklearn.linear_model import ElasticNet, LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, f1_score
from sklearn.preprocessing import LabelEncoder

from common.config import PipelineConfig
from common.io import ensure_dir, load_json, read_csv, save_json, write_csv


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()

    cfg = PipelineConfig.from_yaml(args.config)
    df = read_csv(cfg.output_root / "02_targets" / "targets_metadata.csv")
    acts = np.load(cfg.output_root / "03_cbl" / "concept_activations.npy")
    X = np.maximum(acts, 0.0)
    y = df[cfg.label_col].astype(str).values

    le = LabelEncoder()
    y_enc = le.fit_transform(y)
    split_col = cfg.split_col
    train_mask = df[split_col].astype(str) == cfg.raw["classifier_training"].get("train_split", "train")
    val_mask = df[split_col].astype(str) == cfg.raw["classifier_training"].get("val_split", "val")
    test_mask = df[split_col].astype(str) == cfg.raw["classifier_training"].get("test_split", "test")

    clf = LogisticRegression(max_iter=int(cfg.raw["classifier_training"].get("max_iter", 2000)), penalty="l2")
    clf.fit(X[train_mask], y_enc[train_mask])

    out_dir = ensure_dir(cfg.output_root / "04_classifier")
    preds = clf.predict(X[test_mask])
    probs = clf.predict_proba(X[test_mask])
    gold = y_enc[test_mask]
    metrics = {
        "accuracy": float(accuracy_score(gold, preds)),
        "macro_f1": float(f1_score(gold, preds, average="macro")),
        "report": classification_report(gold, preds, target_names=list(le.classes_), output_dict=True),
    }
    save_json(metrics, out_dir / "test_metrics.json")

    pred_df = pd.DataFrame({
        "gold_label": le.inverse_transform(gold),
        "pred_label": le.inverse_transform(preds),
    })
    write_csv(pred_df, out_dir / "test_predictions.csv")

    import joblib
    joblib.dump({"clf": clf, "label_encoder": le}, out_dir / "linear_head.joblib")
    print(f"Saved classifier outputs to {out_dir}")


if __name__ == "__main__":
    main()
