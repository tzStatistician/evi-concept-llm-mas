from __future__ import annotations

from typing import List

import numpy as np
from sentence_transformers import SentenceTransformer


class ACSComputer:
    def __init__(self, model_name_or_path: str, device: str = "cuda") -> None:
        self.model = SentenceTransformer(model_name_or_path, device=device)

    def score(self, texts: List[str], concepts: List[str], batch_size: int = 64) -> np.ndarray:
        concept_emb = self.model.encode(concepts, convert_to_numpy=True, batch_size=batch_size, normalize_embeddings=True)
        text_emb = self.model.encode(texts, convert_to_numpy=True, batch_size=batch_size, normalize_embeddings=True)
        return text_emb @ concept_emb.T
