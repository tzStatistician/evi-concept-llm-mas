from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from acs import ACSComputer
from acc import apply_acc
from common.config import PipelineConfig
from common.io import ensure_dir, load_json, read_csv, save_json, write_csv
from common.utils import choose_device


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()

    cfg = PipelineConfig.from_yaml(args.config)
    df = read_csv(cfg.dataset_path)

    concepts_dir = cfg.output_root / "01_concepts"
    targets_dir = ensure_dir(cfg.output_root / "02_targets")

    regulated = load_json(concepts_dir / "regulated_concepts.json")
    concept_to_label = load_json(concepts_dir / "concept_to_label_map.json")
    concepts = [x["concept_name"] for x in regulated]

    stage_cfg = cfg.raw["acs"]
    acs = ACSComputer(stage_cfg["model_name_or_path"], device=stage_cfg.get("device", choose_device()))
    scores = acs.score(df[cfg.text_col].astype(str).tolist(), concepts, batch_size=int(stage_cfg.get("batch_size", 64)))
    acc = apply_acc(scores, df[cfg.label_col].astype(str).tolist(), concepts, concept_to_label)

    np.save(targets_dir / "acs_scores.npy", scores)
    np.save(targets_dir / "acc_targets.npy", acc)
    save_json(concepts, targets_dir / "concept_names.json")

    meta = df[[cfg.text_col, cfg.label_col]].copy()
    if cfg.split_col in df.columns:
        meta[cfg.split_col] = df[cfg.split_col]
    write_csv(meta, targets_dir / "targets_metadata.csv")
    print(f"Saved ACS/ACC targets to {targets_dir}")


if __name__ == "__main__":
    main()
