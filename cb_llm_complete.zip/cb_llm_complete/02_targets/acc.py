from __future__ import annotations

from typing import Dict, List

import numpy as np


def apply_acc(scores: np.ndarray, gold_labels: List[str], concepts: List[str], concept_to_label: Dict[str, str]) -> np.ndarray:
    out = np.zeros_like(scores)
    for i, gold in enumerate(gold_labels):
        for j, concept in enumerate(concepts):
            if scores[i, j] > 0 and concept_to_label.get(concept) == gold:
                out[i, j] = scores[i, j]
    return out
