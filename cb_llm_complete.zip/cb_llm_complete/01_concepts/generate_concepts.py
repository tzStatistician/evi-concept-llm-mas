from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

from vllm import LLM, SamplingParams

from common.config import PipelineConfig
from common.io import ensure_dir, save_json
from common.schemas import ConceptCandidate, to_dict

SYSTEM_PROMPT = """You are helping build a label-conditioned concept set for a text classification task.
Generate interpretable concepts for exactly one class label.
Return JSON only with key `concepts`, where the value is a list of objects.
Each object must have keys:
- concept
n- definition
- rationale
- lexical_cues
Constraints:
- concepts must be text-observable
- concepts must not simply restate the label
- concepts should be concise noun phrases or short semantic phrases
- lexical_cues must be short strings, not sentences
"""


def build_user_prompt(task_name: str, label: str, all_labels: List[str], n: int, label_defs: Dict[str, str]) -> str:
    return f"""
Task: {task_name}
All class labels: {all_labels}
Current target label: {label}
Target label definition: {label_defs.get(label, '')}
Required number of candidate concepts: {n}

Return only JSON with schema:
{{
  "concepts": [
    {{
      "concept": "...",
      "definition": "...",
      "rationale": "...",
      "lexical_cues": ["...", "..."]
    }}
  ]
}}
""".strip()


def parse_response(text: str, label: str) -> List[ConceptCandidate]:
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end < 0:
        raise ValueError("Model output does not contain JSON object.")
    data = json.loads(text[start:end+1])
    out = []
    for item in data.get("concepts", []):
        out.append(
            ConceptCandidate(
                label=label,
                concept=item.get("concept", "").strip(),
                definition=item.get("definition", "").strip(),
                rationale=item.get("rationale", "").strip(),
                lexical_cues=[str(x).strip() for x in item.get("lexical_cues", []) if str(x).strip()],
                raw_source=text,
            )
        )
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()

    cfg = PipelineConfig.from_yaml(args.config)
    stage_cfg = cfg.raw["concept_generation"]
    out_dir = ensure_dir(cfg.output_root / "01_concepts")

    llm = LLM(
        model=stage_cfg["model_path"],
        tensor_parallel_size=int(stage_cfg.get("tensor_parallel_size", 1)),
        max_model_len=int(stage_cfg.get("max_model_len", 4096)),
        gpu_memory_utilization=float(stage_cfg.get("gpu_memory_utilization", 0.85)),
        trust_remote_code=True,
    )
    sp = SamplingParams(
        temperature=float(stage_cfg.get("temperature", 0.1)),
        max_tokens=int(stage_cfg.get("max_tokens", 1200)),
    )

    task_name = cfg.raw.get("task_name", "text classification")
    label_defs = cfg.raw.get("label_definitions", {})
    n_per_label = int(stage_cfg.get("concepts_per_label", 24))

    all_results: Dict[str, Any] = {}
    for label in cfg.labels:
        prompt = build_user_prompt(task_name, label, cfg.labels, n_per_label, label_defs)
        outputs = llm.generate([
            f"<|im_start|>system\n{SYSTEM_PROMPT}<|im_end|>\n<|im_start|>user\n{prompt}<|im_end|>\n<|im_start|>assistant\n"
        ], sp)
        text = outputs[0].outputs[0].text
        concepts = parse_response(text, label)
        all_results[label] = [to_dict(c) for c in concepts]
        save_json(all_results[label], out_dir / f"raw_concepts_{label}.json")

    save_json(all_results, out_dir / "raw_concepts_all.json")
    print(f"Saved raw concepts to {out_dir}")


if __name__ == "__main__":
    main()
