from __future__ import annotations

import argparse
from collections import defaultdict
from pathlib import Path
from typing import Dict, List

from common.config import PipelineConfig
from common.io import load_json, save_json, ensure_dir
from common.schemas import RegulatedConcept, to_dict
from common.utils import concept_id, is_label_like, is_non_text_observable, is_vague, jaccard_tokens, normalize_concept


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()

    cfg = PipelineConfig.from_yaml(args.config)
    in_dir = cfg.output_root / "01_concepts"
    out_dir = ensure_dir(in_dir)

    raw = load_json(in_dir / "raw_concepts_all.json")
    labels = cfg.labels

    kept: List[RegulatedConcept] = []
    dropped: List[Dict] = []
    canonical_map: Dict[str, int] = {}

    for label, items in raw.items():
        for item in items:
            concept = item["concept"].strip()
            norm = normalize_concept(concept)
            if not norm:
                dropped.append({"label": label, "concept": concept, "reason": "empty"})
                continue
            if is_label_like(norm, labels):
                dropped.append({"label": label, "concept": concept, "reason": "label_like"})
                continue
            if is_vague(norm):
                dropped.append({"label": label, "concept": concept, "reason": "vague"})
                continue
            if is_non_text_observable(norm):
                dropped.append({"label": label, "concept": concept, "reason": "non_text_observable"})
                continue

            merged = False
            for idx, existing in enumerate(kept):
                sim = jaccard_tokens(existing.concept_name, norm)
                if norm == normalize_concept(existing.concept_name) or sim >= 0.8:
                    if label not in existing.source_labels:
                        existing.source_labels.append(label)
                    if concept not in existing.merged_from:
                        existing.merged_from.append(concept)
                    merged = True
                    break
            if merged:
                continue

            kept.append(
                RegulatedConcept(
                    concept_id=concept_id(norm),
                    concept_name=norm,
                    source_labels=[label],
                    merged_from=[concept],
                    definition=item.get("definition", ""),
                    lexical_cues=item.get("lexical_cues", []),
                )
            )

    save_json([to_dict(x) for x in kept], out_dir / "regulated_concepts.json")
    save_json(dropped, out_dir / "dropped_concepts.json")

    concept_to_primary = {x.concept_name: x.source_labels[0] for x in kept}
    save_json(concept_to_primary, out_dir / "concept_to_label_map.json")
    print(f"Kept {len(kept)} regulated concepts; dropped {len(dropped)}")


if __name__ == "__main__":
    main()
