#!/usr/bin/env bash
set -euo pipefail

CONFIG=${1:-config/pipeline.yaml}

python 01_concepts/generate_concepts.py --config "$CONFIG"
python 01_concepts/regulate_concepts.py --config "$CONFIG"
python 02_targets/build_targets.py --config "$CONFIG"
python 03_cbl/train_cbl.py --config "$CONFIG"
python 03_cbl/infer_cbl.py --config "$CONFIG"
python 04_classifier/train_linear_head.py --config "$CONFIG"
python 05_eval/evaluate.py --config "$CONFIG"
