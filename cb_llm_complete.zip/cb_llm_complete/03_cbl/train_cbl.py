from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer, get_linear_schedule_with_warmup
from tqdm import tqdm

from model_backbone_cbl import BackboneCBL
from common.config import PipelineConfig
from common.io import ensure_dir, load_json, read_csv, write_csv
from common.utils import set_seed, choose_device


class ConceptDataset(Dataset):
    def __init__(self, texts, targets, tokenizer, max_length=256):
        self.texts = list(texts)
        self.targets = targets
        self.tok = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        enc = self.tok(
            self.texts[idx],
            truncation=True,
            max_length=self.max_length,
            padding="max_length",
            return_tensors="pt",
        )
        item = {k: v.squeeze(0) for k, v in enc.items()}
        item["targets"] = torch.tensor(self.targets[idx], dtype=torch.float32)
        return item


def split_mask(df, split_col, split_name):
    return df[split_col].astype(str) == split_name if split_col in df.columns else np.array([True] * len(df))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()

    cfg = PipelineConfig.from_yaml(args.config)
    stage_cfg = cfg.raw["cbl_training"]
    set_seed(int(stage_cfg.get("seed", 42)))
    device = stage_cfg.get("device", choose_device())

    targets_dir = cfg.output_root / "02_targets"
    out_dir = ensure_dir(cfg.output_root / "03_cbl")
    df = read_csv(targets_dir / "targets_metadata.csv")
    acc_targets = np.load(targets_dir / "acc_targets.npy")
    concepts = load_json(targets_dir / "concept_names.json")

    tokenizer = AutoTokenizer.from_pretrained(stage_cfg["backbone_name_or_path"])
    model = BackboneCBL(stage_cfg["backbone_name_or_path"], len(concepts), float(stage_cfg.get("dropout", 0.1))).to(device)

    train_mask = split_mask(df, cfg.split_col, stage_cfg.get("train_split", "train"))
    val_mask = split_mask(df, cfg.split_col, stage_cfg.get("val_split", "val"))

    train_ds = ConceptDataset(df.loc[train_mask, cfg.text_col].tolist(), acc_targets[train_mask], tokenizer, int(stage_cfg.get("max_length", 256)))
    val_ds = ConceptDataset(df.loc[val_mask, cfg.text_col].tolist(), acc_targets[val_mask], tokenizer, int(stage_cfg.get("max_length", 256)))

    train_loader = DataLoader(train_ds, batch_size=int(stage_cfg.get("batch_size", 16)), shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=int(stage_cfg.get("batch_size", 16)), shuffle=False)

    opt = torch.optim.AdamW(model.parameters(), lr=float(stage_cfg.get("lr", 2e-5)), weight_decay=float(stage_cfg.get("weight_decay", 0.01)))
    total_steps = len(train_loader) * int(stage_cfg.get("epochs", 3))
    sched = get_linear_schedule_with_warmup(opt, int(total_steps * float(stage_cfg.get("warmup_ratio", 0.1))), total_steps)

    best_val = float("inf")
    history = []
    for epoch in range(int(stage_cfg.get("epochs", 3))):
        model.train()
        tr_loss = 0.0
        for batch in tqdm(train_loader, desc=f"train epoch {epoch+1}"):
            batch = {k: v.to(device) for k, v in batch.items()}
            pred = model(batch["input_ids"], batch["attention_mask"])
            loss = F.mse_loss(pred, batch["targets"])
            opt.zero_grad()
            loss.backward()
            opt.step()
            sched.step()
            tr_loss += loss.item()

        model.eval()
        va_loss = 0.0
        with torch.no_grad():
            for batch in tqdm(val_loader, desc=f"val epoch {epoch+1}"):
                batch = {k: v.to(device) for k, v in batch.items()}
                pred = model(batch["input_ids"], batch["attention_mask"])
                loss = F.mse_loss(pred, batch["targets"])
                va_loss += loss.item()
        tr_loss /= max(len(train_loader), 1)
        va_loss /= max(len(val_loader), 1)
        history.append({"epoch": epoch + 1, "train_mse": tr_loss, "val_mse": va_loss})
        if va_loss < best_val:
            best_val = va_loss
            torch.save(model.state_dict(), out_dir / "best_cbl.pt")

    write_csv(__import__('pandas').DataFrame(history), out_dir / "cbl_history.csv")
    print(f"Saved CBL model to {out_dir / 'best_cbl.pt'}")


if __name__ == "__main__":
    main()
