from __future__ import annotations

import argparse

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset
from transformers import AutoTokenizer

from model_backbone_cbl import BackboneCBL
from common.config import PipelineConfig
from common.io import ensure_dir, load_json, read_csv
from common.utils import choose_device


class TextDataset(Dataset):
    def __init__(self, texts, tokenizer, max_length=256):
        self.texts = list(texts)
        self.tok = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        enc = self.tok(self.texts[idx], truncation=True, max_length=self.max_length, padding="max_length", return_tensors="pt")
        return {k: v.squeeze(0) for k, v in enc.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = PipelineConfig.from_yaml(args.config)
    stage_cfg = cfg.raw["cbl_training"]
    device = stage_cfg.get("device", choose_device())

    targets_dir = cfg.output_root / "02_targets"
    out_dir = ensure_dir(cfg.output_root / "03_cbl")
    df = read_csv(targets_dir / "targets_metadata.csv")
    concepts = load_json(targets_dir / "concept_names.json")

    tok = AutoTokenizer.from_pretrained(stage_cfg["backbone_name_or_path"])
    model = BackboneCBL(stage_cfg["backbone_name_or_path"], len(concepts), float(stage_cfg.get("dropout", 0.1))).to(device)
    model.load_state_dict(torch.load(out_dir / "best_cbl.pt", map_location=device))
    model.eval()

    ds = TextDataset(df[cfg.text_col].tolist(), tok, int(stage_cfg.get("max_length", 256)))
    loader = DataLoader(ds, batch_size=int(stage_cfg.get("batch_size", 16)), shuffle=False)

    acts = []
    with torch.no_grad():
        for batch in loader:
            batch = {k: v.to(device) for k, v in batch.items()}
            pred = model(batch["input_ids"], batch["attention_mask"])
            acts.append(pred.cpu().numpy())
    acts = np.concatenate(acts, axis=0)
    np.save(out_dir / "concept_activations.npy", acts)
    print(f"Saved activations to {out_dir / 'concept_activations.npy'}")


if __name__ == "__main__":
    main()
