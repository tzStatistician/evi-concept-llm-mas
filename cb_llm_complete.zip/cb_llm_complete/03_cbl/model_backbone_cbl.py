from __future__ import annotations

import torch
import torch.nn as nn
from transformers import AutoModel, AutoTokenizer


class BackboneCBL(nn.Module):
    def __init__(self, backbone_name_or_path: str, num_concepts: int, dropout: float = 0.1):
        super().__init__()
        self.backbone = AutoModel.from_pretrained(backbone_name_or_path)
        hidden = self.backbone.config.hidden_size
        self.dropout = nn.Dropout(dropout)
        self.cbl = nn.Linear(hidden, num_concepts)

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        out = self.backbone(input_ids=input_ids, attention_mask=attention_mask)
        if hasattr(out, "last_hidden_state"):
            pooled = out.last_hidden_state[:, 0]
        else:
            pooled = out[0][:, 0]
        pooled = self.dropout(pooled)
        return self.cbl(pooled)
