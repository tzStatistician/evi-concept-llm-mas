from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

import torch
import torch.nn.functional as F


@dataclass
class LambdaController:
    mode: str = "fixed"
    base_lambda: float = 0.1
    min_lambda: float = 0.03
    max_lambda: float = 0.3
    calibration_steps: int = 100
    ema_decay: float = 0.9

    def __post_init__(self):
        self.current_lambda = float(self.base_lambda)
        self._concept_ema = None
        self._label_ema = None
        self._updates = 0

    def update(self, concept_loss: torch.Tensor, label_loss: torch.Tensor) -> float:
        c = float(concept_loss.detach().item())
        l = float(label_loss.detach().item())
        if self.mode == "fixed":
            self.current_lambda = self.base_lambda
            return self.current_lambda
        self._updates += 1
        if self._concept_ema is None:
            self._concept_ema = c
            self._label_ema = l
        else:
            self._concept_ema = self.ema_decay * self._concept_ema + (1 - self.ema_decay) * c
            self._label_ema = self.ema_decay * self._label_ema + (1 - self.ema_decay) * l
        if self._updates <= self.calibration_steps and self._label_ema > 0:
            raw = self._concept_ema / self._label_ema
            self.current_lambda = min(self.max_lambda, max(self.min_lambda, raw))
        return self.current_lambda


def compute_concept_loss(pred_concepts: torch.Tensor, concept_targets: torch.Tensor, loss_type: str = "mse") -> torch.Tensor:
    if loss_type == "mse":
        return F.mse_loss(pred_concepts, concept_targets)
    if loss_type == "mae":
        return F.l1_loss(pred_concepts, concept_targets)
    if loss_type == "huber":
        return F.huber_loss(pred_concepts, concept_targets, delta=1.0)
    raise ValueError(f"Unsupported concept loss type: {loss_type}")


def compute_label_loss(logits: torch.Tensor, labels: torch.Tensor, class_weights: torch.Tensor | None = None, label_smoothing: float = 0.0) -> torch.Tensor:
    return F.cross_entropy(logits, labels, weight=class_weights, label_smoothing=label_smoothing)


def compute_sparsity_loss(linear_weight: torch.Tensor) -> torch.Tensor:
    return linear_weight.abs().mean()


def build_total_loss(outputs: Dict[str, torch.Tensor], concept_targets: torch.Tensor, labels: torch.Tensor, class_weights: torch.Tensor | None,
                     lambda_label: float, l1_lambda: float, concept_loss_type: str, label_smoothing: float) -> Dict[str, torch.Tensor]:
    concept_loss = compute_concept_loss(outputs["pred_concepts"], concept_targets, concept_loss_type)
    label_loss = compute_label_loss(outputs["logits"], labels, class_weights, label_smoothing)
    sparsity_loss = compute_sparsity_loss(outputs["linear_weight"])
    loss = concept_loss + lambda_label * label_loss + l1_lambda * sparsity_loss
    return {
        "loss": loss,
        "concept_loss": concept_loss,
        "label_loss": label_loss,
        "sparsity_loss": sparsity_loss,
        "lambda_label": torch.tensor(lambda_label, device=loss.device),
    }
