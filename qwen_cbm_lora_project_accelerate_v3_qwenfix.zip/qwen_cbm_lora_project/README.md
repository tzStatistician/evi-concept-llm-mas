# Distributed QLoRA Concept Bottleneck for Text Classification

This version is rebuilt for **multi-GPU training with Hugging Face Accelerate**.

Pipeline:

```text
text -> Qwen-3.5-9B (QLoRA) -> concept layer -> sparse linear predictor -> label
```

## Supported setup

- **4 to 8 GPUs** with `accelerate launch`
- end-to-end QLoRA training
- weighted cross-entropy for imbalanced labels
- L1 sparsity on the concept-to-label linear head
- synchronized distributed metrics gathered across ranks

## Lambda choice

Default:
- `lambda_label = 0.1`

Reason:
- you observed raw label loss is about **10x** the concept loss, so `0.1` is the right first-order scaling.

Optional:
- `--lambda_mode auto`
- early-step calibration updates `lambda_label` from the ratio `concept_loss / label_loss`
- clamped to `[lambda_min, lambda_max]`

## Saved outputs

Under `output_dir`:

- `run_config.json`
- `data_metadata.json`
- `label_mapping.json`
- `concept_scaler.json` when standardization is enabled
- `training_history.json`
- `metrics_train.json`, `metrics_val.json`, `metrics_test.json`
- `metrics_all_splits.json`
- `predictions_train.csv`, `predictions_val.csv`, `predictions_test.csv`
- `predicted_concepts_*.npy`
- `gold_concepts_*.npy`
- `logits_*.npy`
- `best_linear_weight.csv/.npy`, `best_linear_bias.csv/.npy`
- `final_linear_weight.csv/.npy`, `final_linear_bias.csv/.npy`
- `best_model_state.pt`, `final_model_state.pt`
- `best_lora_adapter/`, `final_lora_adapter/`
- `best_tokenizer/`, `final_tokenizer/`

## Example: 4 GPUs

```bash
conda activate sft
cd /mnt/disk1/wbjtu/tzbjtu/somental/qwen_cbm

CUDA_VISIBLE_DEVICES=0,1,2,3 accelerate launch --num_processes 4 --mixed_precision bf16 main.py \
  --csv_path /mnt/disk1/wbjtu/tzbjtu/somental/data/rsd15_evidence_aware_concepts72_cleaned.csv \
  --text_col text \
  --label_col label \
  --model_name_or_path /path/to/your/Qwen3.5-9B \
  --output_dir /mnt/disk1/wbjtu/tzbjtu/somental/qwen_cbm/outputs/run_accel_4gpu \
  --load_in_4bit \
  --bnb_4bit_use_double_quant \
  --standardize_concepts \
  --gradient_checkpointing \
  --pin_memory \
  --save_every_epoch \
  --save_train_predictions \
  --save_val_predictions \
  --save_test_predictions \
  --save_train_split_eval \
  --num_epochs 5 \
  --train_batch_size 1 \
  --eval_batch_size 2 \
  --gradient_accumulation_steps 16 \
  --max_length 512 \
  --lambda_label 0.1 \
  --lambda_mode fixed \
  --l1_lambda 1e-4 \
  --lr_lora 2e-4 \
  --lr_heads 1e-3
```

## Example: 8 GPUs

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 accelerate launch --num_processes 8 --mixed_precision bf16 main.py ...
```


CLI options:
- `--concept_head_type linear|mlp` (default: `linear`)
- `--pooling mean|last_non_pad` (default: `mean`)
