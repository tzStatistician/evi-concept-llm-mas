from __future__ import annotations

import os
from typing import List, Tuple

import torch
import torch.nn as nn
from bitsandbytes.nn import Linear4bit
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from transformers import AutoConfig, AutoModel, AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

from config import TrainConfig
from utils import get_torch_dtype


class ConceptHead(nn.Module):
    def __init__(self, hidden_size: int, num_concepts: int, cfg: TrainConfig) -> None:
        super().__init__()
        if cfg.concept_head_type == "linear":
            self.net = nn.Linear(hidden_size, num_concepts)
        else:
            self.net = nn.Sequential(
                nn.Linear(hidden_size, cfg.concept_hidden_dim),
                nn.GELU(),
                nn.Dropout(cfg.dropout),
                nn.Linear(cfg.concept_hidden_dim, num_concepts),
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Concept targets are calibrated numeric scores in [0, 1], so we bound predictions.
        return torch.sigmoid(self.net(x))


class QwenConceptBottleneckModel(nn.Module):
    def __init__(self, backbone: nn.Module, hidden_size: int, num_concepts: int, num_classes: int, cfg: TrainConfig):
        super().__init__()
        self.backbone = backbone
        self.pooling = cfg.pooling
        self.dropout = nn.Dropout(cfg.dropout)
        self.concept_head = ConceptHead(hidden_size, num_concepts, cfg)
        self.linear_predictor = nn.Linear(num_concepts, num_classes)

    def _pool(self, last_hidden_state: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        if self.pooling == "mean":
            mask = attention_mask.unsqueeze(-1).to(last_hidden_state.dtype)
            return (last_hidden_state * mask).sum(1) / mask.sum(1).clamp_min(1.0)
        idx = attention_mask.sum(1) - 1
        idx = idx.clamp_min(0)
        batch_idx = torch.arange(last_hidden_state.size(0), device=last_hidden_state.device)
        return last_hidden_state[batch_idx, idx]

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> dict:
        out = self.backbone(input_ids=input_ids, attention_mask=attention_mask, return_dict=True)
        if not hasattr(out, "last_hidden_state"):
            raise AttributeError("Backbone output does not expose last_hidden_state. Check model loader/backbone extraction.")
        pooled = self.dropout(self._pool(out.last_hidden_state, attention_mask))
        pred_concepts = self.concept_head(pooled)
        logits = self.linear_predictor(pred_concepts)
        return {
            "pooled": pooled,
            "pred_concepts": pred_concepts,
            "logits": logits,
            "linear_weight": self.linear_predictor.weight,
            "linear_bias": self.linear_predictor.bias,
        }


def _infer_lora_targets(model: nn.Module, requested: str, load_in_4bit: bool) -> List[str]:
    req = [x.strip() for x in requested.split(",") if x.strip()]
    found = set()
    allowed_types = (Linear4bit,) if load_in_4bit else (nn.Linear, Linear4bit)
    fallback_found = set()

    for name, module in model.named_modules():
        leaf = name.split(".")[-1]
        if leaf in req and isinstance(module, allowed_types):
            found.add(leaf)
        if leaf in req and isinstance(module, (nn.Linear, Linear4bit)):
            fallback_found.add(leaf)

    if found:
        return sorted(found)

    if load_in_4bit and fallback_found:
        # Some custom checkpoints may not expose bitsandbytes-wrapped submodules in the way PEFT expects.
        # Fall back to standard Linear LoRA instead of crashing deep inside PEFT.
        return sorted(fallback_found)

    raise ValueError(
        "No LoRA target modules found in loaded backbone. Inspect module names or pass a different --lora_target_modules."
    )


def _resolve_feature_backbone(full_model: nn.Module) -> nn.Module:
    candidates = [
        "model",
        "language_model",
        "transformer",
        "backbone",
    ]
    for name in candidates:
        if hasattr(full_model, name):
            sub = getattr(full_model, name)
            if isinstance(sub, nn.Module):
                return sub
    if hasattr(full_model, "last_hidden_state"):
        return full_model
    return full_model


def _load_full_model(cfg: TrainConfig, model_kwargs: dict) -> Tuple[nn.Module, AutoConfig]:
    config = AutoConfig.from_pretrained(cfg.model_name_or_path, trust_remote_code=True)
    architectures = list(getattr(config, "architectures", []) or [])
    arch = architectures[0] if architectures else ""

    loaders = []
    if "ForConditionalGeneration" in arch or "ForCausalLM" in arch or cfg.load_in_4bit:
        loaders.append(AutoModelForCausalLM)
    loaders.append(AutoModel)

    last_error = None
    for loader in loaders:
        try:
            model = loader.from_pretrained(cfg.model_name_or_path, **model_kwargs)
            return model, config
        except Exception as e:
            last_error = e
    raise RuntimeError(f"Failed to load model from {cfg.model_name_or_path}. Last error: {last_error}")


def build_tokenizer(cfg: TrainConfig):
    tok = AutoTokenizer.from_pretrained(cfg.model_name_or_path, use_fast=True, trust_remote_code=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "right"
    return tok


def build_model(cfg: TrainConfig, num_concepts: int, num_classes: int) -> QwenConceptBottleneckModel:
    dtype = get_torch_dtype(cfg.bnb_4bit_compute_dtype)
    model_kwargs = {"trust_remote_code": True}
    if cfg.load_in_4bit:
        local_rank = int(os.environ.get("LOCAL_RANK", "0"))
        model_kwargs.update({
            "quantization_config": BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type=cfg.bnb_4bit_quant_type,
                bnb_4bit_compute_dtype=dtype,
                bnb_4bit_use_double_quant=cfg.bnb_4bit_use_double_quant,
            ),
            "device_map": {"": local_rank},
            "torch_dtype": dtype,
        })
    else:
        model_kwargs["torch_dtype"] = dtype

    full_model, config = _load_full_model(cfg, model_kwargs)
    if cfg.gradient_checkpointing and hasattr(full_model, "gradient_checkpointing_enable"):
        full_model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    if cfg.load_in_4bit:
        full_model = prepare_model_for_kbit_training(full_model)

    feature_backbone = _resolve_feature_backbone(full_model)
    lora_cfg = LoraConfig(
        r=cfg.lora_r,
        lora_alpha=cfg.lora_alpha,
        lora_dropout=cfg.lora_dropout,
        target_modules=_infer_lora_targets(feature_backbone, cfg.lora_target_modules, cfg.load_in_4bit),
        bias="none",
        task_type="FEATURE_EXTRACTION",
    )
    feature_backbone = get_peft_model(feature_backbone, lora_cfg)

    hidden_size = getattr(feature_backbone.config, "hidden_size", None) or getattr(config, "hidden_size", None)
    if hidden_size is None:
        raise ValueError("Could not infer hidden_size from loaded model config.")
    return QwenConceptBottleneckModel(feature_backbone, hidden_size, num_concepts, num_classes, cfg)
