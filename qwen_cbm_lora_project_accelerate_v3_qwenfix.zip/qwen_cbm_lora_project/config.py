from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Literal, Optional


@dataclass
class TrainConfig:
    csv_path: str = ""
    text_col: str = "text"
    label_col: str = "label"
    output_dir: str = "./outputs_qwen_cbm_accelerate"
    concept_suffix: str = "__calibrated"
    id_col: Optional[str] = None
    train_size: float = 0.8
    val_size: float = 0.1
    test_size: float = 0.1
    random_seed: int = 42

    model_name_or_path: str = "Qwen/Qwen3-9B"
    max_length: int = 512
    pooling: Literal["last_non_pad", "mean"] = "mean"
    concept_head_type: Literal["linear", "mlp"] = "linear"
    concept_hidden_dim: int = 1024
    dropout: float = 0.1

    load_in_4bit: bool = True
    lora_r: int = 16
    lora_alpha: int = 32
    lora_dropout: float = 0.05
    lora_target_modules: str = "q_proj,k_proj,v_proj,o_proj,up_proj,down_proj,gate_proj"
    bnb_4bit_quant_type: str = "nf4"
    bnb_4bit_compute_dtype: str = "bfloat16"
    bnb_4bit_use_double_quant: bool = True

    num_epochs: int = 5
    train_batch_size: int = 1
    eval_batch_size: int = 2
    gradient_accumulation_steps: int = 16
    lr_lora: float = 2e-4
    lr_heads: float = 1e-3
    weight_decay: float = 0.01
    warmup_ratio: float = 0.03
    max_grad_norm: float = 1.0

    lambda_label: float = 0.1
    lambda_mode: Literal["fixed", "auto"] = "fixed"
    lambda_min: float = 0.03
    lambda_max: float = 0.3
    lambda_calibration_steps: int = 100
    l1_lambda: float = 1e-4
    concept_loss_type: Literal["mse", "huber", "mae"] = "mse"
    class_weight_mode: Literal["balanced", "inverse_sqrt", "none"] = "balanced"
    label_smoothing: float = 0.0

    standardize_concepts: bool = True
    clip_concepts: bool = False
    concept_clip_min: float = -5.0
    concept_clip_max: float = 5.0

    mixed_precision: Literal["no", "fp16", "bf16"] = "bf16"
    gradient_checkpointing: bool = True
    metric_for_best_model: str = "macro_f1"
    greater_is_better: bool = True
    num_workers: int = 2
    pin_memory: bool = True
    save_every_epoch: bool = True
    log_every_steps: int = 10

    save_train_predictions: bool = True
    save_val_predictions: bool = True
    save_test_predictions: bool = True
    save_train_split_eval: bool = True

    def validate(self) -> None:
        total = self.train_size + self.val_size + self.test_size
        if abs(total - 1.0) > 1e-6:
            raise ValueError(f"train/val/test sizes must sum to 1.0, got {total}")
        if self.lambda_mode == "auto" and self.lambda_calibration_steps <= 0:
            raise ValueError("lambda_calibration_steps must be > 0 when lambda_mode='auto'")
        if self.lambda_min <= 0 or self.lambda_max <= 0 or self.lambda_min > self.lambda_max:
            raise ValueError("Invalid lambda_min/lambda_max range")

    def to_dict(self) -> dict:
        return asdict(self)
