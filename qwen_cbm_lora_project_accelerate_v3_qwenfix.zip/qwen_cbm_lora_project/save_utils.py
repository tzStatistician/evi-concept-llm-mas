from __future__ import annotations

import os
from typing import Dict, List

import numpy as np
import pandas as pd
import torch

from utils import ensure_dir, save_json, to_serializable


def save_metrics(metrics: Dict, output_dir: str, filename: str) -> None:
    ensure_dir(output_dir)
    save_json(to_serializable(metrics), os.path.join(output_dir, filename))


def save_training_history(history: Dict, output_dir: str) -> None:
    save_json(to_serializable(history), os.path.join(output_dir, "training_history.json"))


def save_linear_head(linear_predictor: torch.nn.Linear, concept_cols: List[str], class_names: List[str], output_dir: str, prefix: str = "linear") -> None:
    ensure_dir(output_dir)
    w = linear_predictor.weight.detach().float().cpu().numpy()
    b = linear_predictor.bias.detach().float().cpu().numpy()
    np.save(os.path.join(output_dir, f"{prefix}_weight.npy"), w)
    np.save(os.path.join(output_dir, f"{prefix}_bias.npy"), b)
    pd.DataFrame(w, index=class_names, columns=concept_cols).to_csv(os.path.join(output_dir, f"{prefix}_weight.csv"))
    pd.DataFrame({"class_name": class_names, "bias": b}).to_csv(os.path.join(output_dir, f"{prefix}_bias.csv"), index=False)


def save_prediction_artifacts(output_dir: str, split_name: str, payload: Dict, split_df: pd.DataFrame, text_col: str, label_col: str,
                              concept_cols: List[str], class_names: List[str]) -> None:
    ensure_dir(output_dir)
    order = np.argsort(payload["row_idx"].astype(int))
    row_idx = payload["row_idx"][order].astype(int)
    y_true = payload["y_true"][order].astype(int)
    y_pred = payload["y_pred"][order].astype(int)
    logits = payload["logits"][order]
    pred_concepts = payload["pred_concepts"][order]
    gold_concepts = payload["gold_concepts"][order]
    lookup = split_df.set_index("__row_idx__").loc[row_idx].reset_index()
    out = pd.DataFrame({
        "row_idx": row_idx,
        text_col: lookup[text_col].astype(str).values,
        "y_true": y_true,
        "y_pred": y_pred,
        "y_true_name": [class_names[i] for i in y_true],
        "y_pred_name": [class_names[i] for i in y_pred],
    })
    extra_cols = [c for c in lookup.columns if c not in {"__row_idx__", text_col, label_col} and not c.endswith("__calibrated")]
    for c in extra_cols:
        out[c] = lookup[c].values
    out[f"{label_col}_encoded"] = lookup[label_col].values
    for j, col in enumerate(concept_cols):
        out[f"gold::{col}"] = gold_concepts[:, j]
        out[f"pred::{col}"] = pred_concepts[:, j]
    out.to_csv(os.path.join(output_dir, f"predictions_{split_name}.csv"), index=False)
    np.save(os.path.join(output_dir, f"logits_{split_name}.npy"), logits)
    np.save(os.path.join(output_dir, f"predicted_concepts_{split_name}.npy"), pred_concepts)
    np.save(os.path.join(output_dir, f"gold_concepts_{split_name}.npy"), gold_concepts)
