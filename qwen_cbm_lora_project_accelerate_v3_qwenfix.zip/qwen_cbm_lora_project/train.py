from __future__ import annotations

import math
import os
from typing import Dict, List, Tuple

import numpy as np
import torch
from accelerate import Accelerator
from torch.optim import AdamW
from tqdm.auto import tqdm
from transformers import get_linear_schedule_with_warmup

from config import TrainConfig
from data_utils import DatasetBundle, build_dataloaders
from eval_utils import compute_classification_metrics
from losses import LambdaController, build_total_loss
from save_utils import save_linear_head, save_metrics, save_prediction_artifacts, save_training_history
from utils import ensure_dir


def _get_trainable_param_groups(model: torch.nn.Module, cfg: TrainConfig):
    lora_params, head_params, other_params = [], [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if "lora_" in name:
            lora_params.append(p)
        elif "concept_head" in name or "linear_predictor" in name:
            head_params.append(p)
        else:
            other_params.append(p)
    groups = []
    if lora_params:
        groups.append({"params": lora_params, "lr": cfg.lr_lora, "weight_decay": cfg.weight_decay})
    if head_params:
        groups.append({"params": head_params, "lr": cfg.lr_heads, "weight_decay": cfg.weight_decay})
    if other_params:
        groups.append({"params": other_params, "lr": cfg.lr_heads, "weight_decay": cfg.weight_decay})
    return groups


def _gather_np(accelerator: Accelerator, tensor: torch.Tensor) -> np.ndarray:
    t = accelerator.gather_for_metrics(tensor)
    return t.detach().cpu().numpy()


@torch.no_grad()
def predict(model, data_loader, accelerator: Accelerator, class_names: List[str]) -> Tuple[Dict, Dict]:
    model.eval()
    logits_list, y_list, predc_list, goldc_list, row_list = [], [], [], [], []
    pbar = tqdm(data_loader, desc="Predict", leave=False, disable=not accelerator.is_local_main_process)
    for batch in pbar:
        outputs = model(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"])
        logits_list.append(_gather_np(accelerator, outputs["logits"].float()))
        y_list.append(_gather_np(accelerator, batch["labels"]))
        predc_list.append(_gather_np(accelerator, outputs["pred_concepts"].float()))
        goldc_list.append(_gather_np(accelerator, batch["concept_targets"].float()))
        row_list.append(_gather_np(accelerator, batch["row_idx"]))
    logits = np.concatenate(logits_list, axis=0)
    y_true = np.concatenate(y_list, axis=0).astype(int)
    pred_concepts = np.concatenate(predc_list, axis=0)
    gold_concepts = np.concatenate(goldc_list, axis=0)
    row_idx = np.concatenate(row_list, axis=0).astype(int)
    y_pred = logits.argmax(axis=1).astype(int)
    metrics = compute_classification_metrics(y_true, y_pred, class_names)
    payload = {"row_idx": row_idx, "y_true": y_true, "y_pred": y_pred, "logits": logits, "pred_concepts": pred_concepts, "gold_concepts": gold_concepts}
    return metrics, payload


def _save_checkpoint(accelerator: Accelerator, model: torch.nn.Module, tokenizer, bundle: DatasetBundle, out_dir: str, tag: str) -> None:
    ensure_dir(out_dir)
    unwrapped = accelerator.unwrap_model(model)
    accelerator.wait_for_everyone()
    if accelerator.is_main_process:
        torch.save(accelerator.get_state_dict(model), os.path.join(out_dir, f"{tag}_model_state.pt"))
        unwrapped.backbone.save_pretrained(os.path.join(out_dir, f"{tag}_lora_adapter"))
        tokenizer.save_pretrained(os.path.join(out_dir, f"{tag}_tokenizer"))
        save_linear_head(unwrapped.linear_predictor, bundle.concept_cols, bundle.label_encoder.classes_.tolist(), out_dir, prefix=f"{tag}_linear")
    accelerator.wait_for_everyone()


def train_model(model: torch.nn.Module, tokenizer, bundle: DatasetBundle, cfg: TrainConfig, output_dir: str) -> None:
    ensure_dir(output_dir)
    accelerator = Accelerator(gradient_accumulation_steps=cfg.gradient_accumulation_steps, mixed_precision=cfg.mixed_precision)
    train_loader, val_loader, test_loader = build_dataloaders(bundle, tokenizer, cfg)
    optimizer = AdamW(_get_trainable_param_groups(model, cfg))
    updates_per_epoch = math.ceil(len(train_loader) / cfg.gradient_accumulation_steps)
    total_steps = updates_per_epoch * cfg.num_epochs
    warmup_steps = int(total_steps * cfg.warmup_ratio)
    scheduler = get_linear_schedule_with_warmup(optimizer, warmup_steps, total_steps)
    class_weights = torch.tensor(bundle.class_weights, dtype=torch.float32)
    model, optimizer, train_loader, val_loader, test_loader, scheduler, class_weights = accelerator.prepare(
        model, optimizer, train_loader, val_loader, test_loader, scheduler, class_weights
    )
    lambda_controller = LambdaController(cfg.lambda_mode, cfg.lambda_label, cfg.lambda_min, cfg.lambda_max, cfg.lambda_calibration_steps)
    best_metric = -float("inf") if cfg.greater_is_better else float("inf")
    history = {"epochs": []}
    class_names = bundle.label_encoder.classes_.tolist()

    for epoch in range(1, cfg.num_epochs + 1):
        model.train()
        running = {"loss": 0.0, "concept_loss": 0.0, "label_loss": 0.0, "sparsity_loss": 0.0, "lambda_label": 0.0}
        pbar = tqdm(train_loader, desc=f"Epoch {epoch}/{cfg.num_epochs}", disable=not accelerator.is_local_main_process)
        for step, batch in enumerate(pbar, start=1):
            with accelerator.accumulate(model):
                outputs = model(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"])
                pre = build_total_loss(outputs, batch["concept_targets"], batch["labels"], class_weights, cfg.lambda_label, cfg.l1_lambda, cfg.concept_loss_type, cfg.label_smoothing)
                lam = lambda_controller.update(pre["concept_loss"], pre["label_loss"])
                loss_dict = build_total_loss(outputs, batch["concept_targets"], batch["labels"], class_weights, lam, cfg.l1_lambda, cfg.concept_loss_type, cfg.label_smoothing)
                accelerator.backward(loss_dict["loss"])
                if accelerator.sync_gradients:
                    accelerator.clip_grad_norm_(model.parameters(), cfg.max_grad_norm)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad(set_to_none=True)
            for k in ["loss", "concept_loss", "label_loss", "sparsity_loss"]:
                running[k] += float(loss_dict[k].detach().item())
            running["lambda_label"] += float(lam)
            if step % cfg.log_every_steps == 0 or step == len(train_loader):
                pbar.set_postfix(loss=f"{running['loss']/step:.4f}", concept=f"{running['concept_loss']/step:.4f}", label=f"{running['label_loss']/step:.4f}", lam=f"{running['lambda_label']/step:.4f}")
        train_summary = {k: v / max(len(train_loader), 1) for k, v in running.items()}
        val_metrics, _ = predict(model, val_loader, accelerator, class_names)
        current_metric = val_metrics[cfg.metric_for_best_model]
        history["epochs"].append({"epoch": epoch, "train": train_summary, "val": val_metrics, "lr_last": scheduler.get_last_lr()})
        if accelerator.is_main_process:
            save_training_history(history, output_dir)
            save_metrics(val_metrics, output_dir, f"metrics_val_epoch{epoch}.json")
        better = current_metric > best_metric if cfg.greater_is_better else current_metric < best_metric
        if better:
            best_metric = current_metric
            _save_checkpoint(accelerator, model, tokenizer, bundle, output_dir, "best")
        if cfg.save_every_epoch and accelerator.is_main_process:
            save_linear_head(accelerator.unwrap_model(model).linear_predictor, bundle.concept_cols, class_names, output_dir, prefix=f"epoch{epoch}_linear")
        accelerator.wait_for_everyone()

    _save_checkpoint(accelerator, model, tokenizer, bundle, output_dir, "final")
    split_specs = [("val", val_loader, bundle.val_df, cfg.save_val_predictions), ("test", test_loader, bundle.test_df, cfg.save_test_predictions)]
    if cfg.save_train_split_eval:
        split_specs.insert(0, ("train", train_loader, bundle.train_df, cfg.save_train_predictions))
    all_metrics = {}
    for split_name, loader, split_df, save_preds in split_specs:
        metrics, payload = predict(model, loader, accelerator, class_names)
        all_metrics[split_name] = metrics
        if accelerator.is_main_process:
            save_metrics(metrics, output_dir, f"metrics_{split_name}.json")
            if save_preds:
                save_prediction_artifacts(output_dir, split_name, payload, split_df, cfg.text_col, cfg.label_col, bundle.concept_cols, class_names)
    if accelerator.is_main_process:
        save_metrics(all_metrics, output_dir, "metrics_all_splits.json")
