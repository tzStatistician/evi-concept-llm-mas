from dataclasses import dataclass, asdict, field
from typing import List, Dict


@dataclass
class LabelSpec:
    name: str
    definition: str


@dataclass
class RawConceptResult:
    label: str
    concepts: List[str]
    prompt: str
    raw_response: str

    def to_dict(self) -> Dict:
        return asdict(self)


@dataclass
class CanonicalConcept:
    canonical_name: str
    source_labels: List[str] = field(default_factory=list)
    merged_variants: List[str] = field(default_factory=list)
    drop_reason: str = ""

    def to_dict(self) -> Dict:
        return asdict(self)
