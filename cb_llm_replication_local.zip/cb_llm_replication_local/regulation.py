import re
from collections import OrderedDict, defaultdict
from difflib import SequenceMatcher
from typing import Dict, List, Tuple

from models import CanonicalConcept, RawConceptResult

STOPWORDS = {
    "a", "an", "the", "of", "to", "and", "or", "in", "on", "for", "with", "related", "expression", "expressing"
}

VAGUE_TERMS = {
    "distress", "negativity", "mental pain", "psychological crisis", "suicidality", "emotional difficulty", "severe state"
}


def _normalize(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9\s-]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text


def _token_set(text: str) -> set:
    return {t for t in _normalize(text).split() if t and t not in STOPWORDS}


def _too_similar_to_label(concept: str, label: str) -> bool:
    c = _normalize(concept)
    l = _normalize(label)
    if l in c or c in l:
        return True
    return SequenceMatcher(None, c, l).ratio() >= 0.72


def _is_vague(concept: str) -> bool:
    c = _normalize(concept)
    return c in VAGUE_TERMS or len(_token_set(c)) < 1


def _mergeable(a: str, b: str) -> bool:
    na, nb = _normalize(a), _normalize(b)
    if na == nb:
        return True
    if _token_set(na) == _token_set(nb):
        return True
    ratio = SequenceMatcher(None, na, nb).ratio()
    overlap = len(_token_set(na) & _token_set(nb))
    return ratio >= 0.88 or overlap >= max(1, min(len(_token_set(na)), len(_token_set(nb))) - 1)


def regulate_concepts(raw_results: List[RawConceptResult]) -> Tuple[List[CanonicalConcept], List[Dict]]:
    kept: "OrderedDict[str, CanonicalConcept]" = OrderedDict()
    dropped: List[Dict] = []

    for result in raw_results:
        label = result.label
        for concept in result.concepts:
            c = concept.strip()
            if not c:
                continue
            if _too_similar_to_label(c, label):
                dropped.append({"concept": c, "label": label, "reason": "too_similar_to_label"})
                continue
            if _is_vague(c):
                dropped.append({"concept": c, "label": label, "reason": "too_vague"})
                continue

            merged_into = None
            for key in list(kept.keys()):
                if _mergeable(key, c):
                    merged_into = key
                    break

            if merged_into is None:
                kept[c] = CanonicalConcept(canonical_name=c, source_labels=[label], merged_variants=[])
            else:
                item = kept[merged_into]
                if label not in item.source_labels:
                    item.source_labels.append(label)
                if c != merged_into and c not in item.merged_variants:
                    item.merged_variants.append(c)

    return list(kept.values()), dropped
