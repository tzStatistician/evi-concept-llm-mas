from textwrap import dedent


def build_label_prompt(task_name: str, label_name: str, label_definition: str, concepts_per_label: int) -> str:
    return dedent(f"""
    You are helping replicate a concept-bottleneck style classification baseline.

    Task: {task_name}
    Target class label: {label_name}
    Label definition: {label_definition}

    Generate exactly {concepts_per_label} candidate concepts for this label.

    Requirements:
    - Output a JSON object with one key: "concepts"
    - The value must be a list of short concept phrases
    - Each concept must be text-observable
    - Do not use the label name itself or near-paraphrases of the label
    - Avoid trivial wording variants of the same concept
    - Avoid concepts that are too vague, too broad, or not observable from text
    - Keep concepts concise, preferably noun phrases or short semantic phrases

    Return JSON only.
    """).strip()
