#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

python main.py \
  --config config/suicide_labels.yaml \
  --output-dir outputs/suicide_baseline \
  --model-path /mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.6-27B \
  --concepts-per-label 24 \
  --gpu-ids 0,1,2,3
