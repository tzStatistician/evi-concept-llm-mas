import argparse
from pathlib import Path

from pipeline import ConceptPipeline


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="CB-LLM concept extraction baseline using local vLLM")
    p.add_argument("--config", required=True, help="Path to YAML config")
    p.add_argument("--output-dir", required=True, help="Directory for outputs")
    p.add_argument("--model-path", required=True, help="Local model path")
    p.add_argument("--concepts-per-label", type=int, default=24)
    p.add_argument("--tensor-parallel-size", type=int, default=1)
    p.add_argument("--max-model-len", type=int, default=8192)
    p.add_argument("--temperature", type=float, default=0.2)
    p.add_argument("--max-tokens", type=int, default=1800)
    p.add_argument("--gpu-memory-utilization", type=float, default=0.9)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument(
        "--gpu-ids",
        type=str,
        default="",
        help="Comma-separated GPU ids for parallel label generation, e.g. '0,1,2,3'. When set, one label is assigned to one GPU and tensor-parallel is disabled.",
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()
    Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    gpu_ids = [x.strip() for x in args.gpu_ids.split(",") if x.strip()]
    pipeline = ConceptPipeline(
        model_path=args.model_path,
        concepts_per_label=args.concepts_per_label,
        tensor_parallel_size=args.tensor_parallel_size,
        max_model_len=args.max_model_len,
        temperature=args.temperature,
        max_tokens=args.max_tokens,
        gpu_memory_utilization=args.gpu_memory_utilization,
        seed=args.seed,
        gpu_ids=gpu_ids,
    )
    pipeline.run(args.config, args.output_dir)


if __name__ == "__main__":
    main()
