import os
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import List, Optional

from tqdm import tqdm

from models import LabelSpec, RawConceptResult
from regulation import regulate_concepts
from utils import dump_json, ensure_dir, load_yaml


def _generate_for_label_worker(
    *,
    model_path: str,
    concepts_per_label: int,
    max_model_len: int,
    temperature: float,
    max_tokens: int,
    gpu_memory_utilization: float,
    seed: int,
    task_name: str,
    label_name: str,
    label_definition: str,
    gpu_id: str,
) -> RawConceptResult:
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
    from local_llm import LocalVLLMGenerator

    generator = LocalVLLMGenerator(
        model_path=model_path,
        tensor_parallel_size=1,
        max_model_len=max_model_len,
        temperature=temperature,
        max_tokens=max_tokens,
        gpu_memory_utilization=gpu_memory_utilization,
        seed=seed,
    )
    return generator.generate_label_concepts(
        task_name=task_name,
        label_name=label_name,
        label_definition=label_definition,
        concepts_per_label=concepts_per_label,
    )


class ConceptPipeline:
    def __init__(
        self,
        model_path: str,
        concepts_per_label: int,
        tensor_parallel_size: int,
        max_model_len: int,
        temperature: float,
        max_tokens: int,
        gpu_memory_utilization: float,
        seed: int,
        gpu_ids: Optional[List[str]] = None,
    ) -> None:
        self.model_path = model_path
        self.concepts_per_label = concepts_per_label
        self.tensor_parallel_size = tensor_parallel_size
        self.max_model_len = max_model_len
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.gpu_memory_utilization = gpu_memory_utilization
        self.seed = seed
        self.gpu_ids = gpu_ids or []

    def _run_parallel(self, task_name: str, labels: List[LabelSpec]) -> List[RawConceptResult]:
        if len(self.gpu_ids) < len(labels):
            raise ValueError(
                f"parallel label mode needs at least as many gpu_ids as labels; got {len(self.gpu_ids)} gpu_ids for {len(labels)} labels"
            )

        results_by_label = {}
        with ProcessPoolExecutor(max_workers=len(labels)) as ex:
            futures = []
            for idx, label in enumerate(labels):
                futures.append(
                    ex.submit(
                        _generate_for_label_worker,
                        model_path=self.model_path,
                        concepts_per_label=self.concepts_per_label,
                        max_model_len=self.max_model_len,
                        temperature=self.temperature,
                        max_tokens=self.max_tokens,
                        gpu_memory_utilization=self.gpu_memory_utilization,
                        seed=self.seed + idx,
                        task_name=task_name,
                        label_name=label.name,
                        label_definition=label.definition,
                        gpu_id=self.gpu_ids[idx],
                    )
                )

            for fut in tqdm(as_completed(futures), total=len(futures), desc="Generating concepts (1 label / 1 GPU)"):
                result = fut.result()
                results_by_label[result.label] = result

        ordered = [results_by_label[label.name] for label in labels]
        return ordered

    def _run_single(self, task_name: str, labels: List[LabelSpec]) -> List[RawConceptResult]:
        from local_llm import LocalVLLMGenerator

        generator = LocalVLLMGenerator(
            model_path=self.model_path,
            tensor_parallel_size=self.tensor_parallel_size,
            max_model_len=self.max_model_len,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            gpu_memory_utilization=self.gpu_memory_utilization,
            seed=self.seed,
        )

        raw_results: List[RawConceptResult] = []
        for label in tqdm(labels, desc="Generating concepts"):
            result = generator.generate_label_concepts(
                task_name=task_name,
                label_name=label.name,
                label_definition=label.definition,
                concepts_per_label=self.concepts_per_label,
            )
            raw_results.append(result)
        return raw_results

    def run(self, config_path: str, output_dir: str) -> None:
        cfg = load_yaml(config_path)
        task_name = cfg["task_name"]
        labels = [LabelSpec(**x) for x in cfg["labels"]]
        ensure_dir(output_dir)

        if self.gpu_ids:
            raw_results = self._run_parallel(task_name, labels)
        else:
            raw_results = self._run_single(task_name, labels)

        canonical, dropped = regulate_concepts(raw_results)

        dump_json([x.to_dict() for x in raw_results], str(Path(output_dir) / "raw_concepts.json"))
        dump_json([x.to_dict() for x in canonical], str(Path(output_dir) / "canonical_concepts.json"))
        dump_json(dropped, str(Path(output_dir) / "dropped_concepts.json"))
