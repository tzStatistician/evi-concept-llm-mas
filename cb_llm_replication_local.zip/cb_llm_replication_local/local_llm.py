import json
import re
from typing import List

from vllm import LLM, SamplingParams

from prompts import build_label_prompt
from models import RawConceptResult


class LocalVLLMGenerator:
    def __init__(
        self,
        model_path: str,
        tensor_parallel_size: int = 1,
        max_model_len: int = 8192,
        gpu_memory_utilization: float = 0.9,
        temperature: float = 0.2,
        max_tokens: int = 1800,
        seed: int = 42,
    ) -> None:
        self.llm = LLM(
            model=model_path,
            tensor_parallel_size=tensor_parallel_size,
            max_model_len=max_model_len,
            gpu_memory_utilization=gpu_memory_utilization,
            trust_remote_code=True,
            seed=seed,
        )
        self.sampling_params = SamplingParams(
            temperature=temperature,
            max_tokens=max_tokens,
        )

    def generate_label_concepts(
        self,
        task_name: str,
        label_name: str,
        label_definition: str,
        concepts_per_label: int,
    ) -> RawConceptResult:
        prompt = build_label_prompt(task_name, label_name, label_definition, concepts_per_label)
        outputs = self.llm.generate([prompt], self.sampling_params)
        text = outputs[0].outputs[0].text.strip()
        concepts = self._parse_concepts(text)
        return RawConceptResult(label=label_name, concepts=concepts, prompt=prompt, raw_response=text)

    def _parse_concepts(self, text: str) -> List[str]:
        try:
            data = json.loads(text)
            items = data.get("concepts", [])
            return [str(x).strip() for x in items if str(x).strip()]
        except Exception:
            pass

        match = re.search(r"\{.*\}", text, flags=re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(0))
                items = data.get("concepts", [])
                return [str(x).strip() for x in items if str(x).strip()]
            except Exception:
                pass

        lines = [ln.strip("-• \t") for ln in text.splitlines() if ln.strip()]
        return [ln for ln in lines if ln]
