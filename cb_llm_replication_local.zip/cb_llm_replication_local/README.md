# CB-LLM Replication (Local vLLM)

A clean rewrite of the concept-extraction baseline for CB-LLM-style replication.

## What changed
- Uses **direct local vLLM Python inference**
- Does **not** use OpenAI-compatible HTTP serving
- Does **not** require `OPENAI_BASE_URL` or `OPENAI_API_KEY`
- Uses a single clean project root with no duplicated package folder name
- Supports **1 label per GPU** parallel generation via `--gpu-ids`

## Structure
- `main.py` — CLI entrypoint
- `local_llm.py` — direct local vLLM generator
- `pipeline.py` — end-to-end pipeline
- `regulation.py` — structural sanity regulation
- `prompts.py` — label-conditioned prompts
- `models.py` — data containers
- `utils.py` — YAML/JSON helpers
- `config/suicide_labels.yaml` — your four-label setup
- `scripts/run_local_concept_pipeline.sh` — run script

## Install
```bash
pip install -r requirements.txt
```

## Run on 4 GPUs with 1 label per GPU
```bash
cd /path/to/cb_llm_replication_local
python main.py \
  --config config/suicide_labels.yaml \
  --output-dir outputs/suicide_baseline \
  --model-path /mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.6-27B \
  --concepts-per-label 24 \
  --gpu-ids 0,1,2,3
```

## Run in single-process mode
```bash
python main.py \
  --config config/suicide_labels.yaml \
  --output-dir outputs/suicide_baseline \
  --model-path /mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.6-27B \
  --concepts-per-label 24 \
  --tensor-parallel-size 4
```

## Outputs
- `raw_concepts.json`
- `canonical_concepts.json`
- `dropped_concepts.json`

## Notes
This version stays label-conditioned for concept generation, then applies a generic structural sanity check:
- removes concepts too similar to labels
- merges duplicates and trivial variants
- removes overly vague concepts
- keeps provenance by source label

When `--gpu-ids` is set, the code spawns one worker per label and pins each worker to exactly one GPU using `CUDA_VISIBLE_DEVICES`.
