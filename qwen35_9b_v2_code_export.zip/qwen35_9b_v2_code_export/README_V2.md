# Qwen3.5-9B Concept SFT LoRA V2

This 9B variant reuses the same v2 data pipeline and prompt design as the 27B run, but changes the base model and output package to Qwen3.5-9B. It is intended for faster inference.


## Dataset Summary and Post-SFT Metrics

Final evaluation file:

```text
outputs/metrics/test_metrics_peft_qwen35_9b_v2_4gpu_parallel.json
```

Global evaluation summary:

```text
n = 7825
json_parse_rate = 0.9978
schema_valid_rate = 0.9978
```

| Dataset | Used in final SFT? | Paper title | Paper link | GitHub / source link | Post-SFT metric |
|---|---:|---|---|---|---|
| CAMS | Yes | CAMS: An Annotated Corpus for Causal Analysis of Mental Health Issues in Social Media Posts | https://aclanthology.org/2022.lrec-1.686/ | https://github.com/drmuskangarg/CAMS | Category accuracy = 0.5663; category macro-F1 = 0.5557; interpretation token-F1 = 0.4370; schema-valid = 0.9071 |
| LoST | Yes | LOST: A Mental Health Dataset of Low Self-esteem in Reddit Posts | https://arxiv.org/abs/2306.05596 | https://github.com/drmuskangarg/LoST | Accuracy = 0.8727; macro-F1 = 0.8319; schema-valid = 1.0000 |
| LonXplain | Yes | LonXplain: Lonesomeness as a Consequence of Mental Disturbance in Reddit Posts | https://arxiv.org/abs/2305.18736 | https://github.com/drmuskangarg/lonesomeness_dataset | Accuracy = 0.8750; macro-F1 = 0.8749; span token-F1 = 0.7108; schema-valid = 1.0000 |
| MultiWD | Yes | MultiWD: Multi-label wellness dimensions in social media posts | https://www.sciencedirect.com/science/article/abs/pii/S1532046424000042 | https://github.com/drmuskangarg/MultiWD | Micro-F1 = 0.7302; macro-F1 = 0.6023; subset accuracy = 0.3384; schema-valid = 1.0000 |
| WellnessDimensions | Yes, original human data only | Augmenting Reddit Posts to Determine Wellness Dimensions impacting Mental Health | https://aclanthology.org/2023.bionlp-1.27/ | https://github.com/drmuskangarg/WellnessDimensions | Aspect accuracy = 0.7540; aspect macro-F1 = 0.7466; span token-F1 = 0.5604; schema-valid = 1.0000 |
| SAD | Yes | SAD: A Stress Annotated Dataset for Recognizing Everyday Stressors in SMS-like Conversational Systems | https://github.com/PervasiveWellbeingTech/Stress-Annotated-Dataset-SAD | https://github.com/PervasiveWellbeingTech/Stress-Annotated-Dataset-SAD | is_stressor accuracy = 0.9650; is_stressor macro-F1 = 0.7601; stress_label accuracy = 0.7693; stress_label macro-F1 = 0.7165; schema-valid = 1.0000 |
| GoEmotions | Yes | GoEmotions: A Dataset of Fine-Grained Emotions | https://aclanthology.org/2020.acl-main.372/ | https://github.com/google-research/google-research/tree/master/goemotions | Micro-F1 = 0.5582; macro-F1 = 0.4747; subset accuracy = 0.4834; schema-valid = 1.0000 |
| DepressionEmo | No | DepressionEmo: A novel dataset for multilabel classification of depression emotions | https://pubmed.ncbi.nlm.nih.gov/39214375/ | https://github.com/abuBakarSiddiqurRahman/DepressionEmo | Excluded because of weak / LLM-assisted label concern |

Notes:

```text
WellnessDimensions GPT/ChatGPT-augmented files were excluded.
Only the original human-annotated WellnessDimensions file was used.
DepressionEmo was excluded from the final human-only SFT set.
```

---

## Usage Commands

### 1. Enter project

```bash
cd /mnt/disk1/wbjtu/tzbjtu/somental/qwen35_9b_concept_sft_project_v2
conda activate sft
```

### 2. Prepare v2 SFT data

```bash
python scripts/prepare_sft_data_v2.py \
  --base_dir /mnt/disk1/wbjtu/tzbjtu/somental/data/finetune \
  --output_dir /mnt/disk1/wbjtu/tzbjtu/somental/data/finetune/qwen_sft_merged_v2 \
  --test_ratio 0.1 \
  --seed 42 \
  --save_normalized \
  --preview 2
```

Expected full-data distribution:

```text
Train JSONL: 70434 examples
Test JSONL : 7825 examples

CAMS                  train=1644 test=183
GoEmotions            train=48837 test=5426
LoST                  train=4882 test=542
LonXplain             train=3170 test=352
MultiWD               train=2953 test=328
SAD                   train=6165 test=685
WellnessDimensions    train=2783 test=309
```

### 3. Token-length audit

```bash
bash scripts/run_token_length_audit_v2.sh
```

Observed token-length summary:

```text
n = 78259
mean = 273.31
median = 232
p95 = 485
p99 = 637
max = 36679
over_1024 = 101
over_2048 = 14
```

Training decision:

```text
Use max_seq_length = 1024.
Do not increase global sequence length for the small CAMS long-tail.
```

### 4. Build balanced train/validation data

```bash
bash scripts/run_build_balanced_v2.sh
```

Balanced training policy:

```text
- Keep all non-GoEmotions training rows.
- Cap GoEmotions to 20,000 using label-aware sampling.
- Drop training rows with token length > 2048.
- Keep full test set unchanged.
```

Final balanced distribution:

```text
train_for_sft.jsonl total: 39506
GoEmotions               19000
SAD                       5857
LoST                      4638
LonXplain                 3012
MultiWD                   2805
WellnessDimensions        2644
CAMS                      1550

val_for_epoch_select.jsonl total: 2079
GoEmotions                1000
SAD                        308
LoST                       244
LonXplain                  158
MultiWD                    148
WellnessDimensions         139
CAMS                        82

aggregated_test.jsonl total: 7825
GoEmotions                5426
SAD                        685
LoST                       542
LonXplain                  352
MultiWD                    328
WellnessDimensions         309
CAMS                       183
```

### 5. Train QLoRA on 4 L20 GPUs

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 bash scripts/run_train_v2_4gpu.sh
```

Training settings:

```text
num_processes = 4
max_seq_length = 1024
per_device_train_batch_size = 2
gradient_accumulation_steps = 4
effective batch size = 4 × 2 × 4 = 32
LoRA rank = 16
LoRA alpha = 32
bf16 = true
DeepSpeed = not used
```

Monitor:

```bash
watch -n 5 gpustat
```

Tail latest log:

```bash
tail -f $(ls -t outputs/logs/train_qwen35_9b_lora_v2_4gpu_*.log | head -n 1)
```

Successful training output:

```text
[DONE] Saved LoRA adapter to:
outputs/adapter/qwen35_9b_concept_sft_lora_v2_4gpu/final_adapter
```

### 6. Evaluate with 4 PEFT shards

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 bash scripts/run_eval_peft_v2_4gpu_parallel.sh
```

Merged outputs:

```text
outputs/predictions/test_predictions_peft_qwen35_9b_v2_4gpu_parallel.jsonl
outputs/metrics/test_metrics_peft_qwen35_9b_v2_4gpu_parallel.json
```

### 7. Add WellnessDimensions metrics if needed

```bash
python scripts/add_wellness_metrics.py \
  --predictions outputs/predictions/test_predictions_peft_qwen35_9b_v2_4gpu_parallel.jsonl \
  --metrics outputs/metrics/test_metrics_peft_qwen35_9b_v2_4gpu_parallel.json \
  --backup
```

### 8. Package final LoRA model

```bash
bash scripts/package_lora_v2.sh
```

Expected final package:

```text
/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B-concept-sft-lora-v2
```

This package is not a merged full model. It should be used as:

```text
Qwen3.5-9B base model + Qwen3.5-9B-concept-sft-lora-v2 adapter
```

### 9. vLLM LoRA smoke test

Example using physical GPUs 0,1,2,7:

```bash
conda activate vllm

cd /mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B-concept-sft-lora-v2

CUDA_VISIBLE_DEVICES=0,1,2,7 \
python vllm_lora_infer.py \
  --base_model /mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B \
  --adapter /mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B-concept-sft-lora-v2/adapter \
  --tp_size 4 \
  --gpu_memory_utilization 0.70 \
  --disable_custom_all_reduce \
  --enforce_eager \
  --max_tokens 64 \
  --prompt 'Task: Detect whether the text expresses low self-esteem.

Definition:
Low self-esteem means the author negatively evaluates their own worth, adequacy, ability, value, or identity.

Text:
Successful people are usually strong physically and mentally, and I am neither.

Return only JSON with this schema:
{"low_self_esteem":"present|absent"}'
```

Expected output:

```json
{"low_self_esteem":"present"}
```

---

## Problems Encountered and Solutions

### Problem 2: LoST loaded 0 examples

Symptom:

```text
[INFO] load_lost: +0 examples
```

Cause:

```text
LoST files use label column `self`, but the loader only searched generic label columns.
```

Actual columns:

```text
LoST_v1.csv: text, self
LoST_v2_train/test.csv: text, self, Trigger, LoST, Consequences
```

Solution:

Patch `load_lost()` to search these label columns:

```python
["self", "LoST", "lost", "low_self_esteem", "label", "Label", "labels", "class", "target"]
```

Expected result:

```text
[INFO] load_lost: +5424 examples
```

---

### Problem 3: WellnessDimensions missing from dataset distribution

Symptom:

```text
WellnessDimensions absent from dataset stats.
```

Cause:

```text
load_wellnessdimensions was missing from the active loaders list, and the function was missing in the generated v2 script.
```

Solution:

Add `load_wellnessdimensions()` and include it in the active loader list:

```python
loaders = [
    load_cams,
    load_lost,
    load_lonesomeness,
    load_multiwd,
    load_wellnessdimensions,
    load_sad,
    load_goemotions,
]
```

---

### Problem 4: WellnessDimensions found file but loaded 0 examples

Symptom:

```text
[INFO] WellnessDimensions files found:
       dataset_wellnessdimensions.csv
[INFO] load_wellnessdimensions: +0 examples
```

Failed rows showed:

```text
name 'normalize_wellness_aspect' is not defined
```

Cause:

```text
The loader called normalize_wellness_aspect(), but the function was missing.
```

Solution:

Add:

```python
def normalize_wellness_aspect(x):
    aspect_map = {
        1: "Physical",
        2: "Intellectual_Vocational",
        3: "Social",
        4: "Spiritual_Emotional",
    }
```

Expected result:

```text
[INFO] load_wellnessdimensions: +3092 examples
```

---

### Problem 5: Token-length audit originally returned mean length = 2

Symptom:

```text
mean = 2
max = 2
```

Cause:

```text
The tokenizer returned an object whose len() was not the real token length when using apply_chat_template(tokenize=True).
```

Solution:

Render chat template as text first:

```python
rendered = tok.apply_chat_template(messages, tokenize=False)
ids = tok(rendered, add_special_tokens=False)["input_ids"]
token_count = len(ids)
```

Correct result:

```text
mean ≈ 273
p95 ≈ 485
p99 ≈ 637
```

---

### Problem 6: Dataset rebalancing used unstable Python hash()

Symptom:

```bash
grep -n "hash(" scripts/build_balanced_train_val.py
```

returned:

```python
random.Random(seed + hash(ds) % 1000000).shuffle(ds_rows)
```

Problem:

```text
Python hash() is not stable across sessions unless PYTHONHASHSEED is fixed.
```

Solution:

Use MD5-based deterministic seed:

```python
def stable_dataset_seed(seed: int, dataset: str) -> int:
    h = hashlib.md5(dataset.encode("utf-8")).hexdigest()
    return seed + int(h[:8], 16)
```

Then:

```python
random.Random(stable_dataset_seed(seed, ds)).shuffle(ds_rows)
```

---

### Problem 7: CAMS had lower schema-validity

Symptom:

```text
CAMS schema_valid_rate ≈ 0.907
bad CAMS = 17 / 183
```

Bad outputs included:

```text
empty outputs
truncated JSON
non-JSON text
```

Cause:

```text
CAMS requires both a numeric causal category and a free-text causal interpretation.
Some interpretation generations were long and got truncated by max_new_tokens.
```

Current decision:

```text
Proceed because global schema-validity is 0.9978 and CAMS remains above 90%.
```

Future improvement:

```text
Re-evaluate CAMS with larger max_new_tokens, e.g. 256.
```

---

### Problem 8: WellnessDimensions metrics missing

Symptom:

```json
"WellnessDimensions": {
  "n": 309,
  "json_parse_rate": 1.0,
  "schema_valid_rate": 1.0
}
```

Cause:

```text
Predictions were valid, but the metrics code did not compute wellness_aspect accuracy, macro-F1, or span metrics.
```

Solution:

Add `scripts/add_wellness_metrics.py` and call it after merged PEFT eval:

```bash
python scripts/add_wellness_metrics.py \
  --predictions outputs/predictions/test_predictions_peft_qwen35_9b_v2_4gpu_parallel.jsonl \
  --metrics outputs/metrics/test_metrics_peft_qwen35_9b_v2_4gpu_parallel.json \
  --backup
```

Expected added fields:

```text
aspect_metrics.accuracy
aspect_metrics.macro_f1
aspect_metrics.per_label_f1
span_exact_match
span_token_f1
```
