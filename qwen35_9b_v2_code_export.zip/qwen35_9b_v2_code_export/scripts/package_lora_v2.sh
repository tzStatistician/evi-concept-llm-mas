#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/qwen35_9b_concept_sft_project_v2}"
MODEL_ROOT="${MODEL_ROOT:-/mnt/disk1/wbjtu/tzbjtu/somental/models}"
BASE_MODEL="${BASE_MODEL:-/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B}"
ADAPTER_SRC="${ADAPTER_SRC:-${PROJECT_DIR}/outputs/adapter/qwen35_9b_concept_sft_lora_v2_4gpu/final_adapter}"
MODEL_NAME="${MODEL_NAME:-Qwen3.5-9B-concept-sft-lora-v2}"
OUT_DIR="${MODEL_ROOT}/${MODEL_NAME}"

if [[ ! -f "${ADAPTER_SRC}/adapter_config.json" || ! -f "${ADAPTER_SRC}/adapter_model.safetensors" ]]; then
  echo "[ERROR] Adapter files not found in ${ADAPTER_SRC}" >&2
  exit 1
fi

rm -rf "${OUT_DIR}"
mkdir -p "${OUT_DIR}"
cp -a "${ADAPTER_SRC}" "${OUT_DIR}/adapter"
cp "${PROJECT_DIR}/scripts/vllm_lora_infer.py" "${OUT_DIR}/vllm_lora_infer.py" 2>/dev/null || true

cat > "${OUT_DIR}/model_paths.json" <<EOF
{
  "model_name": "${MODEL_NAME}",
  "type": "vllm_peft_lora_adapter",
  "base_model": "${BASE_MODEL}",
  "adapter": "${OUT_DIR}/adapter",
  "recommended_visible_gpus": "0,1,2,3",
  "recommended_tp_size": 4,
  "note": "This is a LoRA adapter package, not a standalone full merged model."
}
EOF

cat > "${OUT_DIR}/README.md" <<EOF
# ${MODEL_NAME}

Base model:
${BASE_MODEL}

Adapter:
${OUT_DIR}/adapter

Recommended vLLM LoRA test:

\`\`\`bash
conda activate vllm
cd ${OUT_DIR}
CUDA_VISIBLE_DEVICES=0,1,2,3 python vllm_lora_infer.py \\
  --base_model ${BASE_MODEL} \\
  --adapter ${OUT_DIR}/adapter \\
  --tp_size 4 \\
  --gpu_memory_utilization 0.70 \\
  --disable_custom_all_reduce \\
  --enforce_eager \\
  --max_tokens 64 \\
  --prompt '<your prompt>'
\`\`\`
EOF

du -sh "${OUT_DIR}"
find "${OUT_DIR}" -maxdepth 2 -type f -print
