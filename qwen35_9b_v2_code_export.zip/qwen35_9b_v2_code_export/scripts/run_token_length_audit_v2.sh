#!/usr/bin/env bash
set -euo pipefail

MODEL_PATH="${MODEL_PATH:-/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B}"
DATA_DIR="${DATA_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/data/finetune/qwen_sft_merged_v2}"
PROJECT_DIR="${PROJECT_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/qwen35_9b_concept_sft_project_v2}"

python "${PROJECT_DIR}/scripts/token_length_audit.py" \
  --model "${MODEL_PATH}" \
  --files "${DATA_DIR}/aggregated_train.jsonl" "${DATA_DIR}/aggregated_test.jsonl" \
  --output_json "${DATA_DIR}/token_length_stats_v2_fixed.json" \
  --output_csv "${DATA_DIR}/token_length_rows_v2_fixed.csv" \
  --trust_remote_code
