#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fine_tune_data_create.py

Create aggregated Qwen chat-style SFT data from heterogeneous mental-health
annotation datasets.

Policy implemented:
1. Load every available file under --base_dir.
2. For each dataset, concatenate all original train/test/dev/val splits.
3. Normalize rows into dataset-specific annotation examples.
4. Split inside each dataset with a 9:1 train/test ratio by default.
5. Merge all dataset train splits and all dataset test splits.
6. Shuffle final train/test independently.
7. Save:
   - aggregated_train.jsonl
   - aggregated_test.jsonl
   - dataset_stats.json
   - failed_rows.jsonl

Example:
python fine_tune_data_create.py \
  --base_dir /mnt/disk1/wbjtu/tzbjtu/somental/data/finetune \
  --output_dir /mnt/disk1/wbjtu/tzbjtu/somental/data/finetune/qwen_sft_merged \
  --test_ratio 0.1 \
  --seed 42
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import pandas as pd


# -----------------------------
# Prompt templates
# -----------------------------

SYSTEM_PROMPT = (
    "You are a strict text annotation engine. "
    "Return only one valid compact JSON object matching the required schema. "
    "Do not explain. Do not think step by step. Do not output markdown."
)

TASK_PROMPTS: Dict[str, Dict[str, str]] = {
    "CAMS": {"instruction": "Task: Identify the explicit primary cause of mental-health distress in the text.\n\nAllowed causal_category values:\n\"0.0\" = no explicit cause is stated\n\"1.0\" = bias, abuse, bullying, harassment, discrimination, body shaming, physical abuse, sexual abuse, or emotional abuse\n\"2.0\" = job, career, school, academic pressure, unemployment, financial pressure, or work-related failure\n\"3.0\" = medication, treatment, physical illness, mental-health condition, hospital care, or medication-induced distress\n\"4.0\" = relationship, family, partner, breakup, friendship, interpersonal conflict, or loss of close social ties\n\"5.0\" = alienation, isolation, social exclusion, worthlessness, purposelessness, or lack of belonging\n\nDecision rules:\n- Choose exactly one causal_category.\n- Use only causes explicitly supported by the text.\n- Do not infer hidden or unstated causes.\n- If multiple causes are stated, choose the primary/root cause.\n- If no clear direct cause is stated, use \"0.0\".\n- causal_interpretation must be a short phrase copied or closely grounded in the text.\n- If causal_category is \"0.0\", causal_interpretation must be an empty string.\n\nText:\n{TEXT}\n\nReturn only JSON with this schema:\n{\"causal_category\":\"0.0|1.0|2.0|3.0|4.0|5.0\",\"causal_interpretation\":\"<short grounded phrase or empty string>\"}"},
    "LoST": {"instruction": "Task: Detect whether the text expresses low self-esteem.\n\nDefinition:\nLow self-esteem means the author negatively evaluates their own worth, adequacy, ability, value, or identity.\n\nLabel \"present\" when the text contains explicit self-devaluation, personal inadequacy, inferiority comparison, self-directed shame, self-hatred, or lack of confidence tied to the self.\nLabel \"absent\" when the text only shows sadness, stress, loneliness, suicidal ideation, social rejection, desire for support, or external problems without explicit negative self-worth.\n\nDecision rule:\n- Focus on the low-self-esteem indicator itself, not merely the trigger or consequence.\n\nText:\n{TEXT}\n\nReturn only JSON with this schema:\n{\"low_self_esteem\":\"present|absent\"}"},
    "LonXplain": {"instruction": "Task: Detect whether the text expresses lonesomeness and return the supporting span.\n\nDefinition:\nLonesomeness means distress caused by lack of meaningful social connection, belonging, companionship, or emotional closeness.\n\nLabel \"present\" when the author expresses loneliness, social isolation/disconnection, lack of meaningful relationships/support, abandonment, or having nobody to talk to.\nLabel \"absent\" for generic sadness, depression, stress, preference for solitude, or being physically alone without distress about social connection.\n\nEvidence rule:\n- evidence_span should be the shortest span directly supporting the label.\n- If absent, evidence_span must be empty.\n\nText:\n{TEXT}\n\nReturn only JSON with this schema:\n{\"lonesomeness\":\"present|absent\",\"evidence_span\":\"<short supporting span or empty string>\"}"},
    "MultiWD": {"instruction": "Task: Identify all wellness dimensions explicitly reflected in the text.\n\nDimensions:\nSpiritual = meaning, purpose, values, existential concerns, faith, hope, hopelessness, or life direction\nPhysical = body, sleep, fatigue, pain, illness, exercise, eating, substance use, or physical health\nIntellectual = thinking, learning, cognition, curiosity, decision-making, problem-solving, or mental growth\nSocial = relationships, family, friends, belonging, support, social conflict, or social isolation\nVocational = work, job, career, school performance, productivity, professional role, or academic/work functioning\nEmotional = emotions, mood, affective distress, emotional regulation, anxiety, anger, guilt, shame, sadness, or joy\n\nDecision rules:\n- This is multi-label: evaluate each dimension independently.\n- Mark 1 only when directly supported.\n- Multiple dimensions may be 1.\n\nText:\n{TEXT}\n\nReturn only JSON with this schema:\n{\"Spiritual\":0|1,\"Physical\":0|1,\"Intellectual\":0|1,\"Social\":0|1,\"Vocational\":0|1,\"Emotional\":0|1}"},
    "WellnessDimensions": {"instruction": "Task: Classify the text into exactly one dominant wellness dimension and return the supporting span.\n\nAllowed wellness_aspect values:\nPhysical = bodily health, sleep, fatigue, pain, illness, physical functioning, eating, exercise, or substance-related physical condition\nIntellectual_Vocational = school, work, career, achievement, productivity, learning, competence, goals, or academic/work functioning\nSocial = friends, family, romantic relationships, interpersonal conflict, social support, belonging, or social connection\nSpiritual_Emotional = guilt, shame, hopelessness, emptiness, emotional pain, self-worth, meaning, purpose, values, or existential distress\n\nDecision rules:\n- Choose exactly one wellness_aspect.\n- Choose the dominant dimension most directly reflected in the text.\n- evidence_span should be short and grounded in the text.\n\nText:\n{TEXT}\n\nReturn only JSON with this schema:\n{\"wellness_aspect\":\"Physical|Intellectual_Vocational|Social|Spiritual_Emotional\",\"evidence_span\":\"<short supporting span or empty string>\"}"},
    "SAD": {"instruction": "Task: Detect whether the text contains an explicit everyday stressor and identify its stressor category.\n\nDefinition:\nA stressor is an identifiable source of psychological strain, burden, worry, or pressure.\n\nAllowed stress_label values:\nFinancial Problem, Family Issues, Social Relationships, Work, School, Emotional Turmoil, Health/Fatigue/Physical Pain, Everyday Decision Making, Other\n\nDecision rules:\n- is_stressor is 1 only when an explicit stressor source is present.\n- Emotional expression alone is not enough unless it is the stressor being described.\n- If is_stressor is 0, stress_label must be an empty string.\n- If more than one category appears, choose the most specific or dominant source.\n\nText:\n{TEXT}\n\nReturn only JSON with this schema:\n{\"is_stressor\":0|1,\"stress_label\":\"Financial Problem|Family Issues|Social Relationships|Work|School|Emotional Turmoil|Health/Fatigue/Physical Pain|Everyday Decision Making|Other|\"}"},
    "GoEmotions": {"instruction": "Task: Identify all emotions directly expressed in the text.\n\nAllowed labels:\nadmiration, amusement, anger, annoyance, approval, caring, confusion, curiosity, desire, disappointment, disapproval, disgust, embarrassment, excitement, fear, gratitude, grief, joy, love, nervousness, optimism, pride, realization, relief, remorse, sadness, surprise, neutral\n\nDecision rules:\n- Select all emotions directly expressed by the text.\n- Multiple emotion labels are allowed.\n- Use neutral only when no specific emotion is clearly expressed.\n- If neutral is selected, do not include other labels.\n\nText:\n{TEXT}\n\nReturn only JSON with this schema:\n{\"emotions\":[\"<one or more allowed labels>\"]}"},
}

# -----------------------------
# Utilities
# -----------------------------

def clean_text(x: Any) -> str:
    """Normalize text content for SFT."""
    if x is None:
        return ""
    if isinstance(x, float) and math.isnan(x):
        return ""
    s = str(x)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def is_missing(x: Any) -> bool:
    if x is None:
        return True
    if isinstance(x, float) and math.isnan(x):
        return True
    s = str(x).strip()
    return s == "" or s.lower() in {"nan", "none", "null", "<na>"}


def to_int01(x: Any) -> int:
    """Convert common binary label formats to 0/1."""
    if isinstance(x, bool):
        return int(x)
    if isinstance(x, (int, float)) and not (isinstance(x, float) and math.isnan(x)):
        return 1 if int(float(x)) == 1 else 0
    s = str(x).strip().lower()
    if s in {"1", "true", "yes", "y", "present", "positive"}:
        return 1
    if s in {"0", "false", "no", "n", "absent", "negative"}:
        return 0
    # Try percentage/float-like values only if exactly numeric.
    try:
        return 1 if int(float(s)) == 1 else 0
    except Exception:
        raise ValueError(f"Cannot convert to binary label: {x!r}")


def present_absent(x: Any) -> str:
    return "present" if to_int01(x) == 1 else "absent"


CAMS_LABEL_MAP = {0: "0.0", 1: "1.0", 2: "2.0", 3: "3.0", 4: "4.0", 5: "5.0"}


def normalize_cams_label(x: Any) -> str:
    s = clean_text(x)
    if not s:
        raise ValueError("missing CAMS label")
    try:
        i = int(float(s))
        if i in CAMS_LABEL_MAP:
            return CAMS_LABEL_MAP[i]
    except Exception:
        pass
    aliases = {
        "no reason": "0.0", "none": "0.0", "other": "0.0",
        "bias": "1.0", "abuse": "1.0", "bias or abuse": "1.0", "bias/abuse": "1.0",
        "jobs and careers": "2.0", "jobs/careers": "2.0", "job": "2.0", "career": "2.0", "school": "2.0", "education": "2.0", "work": "2.0", "financial problem": "2.0",
        "medication": "3.0", "medicine": "3.0", "health": "3.0", "health issues": "3.0", "mental health issue": "3.0",
        "relationship": "4.0", "relationships": "4.0", "relationship issues": "4.0", "family": "4.0", "family issues": "4.0", "social relationships": "4.0",
        "alienation": "5.0", "social": "5.0", "social issues": "5.0", "loss": "5.0", "isolation": "5.0", "loneliness": "5.0",
    }
    key = s.lower().strip()
    if key in aliases:
        return aliases[key]
    raise ValueError(f"unknown CAMS label: {x!r}")



def normalize_wellness_aspect(x: Any) -> str:
    """
    Normalize original WellnessDimensions Aspect labels.

    Original human-annotated mapping:
      1 = Physical
      2 = Intellectual_Vocational
      3 = Social
      4 = Spiritual_Emotional
    """
    s = clean_text(x)
    if not s:
        raise ValueError("missing WellnessDimensions Aspect")

    try:
        v = int(float(s))
    except Exception as e:
        raise ValueError(f"invalid WellnessDimensions Aspect: {x!r}") from e

    aspect_map = {
        1: "Physical",
        2: "Intellectual_Vocational",
        3: "Social",
        4: "Spiritual_Emotional",
    }

    if v not in aspect_map:
        raise ValueError(f"unknown WellnessDimensions Aspect id: {x!r}")

    return aspect_map[v]


def stable_dataset_seed(seed: int, dataset: str) -> int:
    h = hashlib.md5(dataset.encode("utf-8")).hexdigest()
    return seed + int(h[:8], 16)


def compact_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def first_existing_col(df: pd.DataFrame, candidates: Sequence[str]) -> Optional[str]:
    lower_map = {str(c).strip().lower(): c for c in df.columns}
    for cand in candidates:
        c = lower_map.get(cand.strip().lower())
        if c is not None:
            return c
    return None


def read_csv_flexible(path: Path) -> pd.DataFrame:
    """Read CSV/TSV-like files robustly."""
    # Try normal CSV first.
    try:
        return pd.read_csv(path)
    except Exception:
        pass

    # Try Python engine with bad-line skipping.
    try:
        return pd.read_csv(path, engine="python", on_bad_lines="skip")
    except Exception:
        pass

    # Try TSV.
    try:
        return pd.read_csv(path, sep="\t")
    except Exception:
        pass

    # Try common encodings.
    for enc in ["utf-8-sig", "latin1"]:
        try:
            return pd.read_csv(path, encoding=enc, engine="python", on_bad_lines="skip")
        except Exception:
            continue

    raise RuntimeError(f"Failed to read CSV-like file: {path}")


def add_failed(
    failed: List[Dict[str, Any]],
    dataset: str,
    source_file: str,
    row_index: Any,
    reason: str,
    row: Optional[Any] = None,
) -> None:
    item: Dict[str, Any] = {
        "dataset": dataset,
        "source_file": source_file,
        "row_index": row_index,
        "reason": reason,
    }
    if row is not None:
        try:
            if hasattr(row, "to_dict"):
                item["row"] = {str(k): clean_text(v) for k, v in row.to_dict().items()}
            elif isinstance(row, dict):
                item["row"] = {str(k): clean_text(v) for k, v in row.items()}
            else:
                item["row"] = clean_text(row)
        except Exception:
            item["row"] = "<failed_to_serialize_row>"
    failed.append(item)


def make_example(
    dataset: str,
    text: str,
    gold_output: Dict[str, Any],
    source_file: str,
    row_index: Any,
) -> Dict[str, Any]:
    text = clean_text(text)
    if not text:
        raise ValueError("empty text")
    if not isinstance(gold_output, dict) or not gold_output:
        raise ValueError("empty gold_output")
    return {
        "dataset": dataset,
        "text": text,
        "gold_output": gold_output,
        "source_file": source_file,
        "row_index": row_index,
    }


def to_qwen_chat_sft(ex: Dict[str, Any]) -> Dict[str, Any]:
    user_content = TASK_PROMPTS[ex["dataset"]]["instruction"].replace("{TEXT}", ex["text"])
    return {
        "dataset": ex["dataset"],
        "source_file": ex.get("source_file", ""),
        "row_index": ex.get("row_index", None),
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_content},
            {"role": "assistant", "content": compact_json(ex["gold_output"])},
        ],
    }


def write_jsonl(path: Path, rows: Iterable[Dict[str, Any]]) -> int:
    n = 0
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            n += 1
    return n


# -----------------------------
# Dataset loaders
# -----------------------------

def load_cams(base_dir: Path, failed: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    dataset = "CAMS"
    files = [
        base_dir / "IntentSDCNL_Training.csv",
        base_dir / "IntentSDCNL_Testing.csv",
        base_dir / "added_CAMS_data.csv",
    ]
    examples: List[Dict[str, Any]] = []

    for path in files:
        if not path.exists():
            continue
        try:
            df = read_csv_flexible(path)
        except Exception as e:
            add_failed(failed, dataset, str(path), None, f"read_error: {e}")
            continue

        text_col = first_existing_col(df, ["selftext", "text", "Text", "post", "sentence", "content"])
        category_col = first_existing_col(df, ["ANNOTATIONS", "annotations", "annotation", "label", "category", "causal_category"])
        interp_col = first_existing_col(df, ["Interpretations", "interpretations", "interpretation", "causal_interpretation", "reason"])

        if text_col is None or category_col is None:
            add_failed(
                failed, dataset, str(path), None,
                f"missing required columns. columns={list(df.columns)}"
            )
            continue

        for i, row in df.iterrows():
            try:
                text = clean_text(row[text_col])
                cat = normalize_cams_label(row[category_col])
                interp = clean_text(row[interp_col]) if interp_col is not None else ""
                if not text or not cat:
                    raise ValueError("missing text/category")
                if cat == "0.0":
                    interp = ""
                examples.append(
                    make_example(
                        dataset=dataset,
                        text=text,
                        gold_output={
                            "causal_category": cat,
                            "causal_interpretation": interp,
                        },
                        source_file=str(path),
                        row_index=int(i),
                    )
                )
            except Exception as e:
                add_failed(failed, dataset, str(path), int(i), str(e), row)

    return examples


def load_lost(base_dir: Path, failed: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    dataset = "LoST"
    files = [
        base_dir / "LoST_v1.csv",
        base_dir / "LoST_v2_train.csv",
        base_dir / "LoST_v2_test.csv",
    ]
    examples: List[Dict[str, Any]] = []

    for path in files:
        if not path.exists():
            continue
        try:
            df = read_csv_flexible(path)
        except Exception as e:
            add_failed(failed, dataset, str(path), None, f"read_error: {e}")
            continue

        text_col = first_existing_col(df, ["text", "Text", "post", "sentence", "selftext", "content"])
        label_col = first_existing_col(df, ["self", "LoST", "lost", "low_self_esteem", "label", "Label", "labels", "class", "target"])
        if text_col is None or label_col is None:
            add_failed(
                failed, dataset, str(path), None,
                f"missing required columns. columns={list(df.columns)}"
            )
            continue

        for i, row in df.iterrows():
            try:
                examples.append(
                    make_example(
                        dataset=dataset,
                        text=row[text_col],
                        gold_output={"low_self_esteem": present_absent(row[label_col])},
                        source_file=str(path),
                        row_index=int(i),
                    )
                )
            except Exception as e:
                add_failed(failed, dataset, str(path), int(i), str(e), row)

    return examples


def load_lonesomeness(base_dir: Path, failed: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    dataset = "LonXplain"
    path = base_dir / "lonesomeness_dataset.csv"
    examples: List[Dict[str, Any]] = []
    if not path.exists():
        return examples

    try:
        df = read_csv_flexible(path)
    except Exception as e:
        add_failed(failed, dataset, str(path), None, f"read_error: {e}")
        return examples

    text_col = first_existing_col(df, ["text", "Text", "post", "sentence", "content"])
    label_col = first_existing_col(df, ["tb", "label", "Label", "lonesomeness"])
    exp_col = first_existing_col(df, ["tb_exp", "explanation", "evidence_span", "span", "rationale"])
    if text_col is None or label_col is None:
        add_failed(
            failed, dataset, str(path), None,
            f"missing required columns. columns={list(df.columns)}"
        )
        return examples

    for i, row in df.iterrows():
        try:
            label = present_absent(row[label_col])
            span = clean_text(row[exp_col]) if exp_col is not None and not is_missing(row[exp_col]) else ""
            if label == "absent":
                # For absent examples, avoid training a non-empty explanation unless the dataset explicitly stores one.
                span = ""
            examples.append(
                make_example(
                    dataset=dataset,
                    text=row[text_col],
                    gold_output={"lonesomeness": label, "evidence_span": span},
                    source_file=str(path),
                    row_index=int(i),
                )
            )
        except Exception as e:
            add_failed(failed, dataset, str(path), int(i), str(e), row)

    return examples


def load_multiwd(base_dir: Path, failed: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    dataset = "MultiWD"
    files = [base_dir / "MultiWD_train.csv", base_dir / "MultiWD_test.csv"]
    examples: List[Dict[str, Any]] = []
    canonical_labels = ["Spiritual", "Physical", "Intellectual", "Social", "Vocational", "Emotional"]
    alt_labels = {
        "Spiritual": ["Spiritual", "SpA", "spiritual"],
        "Physical": ["Physical", "PA", "physical"],
        "Intellectual": ["Intellectual", "IA", "intellectual"],
        "Social": ["Social", "SA", "social"],
        "Vocational": ["Vocational", "VA", "vocational"],
        "Emotional": ["Emotional", "EA", "emotional"],
    }

    for path in files:
        if not path.exists():
            continue
        try:
            df = read_csv_flexible(path)
        except Exception as e:
            add_failed(failed, dataset, str(path), None, f"read_error: {e}")
            continue

        text_col = first_existing_col(df, ["text", "Text", "post", "sentence", "selftext", "content"])
        label_cols = {label: first_existing_col(df, cands) for label, cands in alt_labels.items()}

        if text_col is None or any(v is None for v in label_cols.values()):
            add_failed(
                failed, dataset, str(path), None,
                f"missing required columns. columns={list(df.columns)} label_cols={label_cols}"
            )
            continue

        for i, row in df.iterrows():
            try:
                output = {label: to_int01(row[label_cols[label]]) for label in canonical_labels}  # type: ignore[index]
                examples.append(
                    make_example(
                        dataset=dataset,
                        text=row[text_col],
                        gold_output=output,
                        source_file=str(path),
                        row_index=int(i),
                    )
                )
            except Exception as e:
                add_failed(failed, dataset, str(path), int(i), str(e), row)

    return examples



def load_wellnessdimensions(base_dir: Path, failed: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    dataset = "WellnessDimensions"

    # Human-only original files.
    # Do NOT load s1_training_dataset_chatgpt1.csv or any GPT/ChatGPT-augmented file.
    files = [
        base_dir / "dataset_wellnessdimensions.csv",
        base_dir / "WellnessDimensions_dataset.csv",
    ]

    # Robust fallback for slightly different local naming.
    for fp in base_dir.rglob("*.csv"):
        name = fp.name.lower()
        if fp in files:
            continue
        if "wellness" in name and "chatgpt" not in name and "gpt" not in name:
            files.append(fp)
        elif name == "dataset_wellnessdimensions.csv":
            files.append(fp)

    files = sorted(set(fp for fp in files if fp.exists()))

    if not files:
        add_failed(failed, dataset, str(base_dir), None, "no human WellnessDimensions csv file found")
        return []

    print("[INFO] WellnessDimensions files found:")
    for fp in files:
        print(f"       {fp}")

    examples: List[Dict[str, Any]] = []

    for path in files:
        try:
            df = read_csv_flexible(path)
        except Exception as e:
            add_failed(failed, dataset, str(path), None, f"read_error: {e}")
            continue

        text_col = first_existing_col(df, ["Text", "text", "post", "sentence", "selftext", "content", "body"])
        aspect_col = first_existing_col(df, ["Aspect", "aspect", "label", "Label"])
        exp_col = first_existing_col(df, ["Explanations", "explanations", "explanation", "rationale", "span"])

        if text_col is None or aspect_col is None:
            add_failed(
                failed,
                dataset,
                str(path),
                None,
                f"missing required columns. columns={list(df.columns)}",
            )
            continue

        for i, row in df.iterrows():
            try:
                text = clean_text(row[text_col])
                if not text:
                    raise ValueError("empty text")

                aspect = normalize_wellness_aspect(row[aspect_col])
                evidence = clean_text(row[exp_col]) if exp_col is not None and not is_missing(row[exp_col]) else ""

                examples.append(
                    make_example(
                        dataset=dataset,
                        text=text,
                        gold_output={
                            "wellness_aspect": aspect,
                            "evidence_span": evidence,
                        },
                        source_file=str(path),
                        row_index=int(i),
                    )
                )
            except Exception as e:
                add_failed(failed, dataset, str(path), int(i), str(e), row)

    return examples


def load_sad(base_dir: Path, failed: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    dataset = "SAD"
    path = base_dir / "SAD" / "SAD_v1.xlsx"
    examples: List[Dict[str, Any]] = []
    if not path.exists():
        return examples

    try:
        df = pd.read_excel(path)
    except Exception as e:
        add_failed(failed, dataset, str(path), None, f"read_error: {e}")
        return examples

    text_col = first_existing_col(df, ["sentence", "text", "Text", "message", "utterance"])
    is_stressor_col = first_existing_col(df, ["is_stressor", "stressor", "label"])
    top_label_col = first_existing_col(df, ["top_label", "original_label", "label_name", "stress_label"])

    if text_col is None or is_stressor_col is None:
        add_failed(
            failed, dataset, str(path), None,
            f"missing required columns. columns={list(df.columns)}"
        )
        return examples

    for i, row in df.iterrows():
        try:
            is_stressor = to_int01(row[is_stressor_col])
            stress_label = clean_text(row[top_label_col]) if top_label_col is not None else ""
            if is_stressor == 0:
                stress_label = ""
            elif not stress_label:
                stress_label = "Other"
            examples.append(
                make_example(
                    dataset=dataset,
                    text=row[text_col],
                    gold_output={"is_stressor": is_stressor, "stress_label": stress_label},
                    source_file=str(path),
                    row_index=int(i),
                )
            )
        except Exception as e:
            add_failed(failed, dataset, str(path), int(i), str(e), row)

    return examples


def load_goemotions(base_dir: Path, failed: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    dataset = "GoEmotions"
    d = base_dir / "GoEmotions"
    files = [
        d / "GoEmotions_train.tsv",
        d / "GoEmotions_dev.tsv",
        d / "GoEmotions_test.tsv",
    ]
    emotions_path = d / "GoEmotions_emotions.txt"
    examples: List[Dict[str, Any]] = []

    if not emotions_path.exists():
        add_failed(failed, dataset, str(emotions_path), None, "missing emotions.txt")
        return examples

    emotions = [clean_text(x) for x in emotions_path.read_text(encoding="utf-8").splitlines() if clean_text(x)]
    if not emotions:
        add_failed(failed, dataset, str(emotions_path), None, "empty emotions.txt")
        return examples

    for path in files:
        if not path.exists():
            continue
        try:
            df = pd.read_csv(path, sep="\t", header=None, names=["text", "label_ids", "comment_id"], quoting=csv.QUOTE_NONE)
        except Exception:
            try:
                df = pd.read_csv(path, sep="\t", header=None, names=["text", "label_ids", "comment_id"])
            except Exception as e:
                add_failed(failed, dataset, str(path), None, f"read_error: {e}")
                continue

        for i, row in df.iterrows():
            try:
                label_ids_str = clean_text(row["label_ids"])
                label_ids = [int(x) for x in label_ids_str.split(",") if x.strip() != ""]
                labels = []
                for label_id in label_ids:
                    if label_id < 0 or label_id >= len(emotions):
                        raise ValueError(f"emotion id out of range: {label_id}; emotions length={len(emotions)}")
                    labels.append(emotions[label_id])
                examples.append(
                    make_example(
                        dataset=dataset,
                        text=row["text"],
                        gold_output={"emotions": labels},
                        source_file=str(path),
                        row_index=int(i),
                    )
                )
            except Exception as e:
                add_failed(failed, dataset, str(path), int(i), str(e), row)

    return examples


def load_depressionemo(base_dir: Path, failed: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    dataset = "DepressionEmo"
    d = base_dir / "DepressionEmo"
    files = [
        d / "DepressionEmo_train.json",
        d / "DepressionEmo_val.json",
        d / "DepressionEmo_test.json",
    ]
    label_names_path = d / "DepressionEmo_label_names.json"
    examples: List[Dict[str, Any]] = []

    label_names: List[str] = []
    if label_names_path.exists():
        try:
            obj = json.loads(label_names_path.read_text(encoding="utf-8"))
            if isinstance(obj, list):
                label_names = [str(x) for x in obj]
            elif isinstance(obj, dict):
                # Common cases: {"0": "anger", ...} or {"label_names": [...]}
                if "label_names" in obj and isinstance(obj["label_names"], list):
                    label_names = [str(x) for x in obj["label_names"]]
                else:
                    # Sort numeric-like keys if possible.
                    def key_fn(k: str) -> Tuple[int, str]:
                        try:
                            return (0, f"{int(k):04d}")
                        except Exception:
                            return (1, k)
                    label_names = [str(obj[k]) for k in sorted(obj.keys(), key=key_fn)]
        except Exception as e:
            add_failed(failed, dataset, str(label_names_path), None, f"label_names_read_error: {e}")

    for path in files:
        if not path.exists():
            continue
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            add_failed(failed, dataset, str(path), None, f"read_error: {e}")
            continue

        # Accept list of records or dict containing records.
        if isinstance(raw, dict):
            if "data" in raw and isinstance(raw["data"], list):
                records = raw["data"]
            elif "examples" in raw and isinstance(raw["examples"], list):
                records = raw["examples"]
            else:
                # Some JSON exports are dict keyed by id.
                records = list(raw.values())
        elif isinstance(raw, list):
            records = raw
        else:
            add_failed(failed, dataset, str(path), None, f"unsupported JSON root type: {type(raw)}")
            continue

        for i, rec in enumerate(records):
            try:
                if not isinstance(rec, dict):
                    raise ValueError("record is not dict")

                text = clean_text(rec.get("text"))
                if not text:
                    title = clean_text(rec.get("title"))
                    post = clean_text(rec.get("post"))
                    text = clean_text((title + "\n\n" + post).strip())

                emotions: List[str] = []
                if isinstance(rec.get("emotions"), list):
                    emotions = [clean_text(x) for x in rec["emotions"] if clean_text(x)]
                elif isinstance(rec.get("emotion"), list):
                    emotions = [clean_text(x) for x in rec["emotion"] if clean_text(x)]
                elif isinstance(rec.get("labels"), list) and rec["labels"] and isinstance(rec["labels"][0], str):
                    emotions = [clean_text(x) for x in rec["labels"] if clean_text(x)]
                elif not is_missing(rec.get("label_id")) and label_names:
                    label_id = clean_text(rec.get("label_id"))
                    # label_id may be a binary string such as "11000000".
                    # Decode 1 positions into label_names.
                    bits = re.sub(r"[^01]", "", label_id)
                    if bits:
                        # If label_names length differs, decode up to min length.
                        emotions = [label_names[j] for j, bit in enumerate(bits[:len(label_names)]) if bit == "1"]
                elif isinstance(rec.get("label_id"), list) and label_names:
                    emotions = [label_names[int(j)] for j in rec["label_id"]]

                if not emotions:
                    raise ValueError("missing emotions/label_id")

                examples.append(
                    make_example(
                        dataset=dataset,
                        text=text,
                        gold_output={"emotions": emotions},
                        source_file=str(path),
                        row_index=int(i),
                    )
                )
            except Exception as e:
                add_failed(failed, dataset, str(path), int(i), str(e), rec)

    return examples


# -----------------------------
# Split / stats
# -----------------------------

def split_by_dataset(
    examples: List[Dict[str, Any]],
    test_ratio: float,
    seed: int,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for ex in examples:
        grouped[ex["dataset"]].append(ex)

    train_all: List[Dict[str, Any]] = []
    test_all: List[Dict[str, Any]] = []

    for dataset in sorted(grouped.keys()):
        rows = list(grouped[dataset])
        rng = random.Random(stable_dataset_seed(seed, dataset))
        rng.shuffle(rows)

        n = len(rows)
        if n <= 1:
            n_test = 0
        else:
            n_test = max(1, int(round(n * test_ratio)))
            n_test = min(n_test, n - 1)

        test_rows = rows[:n_test]
        train_rows = rows[n_test:]

        train_all.extend(train_rows)
        test_all.extend(test_rows)

    rng = random.Random(seed)
    rng.shuffle(train_all)
    rng.shuffle(test_all)
    return train_all, test_all


def summarize_stats(
    all_examples: List[Dict[str, Any]],
    train_examples: List[Dict[str, Any]],
    test_examples: List[Dict[str, Any]],
    failed: List[Dict[str, Any]],
    args: argparse.Namespace,
) -> Dict[str, Any]:
    def count_by_dataset(rows: List[Dict[str, Any]]) -> Dict[str, int]:
        return dict(Counter(ex["dataset"] for ex in rows))

    all_counts = count_by_dataset(all_examples)
    train_counts = count_by_dataset(train_examples)
    test_counts = count_by_dataset(test_examples)

    by_dataset: Dict[str, Dict[str, Any]] = {}
    for d in sorted(all_counts):
        by_dataset[d] = {
            "total": all_counts.get(d, 0),
            "train": train_counts.get(d, 0),
            "test": test_counts.get(d, 0),
            "train_ratio": round(train_counts.get(d, 0) / all_counts[d], 6) if all_counts[d] else None,
            "test_ratio": round(test_counts.get(d, 0) / all_counts[d], 6) if all_counts[d] else None,
        }

    return {
        "base_dir": str(args.base_dir),
        "output_dir": str(args.output_dir),
        "seed": args.seed,
        "requested_test_ratio": args.test_ratio,
        "total_loaded_examples": len(all_examples),
        "total_train_examples": len(train_examples),
        "total_test_examples": len(test_examples),
        "total_failed_rows": len(failed),
        "by_dataset": by_dataset,
        "failed_by_dataset": dict(Counter(x.get("dataset", "UNKNOWN") for x in failed)),
    }


# -----------------------------
# Main
# -----------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base_dir",
        type=Path,
        default=Path("/mnt/disk1/wbjtu/tzbjtu/somental/data/finetune"),
        help="Directory containing all downloaded datasets.",
    )
    parser.add_argument(
        "--output_dir",
        type=Path,
        default=Path("/mnt/disk1/wbjtu/tzbjtu/somental/data/finetune/qwen_sft_merged_v2"),
        help="Directory to save aggregated_train.jsonl, aggregated_test.jsonl, and stats.",
    )
    parser.add_argument(
        "--test_ratio",
        type=float,
        default=0.1,
        help="Per-dataset test ratio. Default: 0.1 for 9:1 train/test split.",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducible splitting and shuffling.",
    )
    parser.add_argument(
        "--save_normalized",
        action="store_true",
        help="Also save normalized_train.jsonl and normalized_test.jsonl before chat conversion.",
    )
    parser.add_argument(
        "--preview",
        type=int,
        default=2,
        help="Number of examples per split to print after creation.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.base_dir = args.base_dir.expanduser().resolve()
    args.output_dir = args.output_dir.expanduser().resolve()

    if not args.base_dir.exists():
        raise FileNotFoundError(f"base_dir does not exist: {args.base_dir}")
    if not (0 < args.test_ratio < 1):
        raise ValueError("--test_ratio must be between 0 and 1")

    args.output_dir.mkdir(parents=True, exist_ok=True)

    failed: List[Dict[str, Any]] = []
    all_examples: List[Dict[str, Any]] = []

    loaders = [
        load_cams,
        load_lost,
        load_lonesomeness,
        load_multiwd,
        load_wellnessdimensions,
        load_sad,
        load_goemotions,
        # load_depressionemo,  # excluded: weak/LLM-assisted label concern
    ]

    print(f"[INFO] base_dir = {args.base_dir}")
    print("[INFO] Loading datasets...")

    for loader in loaders:
        before = len(all_examples)
        examples = loader(args.base_dir, failed)
        all_examples.extend(examples)
        print(f"[INFO] {loader.__name__}: +{len(all_examples) - before} examples")

    if not all_examples:
        raise RuntimeError("No examples loaded. Check --base_dir and file names.")

    print(f"[INFO] Total normalized examples: {len(all_examples)}")
    print(f"[INFO] Failed rows so far: {len(failed)}")

    train_norm, test_norm = split_by_dataset(
        examples=all_examples,
        test_ratio=args.test_ratio,
        seed=args.seed,
    )

    train_sft = [to_qwen_chat_sft(ex) for ex in train_norm]
    test_sft = [to_qwen_chat_sft(ex) for ex in test_norm]

    train_path = args.output_dir / "aggregated_train.jsonl"
    test_path = args.output_dir / "aggregated_test.jsonl"
    failed_path = args.output_dir / "failed_rows.jsonl"
    stats_path = args.output_dir / "dataset_stats.json"

    write_jsonl(train_path, train_sft)
    write_jsonl(test_path, test_sft)
    write_jsonl(failed_path, failed)

    if args.save_normalized:
        write_jsonl(args.output_dir / "normalized_train.jsonl", train_norm)
        write_jsonl(args.output_dir / "normalized_test.jsonl", test_norm)

    stats = summarize_stats(all_examples, train_norm, test_norm, failed, args)
    stats_path.write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")

    print("\n[DONE]")
    print(f"Train JSONL: {train_path} ({len(train_sft)} examples)")
    print(f"Test JSONL : {test_path} ({len(test_sft)} examples)")
    print(f"Stats     : {stats_path}")
    print(f"Failed    : {failed_path} ({len(failed)} rows)")

    print("\n[DATASET STATS]")
    for d, s in stats["by_dataset"].items():
        print(
            f"  {d:15s} total={s['total']:7d} "
            f"train={s['train']:7d} test={s['test']:6d} "
            f"train_ratio={s['train_ratio']:.4f} test_ratio={s['test_ratio']:.4f}"
        )

    if args.preview > 0:
        print("\n[PREVIEW TRAIN]")
        for row in train_sft[: args.preview]:
            print(json.dumps(row, ensure_ascii=False)[:1200] + "\n")

        print("\n[PREVIEW TEST]")
        for row in test_sft[: args.preview]:
            print(json.dumps(row, ensure_ascii=False)[:1200] + "\n")


if __name__ == "__main__":
    main()
