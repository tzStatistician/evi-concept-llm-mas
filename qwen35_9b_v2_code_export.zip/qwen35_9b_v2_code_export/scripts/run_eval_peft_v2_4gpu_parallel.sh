#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/qwen35_9b_concept_sft_project_v2}"
BASE_MODEL="${BASE_MODEL:-/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B}"
ADAPTER_DIR="${ADAPTER_DIR:-${PROJECT_DIR}/outputs/adapter/qwen35_9b_concept_sft_lora_v2_4gpu/final_adapter}"
TEST_FILE="${TEST_FILE:-${PROJECT_DIR}/data_v2_balanced_goemo20k/aggregated_test.jsonl}"
GPU_LIST="${GPU_LIST:-0,1,2,3}"
N_SHARDS=4
BATCH_SIZE="${BATCH_SIZE:-2}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-1024}"
MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-96}"

PRED_DIR="${PROJECT_DIR}/outputs/predictions/v2_peft_shards"
METRIC_DIR="${PROJECT_DIR}/outputs/metrics/v2_peft_shards"
LOG_DIR="${PROJECT_DIR}/outputs/logs/v2_peft_shards"
SHARD_DIR="${PROJECT_DIR}/data_v2_eval_shards"
OFFLOAD_DIR="${PROJECT_DIR}/outputs/offload/v2_peft_shards"
FINAL_PRED="${PROJECT_DIR}/outputs/predictions/test_predictions_peft_qwen35_9b_v2_4gpu_parallel.jsonl"
FINAL_METRIC="${PROJECT_DIR}/outputs/metrics/test_metrics_peft_qwen35_9b_v2_4gpu_parallel.json"

mkdir -p "${PRED_DIR}" "${METRIC_DIR}" "${LOG_DIR}" "${SHARD_DIR}" "${OFFLOAD_DIR}" "$(dirname "${FINAL_PRED}")" "$(dirname "${FINAL_METRIC}")"
rm -f "${SHARD_DIR}"/test_shard_*.jsonl "${PRED_DIR}"/pred_shard_*.jsonl "${METRIC_DIR}"/metric_shard_*.json "${LOG_DIR}"/eval_shard_*.log

python - <<PY
from pathlib import Path
src = Path("${TEST_FILE}")
out = Path("${SHARD_DIR}")
n = ${N_SHARDS}
handles = [open(out / f"test_shard_{i}.jsonl", "w", encoding="utf-8") for i in range(n)]
with src.open("r", encoding="utf-8") as f:
    for j, line in enumerate(f):
        if line.strip():
            handles[j % n].write(line)
for h in handles:
    h.close()
for i in range(n):
    p = out / f"test_shard_{i}.jsonl"
    print(p, sum(1 for _ in p.open(encoding="utf-8")))
PY

IFS=',' read -ra GPUS <<< "${GPU_LIST}"
if [[ "${#GPUS[@]}" -ne 4 ]]; then
  echo "[ERROR] GPU_LIST must contain exactly 4 GPUs, got: ${GPU_LIST}" >&2
  exit 1
fi

pids=()
for i in 0 1 2 3; do
  gpu="${GPUS[$i]}"
  echo "[INFO] Launch shard ${i} on physical GPU ${gpu}"
  CUDA_VISIBLE_DEVICES="${gpu}" \
  PYTHONUNBUFFERED=1 \
  TOKENIZERS_PARALLELISM=false \
  PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True \
  python "${PROJECT_DIR}/scripts/evaluate_peft.py" \
    --base_model "${BASE_MODEL}" \
    --adapter "${ADAPTER_DIR}" \
    --test_file "${SHARD_DIR}/test_shard_${i}.jsonl" \
    --output_predictions "${PRED_DIR}/pred_shard_${i}.jsonl" \
    --output_metrics "${METRIC_DIR}/metric_shard_${i}.json" \
    --max_model_len "${MAX_MODEL_LEN}" \
    --max_new_tokens "${MAX_NEW_TOKENS}" \
    --batch_size "${BATCH_SIZE}" \
    --load_in_4bit \
    --max_memory_per_gpu 40GiB \
    --offload_folder "${OFFLOAD_DIR}/shard_${i}" \
    --trust_remote_code \
    > "${LOG_DIR}/eval_shard_${i}.log" 2>&1 &
  pids+=("$!")
done

failed=0
for pid in "${pids[@]}"; do
  if ! wait "${pid}"; then
    failed=1
  fi
done
if [[ "${failed}" -ne 0 ]]; then
  echo "[ERROR] At least one eval shard failed. Check ${LOG_DIR}" >&2
  exit 1
fi

cat "${PRED_DIR}"/pred_shard_*.jsonl > "${FINAL_PRED}"

python - <<PY
import json, sys
from pathlib import Path
sys.path.insert(0, "${PROJECT_DIR}/scripts")
from metrics_utils import compute_metrics_from_records
pred = Path("${FINAL_PRED}")
out = Path("${FINAL_METRIC}")
records = [json.loads(line) for line in pred.open(encoding="utf-8") if line.strip()]
metrics = compute_metrics_from_records(records)
out.write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
print("records", len(records))
print("metrics", out)
print(json.dumps(metrics["global"], ensure_ascii=False, indent=2))
PY

echo "[DONE] ${FINAL_PRED}"
echo "[DONE] ${FINAL_METRIC}"
