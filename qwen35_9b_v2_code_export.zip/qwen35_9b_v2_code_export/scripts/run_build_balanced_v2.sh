#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/qwen35_9b_concept_sft_project_v2}"
SRC_DIR="${SRC_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/data/finetune/qwen_sft_merged_v2}"
OUT_DIR="${OUT_DIR:-${PROJECT_DIR}/data_v2_balanced_goemo20k}"

python "${PROJECT_DIR}/scripts/build_balanced_train_val.py" \
  --aggregated_train "${SRC_DIR}/aggregated_train.jsonl" \
  --aggregated_test "${SRC_DIR}/aggregated_test.jsonl" \
  --output_dir "${OUT_DIR}" \
  --token_length_csv "${SRC_DIR}/token_length_rows_v2_fixed.csv" \
  --drop_train_over_length 2048 \
  --goemotions_cap 20000 \
  --goemotions_min_per_label 500 \
  --val_ratio 0.05 \
  --seed 42
