#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Add / recompute WellnessDimensions metrics from saved prediction JSONL.

This is used after PEFT shard evaluation and merge. It avoids rerunning inference
when the prediction file already contains valid WellnessDimensions pred_obj values.
"""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List


LABELS = [
    "Physical",
    "Intellectual_Vocational",
    "Social",
    "Spiritual_Emotional",
]


def norm(x: Any) -> str:
    return str(x or "").strip()


def token_f1(gold: Any, pred: Any) -> float:
    gt = re.findall(r"\w+", str(gold or "").lower())
    pt = re.findall(r"\w+", str(pred or "").lower())

    if not gt and not pt:
        return 1.0
    if not gt or not pt:
        return 0.0

    cg, cp = Counter(gt), Counter(pt)
    overlap = sum((cg & cp).values())

    if overlap == 0:
        return 0.0

    precision = overlap / len(pt)
    recall = overlap / len(gt)
    return 2 * precision * recall / (precision + recall)


def compute_wellness_metrics(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    rows = [r for r in records if r.get("dataset") == "WellnessDimensions"]

    valid = [
        r for r in rows
        if r.get("schema_valid") and isinstance(r.get("pred_obj"), dict)
    ]

    if not rows:
        return {
            "n": 0,
            "json_parse_rate": None,
            "schema_valid_rate": None,
            "aspect_metrics": {
                "n": 0,
                "accuracy": None,
                "macro_f1": None,
                "per_label_f1": {},
            },
            "span_exact_match": None,
            "span_token_f1": None,
        }

    gold_labels = [norm(r.get("gold", {}).get("wellness_aspect")) for r in valid]
    pred_labels = [norm(r.get("pred_obj", {}).get("wellness_aspect")) for r in valid]

    accuracy = (
        sum(g == p for g, p in zip(gold_labels, pred_labels)) / len(valid)
        if valid else None
    )

    per_label_f1: Dict[str, float] = {}
    for lab in LABELS:
        tp = sum(g == lab and p == lab for g, p in zip(gold_labels, pred_labels))
        fp = sum(g != lab and p == lab for g, p in zip(gold_labels, pred_labels))
        fn = sum(g == lab and p != lab for g, p in zip(gold_labels, pred_labels))
        denom = 2 * tp + fp + fn
        per_label_f1[lab] = 2 * tp / denom if denom else 0.0

    macro_f1 = (
        sum(per_label_f1.values()) / len(per_label_f1)
        if per_label_f1 else None
    )

    span_exact = []
    span_f1 = []

    for r in valid:
        gspan = norm(r.get("gold", {}).get("evidence_span"))
        pspan = norm(r.get("pred_obj", {}).get("evidence_span"))
        span_exact.append(1.0 if gspan == pspan else 0.0)
        span_f1.append(token_f1(gspan, pspan))

    return {
        "n": len(rows),
        "json_parse_rate": sum(r.get("pred_obj") is not None for r in rows) / len(rows),
        "schema_valid_rate": len(valid) / len(rows),
        "aspect_metrics": {
            "n": len(valid),
            "accuracy": accuracy,
            "macro_f1": macro_f1,
            "per_label_f1": per_label_f1,
        },
        "span_exact_match": sum(span_exact) / len(span_exact) if span_exact else None,
        "span_token_f1": sum(span_f1) / len(span_f1) if span_f1 else None,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--metrics", type=Path, required=True)
    parser.add_argument("--backup", action="store_true")
    args = parser.parse_args()

    records = []
    with args.predictions.open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                records.append(json.loads(line))

    metrics = json.loads(args.metrics.read_text(encoding="utf-8"))
    metrics.setdefault("by_dataset", {})

    wd_metrics = compute_wellness_metrics(records)
    metrics["by_dataset"]["WellnessDimensions"] = wd_metrics

    if args.backup:
        backup = args.metrics.with_suffix(".before_wellness_patch.json")
        if not backup.exists():
            backup.write_text(
                json.dumps(json.loads(args.metrics.read_text(encoding="utf-8")), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

    args.metrics.write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(json.dumps(wd_metrics, ensure_ascii=False, indent=2))
    print(f"[DONE] Updated metrics: {args.metrics}")


if __name__ == "__main__":
    main()
