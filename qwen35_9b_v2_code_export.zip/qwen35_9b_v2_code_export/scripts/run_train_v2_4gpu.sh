#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/mnt/disk1/wbjtu/tzbjtu/somental/qwen35_9b_concept_sft_project_v2}"
MODEL_PATH="${MODEL_PATH:-/mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B}"
DATA_DIR="${DATA_DIR:-${PROJECT_DIR}/data_v2_balanced_goemo20k}"
OUTPUT_DIR="${OUTPUT_DIR:-${PROJECT_DIR}/outputs/adapter/qwen35_9b_concept_sft_lora_v2_4gpu}"
LOG_DIR="${LOG_DIR:-${PROJECT_DIR}/outputs/logs}"

mkdir -p "${OUTPUT_DIR}" "${LOG_DIR}"

# 9B default: effective batch size = 4 GPUs × batch 2 × grad_acc 4 = 32.
# Override PER_DEVICE_TRAIN_BATCH_SIZE or GRADIENT_ACCUMULATION_STEPS if needed.

export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

accelerate launch \
  --num_processes 4 \
  --num_machines 1 \
  --mixed_precision bf16 \
  --dynamo_backend no \
  "${PROJECT_DIR}/scripts/train_qlora.py" \
  --model_name_or_path "${MODEL_PATH}" \
  --train_file "${DATA_DIR}/train_for_sft.jsonl" \
  --validation_file "${DATA_DIR}/val_for_epoch_select.jsonl" \
  --output_dir "${OUTPUT_DIR}" \
  --max_seq_length "${MAX_SEQ_LENGTH:-1024}" \
  --num_train_epochs "${NUM_TRAIN_EPOCHS:-3}" \
  --per_device_train_batch_size "${PER_DEVICE_TRAIN_BATCH_SIZE:-2}" \
  --per_device_eval_batch_size 1 \
  --gradient_accumulation_steps "${GRADIENT_ACCUMULATION_STEPS:-4}" \
  --learning_rate "${LEARNING_RATE:-1e-5}" \
  --warmup_ratio 0.03 \
  --weight_decay 0.01 \
  --lora_rank 16 \
  --lora_alpha 32 \
  --lora_dropout 0.05 \
  --target_modules q_proj,k_proj,v_proj,o_proj \
  --eval_steps "${EVAL_STEPS:-200}" \
  --save_steps "${SAVE_STEPS:-200}" \
  --logging_steps 10 \
  --save_total_limit 3 \
  --gradient_checkpointing \
  --trust_remote_code \
  2>&1 | tee "${LOG_DIR}/train_qwen35_9b_lora_v2_4gpu_$(date +%Y%m%d_%H%M%S).log"
