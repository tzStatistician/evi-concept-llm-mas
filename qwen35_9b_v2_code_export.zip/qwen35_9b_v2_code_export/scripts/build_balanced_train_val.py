#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build balanced SFT train/validation files from aggregated_train.jsonl.

Default policy for v2:
- Keep all non-GoEmotions training rows.
- Cap GoEmotions to 20k with label-aware rare-first sampling.
- Optionally drop overlength training rows using token_length_rows CSV.
- Split resulting training pool into train_for_sft / val_for_epoch_select.
- Copy aggregated_test unchanged by default.
"""
from __future__ import annotations

import argparse
import json
import hashlib
import random
import shutil
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Set, Tuple



def stable_dataset_seed(seed: int, dataset: str) -> int:
    h = hashlib.md5(dataset.encode("utf-8")).hexdigest()
    return seed + int(h[:8], 16)

def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if line.strip():
                row = json.loads(line)
                row.setdefault("_source_index", i)
                rows.append(row)
    return rows


def write_jsonl(path: Path, rows: Iterable[Dict[str, Any]]) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            out = dict(row)
            out.pop("_source_index", None)
            f.write(json.dumps(out, ensure_ascii=False) + "\n")
            n += 1
    return n


def gold_json(row: Dict[str, Any]) -> Dict[str, Any]:
    return json.loads(row["messages"][-1]["content"])


def load_drop_indices(csv_path: Path | None, source_file_name: str, max_len: int | None) -> Set[int]:
    if csv_path is None or max_len is None or max_len <= 0:
        return set()
    drop: Set[int] = set()
    with csv_path.open("r", encoding="utf-8") as f:
        header = next(f).strip().split(",")
        pos = {k: i for i, k in enumerate(header)}
        for line in f:
            parts = line.rstrip("\n").split(",")
            if parts[pos["file"]] != source_file_name:
                continue
            if int(parts[pos["full_len"]]) > max_len:
                drop.add(int(parts[pos["index"]]))
    return drop


def label_aware_goemotions_sample(rows: List[Dict[str, Any]], cap: int, min_per_label: int, seed: int) -> List[Dict[str, Any]]:
    rng = random.Random(seed)
    if cap <= 0 or len(rows) <= cap:
        out = list(rows)
        rng.shuffle(out)
        return out

    label_to_indices: Dict[str, List[int]] = defaultdict(list)
    for i, row in enumerate(rows):
        labels = gold_json(row).get("emotions", [])
        if not isinstance(labels, list):
            labels = []
        for lab in sorted({str(x).strip() for x in labels if str(x).strip()}):
            label_to_indices[lab].append(i)

    selected: Set[int] = set()
    labels_by_rarity = sorted(label_to_indices, key=lambda lab: len(label_to_indices[lab]))

    for lab in labels_by_rarity:
        candidates = list(label_to_indices[lab])
        rng.shuffle(candidates)
        need = max(0, min(min_per_label, len(candidates)) - sum(1 for i in candidates if i in selected))
        for i in candidates:
            if len(selected) >= cap or need <= 0:
                break
            if i not in selected:
                selected.add(i)
                need -= 1

    remaining = [i for i in range(len(rows)) if i not in selected]
    rng.shuffle(remaining)
    for i in remaining:
        if len(selected) >= cap:
            break
        selected.add(i)

    out = [rows[i] for i in sorted(selected)]
    rng.shuffle(out)
    return out


def split_train_val(rows: List[Dict[str, Any]], val_ratio: float, seed: int) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[row.get("dataset", "UNKNOWN")].append(row)

    train, val = [], []
    for ds in sorted(grouped):
        ds_rows = list(grouped[ds])
        random.Random(stable_dataset_seed(seed, ds)).shuffle(ds_rows)
        n_val = max(1, round(len(ds_rows) * val_ratio)) if len(ds_rows) > 1 else 0
        n_val = min(n_val, max(0, len(ds_rows) - 1))
        val.extend(ds_rows[:n_val])
        train.extend(ds_rows[n_val:])

    rng = random.Random(seed)
    rng.shuffle(train)
    rng.shuffle(val)
    return train, val


def count_by_dataset(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    return dict(Counter(row.get("dataset", "UNKNOWN") for row in rows))


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--aggregated_train", type=Path, required=True)
    p.add_argument("--aggregated_test", type=Path, required=True)
    p.add_argument("--output_dir", type=Path, required=True)
    p.add_argument("--token_length_csv", type=Path, default=None)
    p.add_argument("--drop_train_over_length", type=int, default=2048)
    p.add_argument("--goemotions_cap", type=int, default=20000)
    p.add_argument("--goemotions_min_per_label", type=int, default=500)
    p.add_argument("--val_ratio", type=float, default=0.05)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()

    train_rows = read_jsonl(args.aggregated_train)
    test_rows = read_jsonl(args.aggregated_test)

    drop_idx = load_drop_indices(args.token_length_csv, args.aggregated_train.name, args.drop_train_over_length)
    before = len(train_rows)
    if drop_idx:
        train_rows = [r for r in train_rows if int(r.get("_source_index", -1)) not in drop_idx]
    dropped = before - len(train_rows)

    non_go = [r for r in train_rows if r.get("dataset") != "GoEmotions"]
    go = [r for r in train_rows if r.get("dataset") == "GoEmotions"]
    go_sample = label_aware_goemotions_sample(go, args.goemotions_cap, args.goemotions_min_per_label, args.seed)

    balanced = non_go + go_sample
    random.Random(args.seed).shuffle(balanced)
    train_final, val_final = split_train_val(balanced, args.val_ratio, args.seed)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    n_train = write_jsonl(args.output_dir / "train_for_sft.jsonl", train_final)
    n_val = write_jsonl(args.output_dir / "val_for_epoch_select.jsonl", val_final)
    n_agg_train = write_jsonl(args.output_dir / "aggregated_train_balanced.jsonl", balanced)
    shutil.copy2(args.aggregated_test, args.output_dir / "aggregated_test.jsonl")

    manifest = {
        "aggregated_train": str(args.aggregated_train),
        "aggregated_test": str(args.aggregated_test),
        "token_length_csv": str(args.token_length_csv) if args.token_length_csv else None,
        "drop_train_over_length": args.drop_train_over_length,
        "dropped_train_rows": dropped,
        "goemotions_original_train": len(go),
        "goemotions_cap": args.goemotions_cap,
        "goemotions_selected": len(go_sample),
        "goemotions_min_per_label": args.goemotions_min_per_label,
        "val_ratio": args.val_ratio,
        "seed": args.seed,
        "counts": {
            "balanced_train_pool": count_by_dataset(balanced),
            "train_for_sft": count_by_dataset(train_final),
            "val_for_epoch_select": count_by_dataset(val_final),
            "aggregated_test": count_by_dataset(test_rows),
        },
        "files": {
            "aggregated_train_balanced": str(args.output_dir / "aggregated_train_balanced.jsonl"),
            "train_for_sft": str(args.output_dir / "train_for_sft.jsonl"),
            "val_for_epoch_select": str(args.output_dir / "val_for_epoch_select.jsonl"),
            "aggregated_test": str(args.output_dir / "aggregated_test.jsonl"),
        },
    }
    (args.output_dir / "balance_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    print("[DONE]")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    print(f"lines: train_for_sft={n_train} val={n_val} balanced_pool={n_agg_train}")


if __name__ == "__main__":
    main()
