from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
from tqdm import tqdm

from data_io import load_csv, load_json, save_csv, save_json
from acs import AutomaticConceptScorer
from acc import batch_acc


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description='Build ACS and ACC concept targets.')
    p.add_argument('--csv-path', required=True)
    p.add_argument('--concept-json', required=True)
    p.add_argument('--text-col', default='text')
    p.add_argument('--label-col', default='sentiment')
    p.add_argument('--output-dir', required=True)
    p.add_argument('--encoder-name', default='sentence-transformers/all-mpnet-base-v2')
    return p.parse_args()


def main() -> None:
    args = parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    df = load_csv(args.csv_path)
    concept_inventory = load_json(args.concept_json)

    concepts = [x['concept_name'] for x in concept_inventory['concepts']]
    concept_to_label = {x['concept_name']: x['primary_source_label'] for x in concept_inventory['concepts']}

    scorer = AutomaticConceptScorer(args.encoder_name)
    score_matrix = scorer.score(df[args.text_col].astype(str).tolist(), concepts)
    named_scores = scorer.to_named_scores(score_matrix, concepts)
    corrected_scores = batch_acc(named_scores, df[args.label_col].astype(str).tolist(), concept_to_label)

    save_json(named_scores, out / 'acs_named_scores.json')
    save_json(corrected_scores, out / 'acc_named_scores.json')

    acs_df = pd.DataFrame(named_scores)
    acc_df = pd.DataFrame(corrected_scores)

    acs_df.insert(0, args.label_col, df[args.label_col].values)
    acs_df.insert(0, args.text_col, df[args.text_col].values)

    acc_df.insert(0, args.label_col, df[args.label_col].values)
    acc_df.insert(0, args.text_col, df[args.text_col].values)

    save_csv(acs_df, out / 'acs_targets.csv')
    save_csv(acc_df, out / 'acc_targets.csv')
    print(f'Saved outputs to: {out}')


if __name__ == '__main__':
    main()
