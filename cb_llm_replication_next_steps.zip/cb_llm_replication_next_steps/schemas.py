from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import List, Dict, Any


@dataclass
class ConceptRecord:
    concept_id: str
    concept_name: str
    primary_source_label: str
    all_source_labels: List[str]
    dropped_variants: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ACSTargetRow:
    row_id: int
    text: str
    label: str
    concept_scores: Dict[str, float]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
