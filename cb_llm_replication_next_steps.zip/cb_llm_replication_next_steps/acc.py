from __future__ import annotations

from typing import Dict, List


def automatic_concept_correction(
    concept_scores: Dict[str, float],
    concept_to_label: Dict[str, str],
    gold_label: str,
) -> Dict[str, float]:
    corrected = {}
    for concept, score in concept_scores.items():
        if score > 0 and concept_to_label.get(concept) == gold_label:
            corrected[concept] = float(score)
        else:
            corrected[concept] = 0.0
    return corrected


def batch_acc(
    named_scores: List[Dict[str, float]],
    labels: List[str],
    concept_to_label: Dict[str, str],
) -> List[Dict[str, float]]:
    return [
        automatic_concept_correction(scores, concept_to_label, gold)
        for scores, gold in zip(named_scores, labels)
    ]
