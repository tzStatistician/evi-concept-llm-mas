from __future__ import annotations

from typing import List, Dict

import numpy as np
from sentence_transformers import SentenceTransformer


class AutomaticConceptScorer:
    def __init__(self, encoder_name: str = 'sentence-transformers/all-mpnet-base-v2'):
        self.model = SentenceTransformer(encoder_name)

    def score(self, texts: List[str], concepts: List[str], batch_size: int = 64) -> np.ndarray:
        concept_emb = self.model.encode(concepts, batch_size=batch_size, normalize_embeddings=True, show_progress_bar=True)
        text_emb = self.model.encode(texts, batch_size=batch_size, normalize_embeddings=True, show_progress_bar=True)
        return np.matmul(text_emb, concept_emb.T)

    @staticmethod
    def to_named_scores(score_matrix: np.ndarray, concepts: List[str]) -> List[Dict[str, float]]:
        return [
            {concepts[j]: float(row[j]) for j in range(len(concepts))}
            for row in score_matrix
        ]
