#!/usr/bin/env bash
set -euo pipefail

# Example usage only.
# Adjust paths before running.

CSV_PATH=${CSV_PATH:-/path/to/data.csv}
CONCEPT_JSON=${CONCEPT_JSON:-/path/to/concept_inventory.json}
OUT_DIR=${OUT_DIR:-outputs_next_steps}

python build_concept_targets.py \
  --csv-path "$CSV_PATH" \
  --concept-json "$CONCEPT_JSON" \
  --text-col text \
  --label-col sentiment \
  --output-dir "$OUT_DIR/concept_targets"

python train_linear_head.py \
  --acc-csv "$OUT_DIR/concept_targets/acc_targets.csv" \
  --text-col text \
  --label-col sentiment \
  --output-dir "$OUT_DIR/linear_head"
