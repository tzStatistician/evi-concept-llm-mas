from __future__ import annotations

import argparse
import json
import pandas as pd
from sklearn.metrics import classification_report, accuracy_score, f1_score


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description='Evaluate prediction CSV with gold and pred columns.')
    p.add_argument('--csv-path', required=True)
    p.add_argument('--gold-col', default='gold')
    p.add_argument('--pred-col', default='pred')
    p.add_argument('--output-json', required=True)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    df = pd.read_csv(args.csv_path)
    gold = df[args.gold_col].astype(str)
    pred = df[args.pred_col].astype(str)

    result = {
        'accuracy': accuracy_score(gold, pred),
        'macro_f1': f1_score(gold, pred, average='macro'),
        'weighted_f1': f1_score(gold, pred, average='weighted'),
        'report': classification_report(gold, pred, output_dict=True),
    }
    with open(args.output_json, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f'Saved metrics to {args.output_json}')


if __name__ == '__main__':
    main()
