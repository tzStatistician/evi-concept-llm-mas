from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_selection import VarianceThreshold
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_recall_fscore_support, classification_report
from sklearn.model_selection import train_test_split


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description='Train a simple linear head on ACC targets.')
    p.add_argument('--acc-csv', required=True)
    p.add_argument('--text-col', default='text')
    p.add_argument('--label-col', default='sentiment')
    p.add_argument('--output-dir', required=True)
    p.add_argument('--test-size', type=float, default=0.2)
    p.add_argument('--random-seed', type=int, default=42)
    p.add_argument('--c', type=float, default=1.0)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(args.acc_csv)
    feature_cols = [c for c in df.columns if c not in {args.text_col, args.label_col}]
    X = df[feature_cols].fillna(0.0).values
    y = df[args.label_col].astype(str).values

    selector = VarianceThreshold(threshold=0.0)
    X = selector.fit_transform(X)
    kept_cols = [feature_cols[i] for i, keep in enumerate(selector.get_support()) if keep]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=args.random_seed, stratify=y
    )

    clf = LogisticRegression(
        penalty='elasticnet',
        solver='saga',
        l1_ratio=0.99,
        C=args.c,
        max_iter=5000,
        n_jobs=1,
        multi_class='multinomial',
    )
    clf.fit(X_train, y_train)
    pred = clf.predict(X_test)

    report = classification_report(y_test, pred, output_dict=True)
    summary = {
        'accuracy': accuracy_score(y_test, pred),
        'macro_f1': f1_score(y_test, pred, average='macro'),
        'weighted_f1': f1_score(y_test, pred, average='weighted'),
        'report': report,
        'kept_features': kept_cols,
    }

    with open(out / 'linear_head_metrics.json', 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    coef_df = pd.DataFrame(clf.coef_, columns=kept_cols, index=clf.classes_)
    coef_df.to_csv(out / 'linear_head_weights.csv')
    print(f'Saved linear-head outputs to: {out}')


if __name__ == '__main__':
    main()
