# CB-LLM Replication: Next Steps Add-on

This add-on is designed to sit next to the concept-extraction project and cover the next faithful replication stages:

1. **Automatic Concept Scoring (ACS)**
2. **Automatic Concept Correction (ACC)**
3. **Training-table export for the bottleneck stage**
4. **Linear-head training scaffold**
5. **Evaluation scaffold**

These files are intentionally modular so you can plug them into your existing workflow without changing the concept-extraction project structure.

## Expected inputs

- `concept_inventory.json` from the concept extraction stage
- a CSV with columns:
  - `text`
  - `sentiment`
- label config describing the 4 classes

## Main files

- `build_concept_targets.py`: compute ACS + ACC targets
- `train_linear_head.py`: simple sparse linear-head baseline scaffold
- `evaluate_predictions.py`: metrics script
- `data_io.py`: shared loading/saving helpers
- `acs.py`: embedding-based concept scoring
- `acc.py`: class-conditioned concept correction
- `schemas.py`: dataclasses and schemas

## Notes

- This package does **not** add psychology-domain knowledge.
- It assumes a faithful replication path after concept extraction.
- ACS uses sentence embeddings.
- ACC uses label-origin metadata from the concept inventory.
