from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_recall_fscore_support,
    precision_score,
    recall_score,
)
from sklearn.preprocessing import StandardScaler


def find_first_existing(cols, candidates):
    for c in candidates:
        if c in cols:
            return c
    return None


def eval_metrics(y_true, y_pred, split_name: str) -> Dict[str, float]:
    return {
        "split": split_name,
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro")),
        "macro_precision": float(precision_score(y_true, y_pred, average="macro", zero_division=0)),
        "macro_recall": float(recall_score(y_true, y_pred, average="macro", zero_division=0)),
    }


def per_class_df(y_true, y_pred, classes, split_name: str, trial_name: str) -> pd.DataFrame:
    pr, rc, f1, sp = precision_recall_fscore_support(
        y_true, y_pred, labels=classes, zero_division=0
    )
    return pd.DataFrame({
        "trial": trial_name,
        "split": split_name,
        "class": classes,
        "precision": pr,
        "recall": rc,
        "f1": f1,
        "support": sp,
    })


def save_predictions(path: Path, df: pd.DataFrame, y_pred, probs, classes):
    out = df.copy()
    out["logreg_pred_label"] = y_pred
    for j, cls in enumerate(classes):
        out[f"logreg_prob_{cls}"] = probs[:, j]
    out.to_csv(path, index=False)


def make_trial_specs(manual_class_weights: Optional[Dict[str, float]]) -> List[Dict]:
    return [
        {
            "name": "balanced_l2",
            "class_weight": "balanced",
            "penalty": "l2",
            "solver": "lbfgs",
            "C": 1.0,
            "standardize": False,
        },
        {
            "name": "balanced_l1",
            "class_weight": "balanced",
            "penalty": "l1",
            "solver": "saga",
            "C": 1.0,
            "standardize": False,
        },
        {
            "name": "balanced_elasticnet",
            "class_weight": "balanced",
            "penalty": "elasticnet",
            "solver": "saga",
            "C": 1.0,
            "l1_ratio": 0.5,
            "standardize": False,
        },
        {
            "name": "manual_elasticnet",
            "class_weight": manual_class_weights if manual_class_weights else "balanced",
            "penalty": "elasticnet",
            "solver": "saga",
            "C": 1.0,
            "l1_ratio": 0.5,
            "standardize": False,
        },
    ]


def maybe_convert_manual_class_weights(run_dir: Path, manual_class_weights: Optional[Dict[str, float]]) -> Optional[Dict[str, float]]:
    if manual_class_weights is None:
        return None

    label_map_path = run_dir / "label_mapping.json"
    if not label_map_path.exists():
        return {str(k): float(v) for k, v in manual_class_weights.items()}

    with open(label_map_path, "r") as f:
        label_map = json.load(f)

    classes = label_map.get("classes", [])
    if not classes:
        return {str(k): float(v) for k, v in manual_class_weights.items()}

    name_to_idx = {name: str(i) for i, name in enumerate(classes)}
    converted = {}
    for k, v in manual_class_weights.items():
        kk = str(k)
        if kk in name_to_idx:
            converted[name_to_idx[kk]] = float(v)
        else:
            converted[kk] = float(v)
    return converted


def main():
    ap = argparse.ArgumentParser(description="Run 4 post-hoc linear/logistic head trials on predicted concepts")
    ap.add_argument("--run_dir", type=str, required=True)
    ap.add_argument("--output_dir", type=str, required=True)
    ap.add_argument("--manual_class_weights", type=str, default="")
    ap.add_argument("--random_seed", type=int, default=42)
    args = ap.parse_args()

    run_dir = Path(args.run_dir)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # -------------------------
    # Load saved phase-1 outputs
    # -------------------------
    pred_train = np.load(run_dir / "predicted_concepts_train.npy")
    pred_val = np.load(run_dir / "predicted_concepts_val.npy")
    pred_test = np.load(run_dir / "predicted_concepts_test.npy")

    train_df = pd.read_csv(run_dir / "predictions_train.csv")
    val_df = pd.read_csv(run_dir / "predictions_val.csv")
    test_df = pd.read_csv(run_dir / "predictions_test.csv")

    train_label_col = find_first_existing(train_df.columns, ["true_label", "gold_label", "label", "sentiment", "y_true"])
    val_label_col = find_first_existing(val_df.columns, ["true_label", "gold_label", "label", "sentiment", "y_true"])
    test_label_col = find_first_existing(test_df.columns, ["true_label", "gold_label", "label", "sentiment", "y_true"])
    if train_label_col is None or val_label_col is None or test_label_col is None:
        raise ValueError("Could not find true-label columns in predictions CSVs.")

    y_train = train_df[train_label_col].astype(str).values
    y_val = val_df[val_label_col].astype(str).values
    y_test = test_df[test_label_col].astype(str).values

    meta_path = run_dir / "data_metadata.json"
    concept_cols = None
    if meta_path.exists():
        with open(meta_path, "r") as f:
            meta = json.load(f)
        concept_cols = meta.get("concept_cols") or meta.get("concept_columns")
    if concept_cols is None:
        concept_cols = [f"concept_{i}" for i in range(pred_train.shape[1])]

    current_test_metrics = {}
    metrics_test_path = run_dir / "metrics_test.json"
    if metrics_test_path.exists():
        with open(metrics_test_path, "r") as f:
            current_test_metrics = json.load(f)

    manual_class_weights = json.loads(args.manual_class_weights) if args.manual_class_weights else None
    manual_class_weights = maybe_convert_manual_class_weights(run_dir, manual_class_weights)

    trial_specs = make_trial_specs(manual_class_weights)

    summary_rows = []
    per_class_rows = []

    best_trial_name = None
    best_val_macro_f1 = -1.0
    best_artifacts = {}

    # -------------------------
    # Run 4 trials
    # -------------------------
    for spec in trial_specs:
        name = spec["name"]

        X_train = pred_train.copy()
        X_val = pred_val.copy()
        X_test = pred_test.copy()

        scaler = None
        if spec.get("standardize", False):
            scaler = StandardScaler()
            X_train = scaler.fit_transform(X_train)
            X_val = scaler.transform(X_val)
            X_test = scaler.transform(X_test)

        clf_kwargs = dict(
            max_iter=5000,
            class_weight=spec["class_weight"],
            solver=spec["solver"],
            penalty=spec["penalty"],
            C=spec["C"],
            random_state=args.random_seed,
        )
        if spec["penalty"] == "elasticnet":
            clf_kwargs["l1_ratio"] = spec["l1_ratio"]

        clf = LogisticRegression(**clf_kwargs)
        clf.fit(X_train, y_train)

        y_val_pred = clf.predict(X_val)
        y_test_pred = clf.predict(X_test)

        val_probs = clf.predict_proba(X_val)
        test_probs = clf.predict_proba(X_test)

        val_metrics = eval_metrics(y_val, y_val_pred, "val")
        test_metrics = eval_metrics(y_test, y_test_pred, "test")

        row = {
            "trial": name,
            "penalty": spec["penalty"],
            "solver": spec["solver"],
            "C": spec["C"],
            "class_weight": json.dumps(spec["class_weight"]) if isinstance(spec["class_weight"], dict) else str(spec["class_weight"]),
            "standardize": spec.get("standardize", False),
            "val_accuracy": val_metrics["accuracy"],
            "val_macro_f1": val_metrics["macro_f1"],
            "val_macro_precision": val_metrics["macro_precision"],
            "val_macro_recall": val_metrics["macro_recall"],
            "test_accuracy": test_metrics["accuracy"],
            "test_macro_f1": test_metrics["macro_f1"],
            "test_macro_precision": test_metrics["macro_precision"],
            "test_macro_recall": test_metrics["macro_recall"],
        }
        if spec["penalty"] == "elasticnet":
            row["l1_ratio"] = spec["l1_ratio"]
        else:
            row["l1_ratio"] = np.nan

        summary_rows.append(row)

        per_class_rows.append(per_class_df(y_val, y_val_pred, clf.classes_, "val", name))
        per_class_rows.append(per_class_df(y_test, y_test_pred, clf.classes_, "test", name))

        if val_metrics["macro_f1"] > best_val_macro_f1:
            best_val_macro_f1 = val_metrics["macro_f1"]
            best_trial_name = name
            best_artifacts = {
                "trial_row": row,
                "clf": clf,
                "classes": clf.classes_,
                "val_metrics": val_metrics,
                "test_metrics": test_metrics,
                "val_df": val_df,
                "test_df": test_df,
                "y_val_pred": y_val_pred,
                "y_test_pred": y_test_pred,
                "val_probs": val_probs,
                "test_probs": test_probs,
                "coef_df": pd.DataFrame(clf.coef_, index=clf.classes_, columns=concept_cols),
                "bias_df": pd.DataFrame({"bias": clf.intercept_}, index=clf.classes_),
            }

    # -------------------------
    # Save compact evidence
    # -------------------------
    summary_df = pd.DataFrame(summary_rows).sort_values("val_macro_f1", ascending=False)
    summary_df.to_csv(out_dir / "trial_summary.csv", index=False)

    per_class_df_all = pd.concat(per_class_rows, axis=0, ignore_index=True)
    per_class_df_all.to_csv(out_dir / "per_class_metrics.csv", index=False)

    with open(out_dir / "best_trial.json", "w") as f:
        json.dump(best_artifacts["trial_row"], f, indent=2)

    comparison = {
        "current_end2end_test_metrics": current_test_metrics,
        "best_posthoc_linear_head": best_artifacts["trial_row"],
    }
    with open(out_dir / "comparison_to_end2end.json", "w") as f:
        json.dump(comparison, f, indent=2)

    best_artifacts["coef_df"].to_csv(out_dir / "coef_best.csv")
    best_artifacts["bias_df"].to_csv(out_dir / "bias_best.csv")

    save_predictions(
        out_dir / "predictions_val_best.csv",
        best_artifacts["val_df"],
        best_artifacts["y_val_pred"],
        best_artifacts["val_probs"],
        best_artifacts["classes"],
    )
    save_predictions(
        out_dir / "predictions_test_best.csv",
        best_artifacts["test_df"],
        best_artifacts["y_test_pred"],
        best_artifacts["test_probs"],
        best_artifacts["classes"],
    )

    with open(out_dir / "metrics_val_best.json", "w") as f:
        json.dump(best_artifacts["val_metrics"], f, indent=2)
    with open(out_dir / "metrics_test_best.json", "w") as f:
        json.dump(best_artifacts["test_metrics"], f, indent=2)

    print("Finished 4 trials.")
    print(summary_df.to_string(index=False))
    print(f"\\nBest trial by validation macro-F1: {best_trial_name} ({best_val_macro_f1:.4f})")
    print(f"Saved compact outputs to: {out_dir}")


if __name__ == "__main__":
    main()
