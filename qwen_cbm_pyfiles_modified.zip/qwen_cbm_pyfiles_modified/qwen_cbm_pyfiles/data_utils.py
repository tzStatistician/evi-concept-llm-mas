from __future__ import annotations

from dataclasses import asdict
import json
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from torch.utils.data import DataLoader, Dataset

from config import TrainConfig
from utils import save_json, to_serializable


class ConceptTextDataset(Dataset):
    def __init__(self, df: pd.DataFrame, tokenizer, text_col: str, label_col: str, concept_cols: List[str], max_length: int):
        self.df = df.reset_index(drop=True).copy()
        self.tokenizer = tokenizer
        self.text_col = text_col
        self.label_col = label_col
        self.concept_cols = concept_cols
        self.max_length = max_length

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        row = self.df.iloc[idx]
        enc = self.tokenizer(str(row[self.text_col]), truncation=True, max_length=self.max_length, padding=False, return_tensors=None)
        return {
            "input_ids": torch.tensor(enc["input_ids"], dtype=torch.long),
            "attention_mask": torch.tensor(enc["attention_mask"], dtype=torch.long),
            "labels": torch.tensor(int(row[self.label_col]), dtype=torch.long),
            "concept_targets": torch.tensor(row[self.concept_cols].astype(float).values, dtype=torch.float32),
            "row_idx": torch.tensor(int(row["__row_idx__"]), dtype=torch.long),
        }


class DataCollatorForConceptText:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def __call__(self, features: List[Dict]) -> Dict[str, torch.Tensor]:
        token_features = [{k: v for k, v in x.items() if k != "row_idx"} for x in features]
        batch = self.tokenizer.pad(token_features, padding=True, return_tensors="pt")
        batch["row_idx"] = torch.stack([x["row_idx"] for x in features])
        return batch


class DatasetBundle:
    def __init__(self, train_df, val_df, test_df, concept_cols, label_encoder, concept_scaler, class_weights, metadata):
        self.train_df = train_df
        self.val_df = val_df
        self.test_df = test_df
        self.concept_cols = concept_cols
        self.label_encoder = label_encoder
        self.concept_scaler = concept_scaler
        self.class_weights = class_weights
        self.metadata = metadata


def compute_class_weights(y_train: np.ndarray, num_classes: int, mode: str, manual_class_weights: str = "", class_names: Optional[List[str]] = None) -> np.ndarray:
    counts = np.bincount(y_train, minlength=num_classes).astype(np.float64)
    counts[counts == 0.0] = 1.0
    if mode == "balanced":
        weights = len(y_train) / (num_classes * counts)
    elif mode == "inverse_sqrt":
        weights = 1.0 / np.sqrt(counts)
        weights = weights / weights.mean()
    elif mode == "none":
        weights = np.ones(num_classes, dtype=np.float64)
    elif mode == "manual":
        if not manual_class_weights:
            raise ValueError("class_weight_mode='manual' requires --manual_class_weights JSON mapping")
        raw = json.loads(manual_class_weights)
        weights = np.ones(num_classes, dtype=np.float64)
        name_to_idx = {str(name): i for i, name in enumerate(class_names or [])}
        for k, v in raw.items():
            kk = str(k)
            if kk.isdigit():
                idx = int(kk)
            elif kk in name_to_idx:
                idx = name_to_idx[kk]
            else:
                raise ValueError(f"Manual class weight key '{kk}' not found in class names or numeric ids")
            if idx < 0 or idx >= num_classes:
                raise ValueError(f"Manual class weight index out of range: {idx}")
            weights[idx] = float(v)
    else:
        raise ValueError(f"Unsupported class_weight_mode: {mode}")
    return weights.astype(np.float32)


def _safe_stratify(df: pd.DataFrame, label_col: str):
    vc = df[label_col].value_counts()
    return df[label_col] if len(vc) > 1 and vc.min() >= 2 else None


def load_and_prepare_data(cfg: TrainConfig) -> DatasetBundle:
    df = pd.read_csv(cfg.csv_path)
    if cfg.text_col not in df.columns:
        raise ValueError(f"text_col '{cfg.text_col}' not in CSV")
    if cfg.label_col not in df.columns:
        raise ValueError(f"label_col '{cfg.label_col}' not in CSV")
    concept_cols = [c for c in df.columns if c.endswith(cfg.concept_suffix)]
    if not concept_cols:
        raise ValueError(f"No concept columns found with suffix '{cfg.concept_suffix}'")

    keep_cols = [cfg.text_col, cfg.label_col] + concept_cols
    if cfg.id_col and cfg.id_col in df.columns:
        keep_cols.append(cfg.id_col)
    df = df[keep_cols].copy().dropna(subset=[cfg.text_col, cfg.label_col] + concept_cols).reset_index(drop=True)
    df["__row_idx__"] = np.arange(len(df))

    le = LabelEncoder()
    df[cfg.label_col] = le.fit_transform(df[cfg.label_col].astype(str).values)

    train_df, temp_df = train_test_split(
        df,
        train_size=cfg.train_size,
        stratify=_safe_stratify(df, cfg.label_col),
        random_state=cfg.random_seed,
    )
    val_rel = cfg.val_size / (cfg.val_size + cfg.test_size)
    val_df, test_df = train_test_split(
        temp_df,
        train_size=val_rel,
        stratify=_safe_stratify(temp_df, cfg.label_col),
        random_state=cfg.random_seed,
    )

    scaler: Optional[StandardScaler] = None
    if cfg.standardize_concepts:
        scaler = StandardScaler()
        train_df.loc[:, concept_cols] = scaler.fit_transform(train_df[concept_cols].values)
        val_df.loc[:, concept_cols] = scaler.transform(val_df[concept_cols].values)
        test_df.loc[:, concept_cols] = scaler.transform(test_df[concept_cols].values)

    if cfg.clip_concepts:
        for split_df in (train_df, val_df, test_df):
            split_df.loc[:, concept_cols] = split_df[concept_cols].clip(lower=cfg.concept_clip_min, upper=cfg.concept_clip_max)

    y_train = train_df[cfg.label_col].values.astype(int)
    class_weights = compute_class_weights(y_train, len(le.classes_), cfg.class_weight_mode, cfg.manual_class_weights, le.classes_.tolist())
    metadata = {
        "config": asdict(cfg),
        "num_samples": int(len(df)),
        "num_train": int(len(train_df)),
        "num_val": int(len(val_df)),
        "num_test": int(len(test_df)),
        "num_classes": int(len(le.classes_)),
        "class_names": le.classes_.tolist(),
        "concept_cols": concept_cols,
        "class_weights": class_weights.tolist(),
        "train_class_counts": np.bincount(y_train, minlength=len(le.classes_)).tolist(),
    }
    return DatasetBundle(train_df.reset_index(drop=True), val_df.reset_index(drop=True), test_df.reset_index(drop=True), concept_cols, le, scaler, class_weights, metadata)


def save_preprocessing_artifacts(bundle: DatasetBundle, output_dir: str) -> None:
    save_json(to_serializable(bundle.metadata), f"{output_dir}/data_metadata.json")
    save_json({"classes": bundle.label_encoder.classes_.tolist()}, f"{output_dir}/label_mapping.json")
    if bundle.concept_scaler is not None:
        save_json(
            {
                "mean": bundle.concept_scaler.mean_.tolist(),
                "scale": bundle.concept_scaler.scale_.tolist(),
                "var": bundle.concept_scaler.var_.tolist(),
                "concept_cols": bundle.concept_cols,
            },
            f"{output_dir}/concept_scaler.json",
        )


def build_dataloaders(bundle: DatasetBundle, tokenizer, cfg: TrainConfig) -> Tuple[DataLoader, DataLoader, DataLoader]:
    collator = DataCollatorForConceptText(tokenizer)
    train_ds = ConceptTextDataset(bundle.train_df, tokenizer, cfg.text_col, cfg.label_col, bundle.concept_cols, cfg.max_length)
    val_ds = ConceptTextDataset(bundle.val_df, tokenizer, cfg.text_col, cfg.label_col, bundle.concept_cols, cfg.max_length)
    test_ds = ConceptTextDataset(bundle.test_df, tokenizer, cfg.text_col, cfg.label_col, bundle.concept_cols, cfg.max_length)
    train_loader = DataLoader(train_ds, batch_size=cfg.train_batch_size, shuffle=True, num_workers=cfg.num_workers, pin_memory=cfg.pin_memory, collate_fn=collator)
    val_loader = DataLoader(val_ds, batch_size=cfg.eval_batch_size, shuffle=False, num_workers=cfg.num_workers, pin_memory=cfg.pin_memory, collate_fn=collator)
    test_loader = DataLoader(test_ds, batch_size=cfg.eval_batch_size, shuffle=False, num_workers=cfg.num_workers, pin_memory=cfg.pin_memory, collate_fn=collator)
    return train_loader, val_loader, test_loader
