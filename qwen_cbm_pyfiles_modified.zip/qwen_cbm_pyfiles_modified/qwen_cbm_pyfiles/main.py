from __future__ import annotations

import argparse
import os

from accelerate import PartialState

from config import TrainConfig
from data_utils import load_and_prepare_data, save_preprocessing_artifacts
from model import build_model, build_tokenizer
from train import train_model
from utils import ensure_dir, save_json, set_seed


def parse_args() -> TrainConfig:
    p = argparse.ArgumentParser(description="Distributed QLoRA concept bottleneck model")
    p.add_argument("--csv_path", required=True)
    p.add_argument("--text_col", default="text")
    p.add_argument("--label_col", default="label")
    p.add_argument("--output_dir", required=True)
    p.add_argument("--concept_suffix", default="__calibrated")
    p.add_argument("--id_col", default=None)
    p.add_argument("--train_size", type=float, default=0.8)
    p.add_argument("--val_size", type=float, default=0.1)
    p.add_argument("--test_size", type=float, default=0.1)
    p.add_argument("--random_seed", type=int, default=42)

    p.add_argument("--model_name_or_path", required=True)
    p.add_argument("--max_length", type=int, default=512)
    p.add_argument("--pooling", choices=["last_non_pad", "mean"], default="mean")
    p.add_argument("--concept_head_type", choices=["linear", "mlp"], default="linear")
    p.add_argument("--concept_hidden_dim", type=int, default=1024)
    p.add_argument("--dropout", type=float, default=0.1)

    p.add_argument("--load_in_4bit", action="store_true")
    p.add_argument("--lora_r", type=int, default=16)
    p.add_argument("--lora_alpha", type=int, default=32)
    p.add_argument("--lora_dropout", type=float, default=0.05)
    p.add_argument("--lora_target_modules", default="q_proj,k_proj,v_proj,o_proj,up_proj,down_proj,gate_proj")
    p.add_argument("--bnb_4bit_quant_type", default="nf4")
    p.add_argument("--bnb_4bit_compute_dtype", default="bfloat16")
    p.add_argument("--bnb_4bit_use_double_quant", action="store_true")

    p.add_argument("--num_epochs", type=int, default=5)
    p.add_argument("--train_batch_size", type=int, default=1)
    p.add_argument("--eval_batch_size", type=int, default=2)
    p.add_argument("--gradient_accumulation_steps", type=int, default=16)
    p.add_argument("--lr_lora", type=float, default=2e-4)
    p.add_argument("--lr_heads", type=float, default=1e-3)
    p.add_argument("--weight_decay", type=float, default=0.01)
    p.add_argument("--warmup_ratio", type=float, default=0.03)
    p.add_argument("--max_grad_norm", type=float, default=1.0)

    p.add_argument("--lambda_label", type=float, default=0.1)
    p.add_argument("--lambda_mode", choices=["fixed", "auto"], default="fixed")
    p.add_argument("--lambda_min", type=float, default=0.03)
    p.add_argument("--lambda_max", type=float, default=0.3)
    p.add_argument("--lambda_calibration_steps", type=int, default=100)
    p.add_argument("--l1_lambda", type=float, default=1e-4)
    p.add_argument("--concept_loss_type", choices=["mse", "huber", "mae"], default="mse")
    p.add_argument("--class_weight_mode", choices=["balanced", "inverse_sqrt", "none", "manual"], default="balanced")
    p.add_argument("--manual_class_weights", default="")
    p.add_argument("--label_smoothing", type=float, default=0.0)

    p.add_argument("--standardize_concepts", action="store_true")
    p.add_argument("--clip_concepts", action="store_true")
    p.add_argument("--concept_clip_min", type=float, default=-5.0)
    p.add_argument("--concept_clip_max", type=float, default=5.0)

    p.add_argument("--mixed_precision", choices=["no", "fp16", "bf16"], default="bf16")
    p.add_argument("--gradient_checkpointing", action="store_true")
    p.add_argument("--metric_for_best_model", default="macro_f1")
    p.add_argument("--greater_is_better", action="store_true")
    p.add_argument("--num_workers", type=int, default=2)
    p.add_argument("--pin_memory", action="store_true")
    p.add_argument("--save_every_epoch", action="store_true")
    p.add_argument("--log_every_steps", type=int, default=10)

    p.add_argument("--save_train_predictions", action="store_true")
    p.add_argument("--save_val_predictions", action="store_true")
    p.add_argument("--save_test_predictions", action="store_true")
    p.add_argument("--save_train_split_eval", action="store_true")

    cfg = TrainConfig(**vars(p.parse_args()))
    cfg.validate()
    return cfg


def main() -> None:
    cfg = parse_args()
    set_seed(cfg.random_seed)
    state = PartialState()
    if state.is_main_process:
        ensure_dir(cfg.output_dir)
        save_json(cfg.to_dict(), os.path.join(cfg.output_dir, "run_config.json"))
    bundle = load_and_prepare_data(cfg)
    if state.is_main_process:
        save_preprocessing_artifacts(bundle, cfg.output_dir)
    tokenizer = build_tokenizer(cfg)
    model = build_model(cfg, len(bundle.concept_cols), len(bundle.label_encoder.classes_))
    train_model(model, tokenizer, bundle, cfg, cfg.output_dir)


if __name__ == "__main__":
    main()
