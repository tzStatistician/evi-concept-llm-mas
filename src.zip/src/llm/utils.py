import re
import json
import yaml
import argparse
import pandas as pd
from typing import Any, Dict, Optional, Set, Union, Tuple, List

def load_prompt_config(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

# ----------------------------
# Extract JSON from text
# ----------------------------

def extract_json_object(text: str) -> Optional[Dict[str, Any]]:
    """
    Extract a JSON dictionary from a string.
    
    Args:
        text: Input string that may contain JSON (pure JSON or embedded in text)
    
    Returns:
        Parsed JSON dictionary if found and valid, otherwise None
    
    Approach:
        1. Try parsing entire string as JSON
        2. If fails, extract first {...} pattern with regular expression and try parsing that
    """
    
    try:
        obj = json.loads(text)
        return obj if isinstance(obj, dict) else None
    except Exception:
        pass

    m = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if not m:
        return None

    try:
        obj = json.loads(m.group(0))
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None

# ----------------------------
# Normalization
# ----------------------------
def _norm_character(k: Any) -> str:
    """Normalizes keys: snake_case, no spaces, no hyphens."""
    s = str(k).strip().lower()
    # 1. Replace separators with underscores first
    s = s.replace("-", "_").replace(" ", "_")
    # 2. Collapse multiple underscores into one
    s = re.sub(r"_+", "_", s)
    return s

def normalize_dict_keys(obj: Dict[str, Any]) -> Dict[str, Any]:
    """
    Recursively normalize dictionary keys using _norm_character.
    
    - All keys are normalized
    - If a value is a dict, recurse
    - Non-dict values are returned as-is
    """
    normalized = {}

    for k, v in obj.items():
        new_key = _norm_character(k)

        if isinstance(v, dict):
            normalized[new_key] = normalize_dict_keys(v)
        else:
            normalized[new_key] = v

    return normalized


# ----------------------------
# Validate LLM return output
# ----------------------------

def _parse_setting_schema(
    schema: Dict[str, Dict[str, Dict[str, str]]]
) -> Tuple[
    str,
    Set[str],
    Dict[str, Dict[str, Set[str]]],
    Dict[str, Set[str]],
]:
    """
    Parse schema:

    Returns:
      - theory_name
      - concept_set
      - value_sets[concept][attribute] -> allowed values set
      - attribute_sets[concept] -> attribute key set
    """
    theory_name = next(iter(schema))

    concepts = schema[theory_name]
    if not isinstance(concepts, dict):
        raise TypeError("Second-level value must be a dictionary (concepts).")

    concept_set: Set[str] = set(concepts.keys())
    value_sets: Dict[str, Dict[str, Set[str]]] = {}
    attribute_sets: Dict[str, Set[str]] = {}

    for concept, attrs in concepts.items():
        if not isinstance(attrs, dict):
            raise TypeError(
                f"Third-level value for concept '{concept}' must be a dictionary (attributes)."
            )

        attribute_sets[concept] = set(attrs.keys())
        value_sets[concept] = {}

        for attr, values in attrs.items():
            if not isinstance(values, str):
                raise TypeError(
                    f"Values for concept '{concept}' attribute '{attr}' must be a string."
                )

            value_sets[concept][attr] = {v.strip() for v in values.split("|") if v.strip()}

    return theory_name, concept_set, value_sets, attribute_sets


def validate_output_json(
    obj: Any,
    request_dict: Dict[str, Any],
) -> Union[bool, str]:
    """
    Validate LLM output JSON against a 3-level schema:
      { theory: { concept: { attribute: value } } }

    Rules:
    - Top-level key must match theory_name
    - Second-level keys must match concept_set
    - Third-level keys must match attribute_sets[concept]
    - For attribute == 'evidence_span': value must be a string (no membership check)
    - Otherwise: value must be a string and in value_sets[concept][attribute]
    """
    theory_name, concept_set, value_sets, attribute_sets = _parse_setting_schema(
        request_dict["desired_output"]
    )

    if not isinstance(obj, dict):
        return "Error: LLM output is not a dictionary"

    if len(obj) != 1:
        return f"Error: Expected 1 top-level key (theory), got {len(obj)}"

    theory_key = next(iter(obj))
    if theory_key != theory_name:
        return f"Error: Top-level key error: got '{theory_key}', expected '{theory_name}'"

    concepts_obj = obj[theory_key]
    if not isinstance(concepts_obj, dict):
        return f"Error: Value under '{theory_key}' is not a dictionary (concepts)"

    actual_concepts = set(concepts_obj.keys())
    expected_concepts = set(concept_set)

    extra_concepts = actual_concepts - expected_concepts
    if extra_concepts:
        return f"Error: Schema error: extra concepts {extra_concepts}"

    missing_concepts = expected_concepts - actual_concepts
    if missing_concepts:
        return f"Error: Schema error: missing concepts {missing_concepts}"

    for concept_name, attrs_obj in concepts_obj.items():
        if not isinstance(attrs_obj, dict):
            return f"Error: Concept '{concept_name}' is not a dictionary (attributes)"

        expected_attrs = attribute_sets[concept_name]
        actual_attrs = set(attrs_obj.keys())

        extra_attrs = actual_attrs - expected_attrs
        if extra_attrs:
            return f"Error: Concept '{concept_name}' has extra attributes {extra_attrs}"

        missing_attrs = expected_attrs - actual_attrs
        if missing_attrs:
            return f"Error: Concept '{concept_name}' is missing attributes {missing_attrs}"

        for attr_name, val in attrs_obj.items():
            if attr_name in {"evidence_span", "summary"}:
                if not isinstance(val, str):
                    return (
                        f"Error: Concept '{concept_name}' attribute 'evidence_span' "
                        f"must be a string"
                    )
                continue

            if not isinstance(val, str):
                return (
                    f"Error: Concept '{concept_name}' attribute '{attr_name}' "
                    f"must be a string"
                )

            allowed = value_sets[concept_name].get(attr_name)
            if allowed is None:
                return f"Error: Unexpected attribute '{attr_name}' under concept '{concept_name}'"

            if val not in allowed:
                return (
                    f"Error: Concept '{concept_name}' attribute '{attr_name}' "
                    f"has invalid value '{val}'. Allowed: {sorted(allowed)}"
                )

    return True


def _msg_out(
    request_dict: Dict[str, Any],
    msg: Any
) -> Dict[str, Dict[str, Dict[str, Any]]]:
    """
    Create a message output JSON with:
    - top-level key: theory
    - second-level keys: concepts
    - third-level keys: attributes
    - values: msg
    """
    theory_name, concept_set, _, attribute_sets = _parse_setting_schema(
        request_dict["desired_output"]
    )

    return {
        theory_name: {
            concept: {
                attr: msg for attr in attribute_sets[concept]
            }
            for concept in concept_set
        }
    }


# ----------------------------
# Post processing LLM output
# ----------------------------


def add_postfix_to_columns(
    df: pd.DataFrame,
    col_to_rename: List[str],
    post_fix: str
) -> pd.DataFrame:
    """
    Add a postfix to specified columns in a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    col_to_rename : List[str]
        List of column names to which the postfix will be added.
    post_fix : str
        Postfix string to append to column names.

    Returns
    -------
    pd.DataFrame
        DataFrame with renamed columns (original df is not modified).
    """
    rename_map = {
        col: f"{col}{post_fix}"
        for col in col_to_rename
        if col in df.columns
    }

    return df.rename(columns=rename_map)

# ----------------------------
# Parse the CMD input
# ----------------------------

def parse_args():
    parser = argparse.ArgumentParser(
        description="Run LLM annotation pipeline with configurable data and YAML prompt settings."
    )
    parser.add_argument(
        "--data_name",
        type=str,
        required=True,
        help="CSV filename under /root/data1/llm_mas/suicide/data/ (e.g., rsd15k_first499.csv)",
    )
    parser.add_argument(
        "--yaml_name",
        type=str,
        required=True,
        help="YAML filename under /root/data1/llm_mas/suicide/prompts/ (e.g., ipts_qwen.yml)",
    )
    return parser.parse_args()

# ----------------------------
# Add index
# ----------------------------

def add_index_as_column(
    df: pd.DataFrame,
    col_name: str = "row_index",
) -> pd.DataFrame:
    """
    Add the DataFrame index as a regular column.

    - Preserves the original index values
    - Does NOT reset or drop the index
    - Returns a new DataFrame
    """
    out = df.copy()
    out[col_name] = out.index
    return out
