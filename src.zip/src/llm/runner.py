import os
import json
import time
import pandas as pd
from tqdm import tqdm
from datetime import datetime
from typing import Dict

from src.llm.utils import _msg_out, _parse_setting_schema
from src.llm.llm_request import llm_extract


def annotate_df(
    df: pd.DataFrame,
    request_dict: Dict,
    text_col: str = "text",
) -> pd.DataFrame:
    print("=" * 60)
    print(f"Starting {request_dict['theory_name']} annotation for {len(df)} rows")
    print("=" * 60)

    # 3-level schema: theory -> concepts -> attributes
    theory_name, concept_set, _, attribute_sets = _parse_setting_schema(
        request_dict["desired_output"]
    )

    # Stable column order: concept then attribute
    concept_list = sorted(concept_set)
    attr_list_by_concept = {c: sorted(attribute_sets[c]) for c in concept_list}

    results = []
    tiktoker = 1

    output_folder_dir = (
        f"{request_dict['output_path']}/"
        f"{datetime.now().strftime('%Y%m%d')}_"
        f"{request_dict['theory_name']}_"
        f"{request_dict['llm_name']}"
    )

    for _, row in tqdm(df.iterrows(), total=len(df), desc="Annotating", unit="post"):
        text = str(row.get(text_col, "") or "")

        if not text.strip():
            out = _msg_out(request_dict, "Error: Empty input")
        else:
            out = llm_extract(text, request_dict)

        theory_key = request_dict["theory_name"]

        if not isinstance(out, dict) or theory_key not in out:
            out = _msg_out(request_dict, f"Error: Not found theory_name {theory_key}")
            concepts_obj = {}
        else:
            concepts_obj = out[theory_key] or {}

        row_result = {
            "json_output": json.dumps(out, ensure_ascii=False)
        }

        # Flatten to columns: <concept>__<attribute>
        for concept in concept_list:
            concept_obj = concepts_obj.get(concept, {}) or {}

            for attr in attr_list_by_concept[concept]:
                col_name = f"{concept}__{attr}"

                if isinstance(concept_obj, dict):
                    row_result[col_name] = concept_obj.get(attr, "Error: Undefined")
                else:
                    row_result[col_name] = "Error: Undefined"

        results.append(row_result)

        if tiktoker % request_dict["checkpoint_num"] == 0:
            df_results = pd.DataFrame(results)
            output_path = os.path.join(
                output_folder_dir,
                request_dict["checkpoint_path"],
                f"checkpoint_results_{tiktoker}_{theory_name}_{request_dict['llm_name']}.csv",
            )
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            df_results.to_csv(output_path, index=False)

        tiktoker += 1
        time.sleep(0.2)

    return pd.concat([df.reset_index(drop=True), pd.DataFrame(results)], axis=1)
