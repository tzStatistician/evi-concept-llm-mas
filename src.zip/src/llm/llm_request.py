import time
import requests
from typing import Any, Dict
from src.llm.utils import _msg_out, extract_json_object, normalize_dict_keys, validate_output_json

def llm_extract(post_text: str, request_dict: Dict) -> Dict[str, Any]:
    """
    - Empty input -> message-shaped JSON via _msg_out
    - Retry up to max_iteration to obtain valid 3-level JSON:
        { theory: { concept: { attribute: value } } }
      where validate_output_json handles schema + value checks (evidence_span only needs to be str).
    - If all attempts fail -> message-shaped JSON with last error
    """
    if not str(post_text or "").strip():
        return _msg_out(request_dict, "Error: Empty input")

    headers = {
        "Authorization": f"Bearer {request_dict['api_key']}",
        "Content-Type": "application/json",
    }

    user_prompt = request_dict["user_prompt_template"].format(text=post_text)

    payload = {
        "model": request_dict["model"],
        "temperature": request_dict["temprature"],
        "messages": [
            {"role": "system", "content": request_dict["system_prompt"]},
            {"role": "user", "content": user_prompt},
        ],
    }

    last_msg = None

    for attempt in range(1):
        try:
            resp = requests.post(
                request_dict["chat_url"],
                headers=headers,
                json=payload,
                timeout=request_dict["timeout"],
            )
            resp.raise_for_status()

            content = resp.json()["choices"][0]["message"]["content"]
            obj = extract_json_object(content)

            obj_norm = normalize_dict_keys(obj)

            result = validate_output_json(obj_norm, request_dict)
            if result is True:
                return obj

            # validation failed; keep message and retry
            last_msg = result

        except Exception as e:
            last_msg = str(e)

        time.sleep(2 ** attempt)

    return _msg_out(request_dict, last_msg or "Unknown validation error")
