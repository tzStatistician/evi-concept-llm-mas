import numpy as np
import pandas as pd

from dataclasses import dataclass
from typing import Optional, List, Dict, Any, Tuple

from scipy import sparse

from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import (
    f1_score,
    precision_score,
    recall_score,
    accuracy_score,
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
    auc,
)

import xgboost as xgb
import optuna

from tqdm.auto import tqdm
from xgboost.core import XGBoostError

@dataclass
class FeatureArtifacts:
    preprocessor: ColumnTransformer
    feature_names: List[str]

def build_preprocessor(df: pd.DataFrame, cat_cols: List[str]) -> ColumnTransformer:
    """
    One-hot encode categorical columns; pass through all other columns unchanged.
    Returns sparse output when possible.
    """
    cat_cols = [c for c in cat_cols if c in df.columns]
    other_cols = [c for c in df.columns if c not in cat_cols]

    preprocessor = ColumnTransformer(
        transformers=[
            ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=True), cat_cols),
            ("num", "passthrough", other_cols),
        ],
        remainder="drop",
        verbose_feature_names_out=False,
        sparse_threshold=1.0,  # IMPORTANT: favor sparse output
    )
    return preprocessor


from scipy import sparse

def fit_transform_features(
    df_feat: pd.DataFrame,
    cat_cols: List[str],
    X_embed: Optional[np.ndarray] = None,
    use_X_embed: bool = False,
) -> Tuple[sparse.csr_matrix, FeatureArtifacts]:
    preprocessor = build_preprocessor(df_feat, cat_cols)
    X_tab = preprocessor.fit_transform(df_feat)

    # Ensure CSR no matter what sklearn returns
    if sparse.issparse(X_tab):
        X_tab = X_tab.tocsr()
    else:
        X_tab = sparse.csr_matrix(X_tab)

    # feature names
    try:
        tab_names = list(preprocessor.get_feature_names_out())
    except Exception:
        tab_names = [f"f_{i}" for i in range(X_tab.shape[1])]

    if use_X_embed:
        if X_embed is None:
            raise ValueError("use_X_embed=True but X_embed is None.")
        if len(X_embed) != len(df_feat):
            raise ValueError("X_embed row count must match df_feat.")
        X_embed_sp = sparse.csr_matrix(X_embed)
        X_all = sparse.hstack([X_tab, X_embed_sp], format="csr")
        feature_names = tab_names + [f"embed_{j}" for j in range(X_embed.shape[1])]
    else:
        X_all = X_tab
        feature_names = tab_names

    return X_all, FeatureArtifacts(preprocessor=preprocessor, feature_names=feature_names)


def transform_features(
    df_feat: pd.DataFrame,
    artifacts: FeatureArtifacts,
    X_embed: Optional[np.ndarray] = None,
    use_X_embed: bool = False,
) -> sparse.csr_matrix:
    """
    Transform with a fitted preprocessor (no refit).
    Optionally append embedding matrix X_embed.
    """
    X_tab = artifacts.preprocessor.transform(df_feat)

    if use_X_embed:
        if X_embed is None:
            raise ValueError("use_X_embed=True but X_embed is None.")
        if len(X_embed) != len(df_feat):
            raise ValueError("X_embed row count must match df_feat.")
        X_embed_sp = sparse.csr_matrix(X_embed)
        return sparse.hstack([X_tab, X_embed_sp], format="csr").tocsr()

    return X_tab.tocsr()

def stratified_split(
    df: pd.DataFrame,
    target_col: str = "sentiment",
    test_size: float = 0.2,
    random_state: int = 42,
) -> Tuple[pd.DataFrame, pd.DataFrame, np.ndarray, np.ndarray]:
    y = df[target_col].to_numpy()
    df_feat = df.drop(columns=[target_col])

    df_train, df_test, y_train, y_test = train_test_split(
        df_feat,
        y,
        test_size=test_size,
        random_state=random_state,
        stratify=y,
    )
    return df_train, df_test, y_train, y_test

def compute_sample_weight(y: np.ndarray) -> np.ndarray:
    """
    Inverse-frequency weights: w_c = N / (K * count_c)
    """
    classes, counts = np.unique(y, return_counts=True)
    k = len(classes)
    n = len(y)
    weight_by_class = {c: n / (k * cnt) for c, cnt in zip(classes, counts)}
    return np.array([weight_by_class[label] for label in y], dtype=float)

def evaluate_multiclass(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_proba: np.ndarray,
    labels: Optional[List[Any]] = None,
) -> Dict[str, Any]:
    if labels is None:
        labels = list(np.unique(y_true))

    out: Dict[str, Any] = {}
    out["accuracy"] = float(accuracy_score(y_true, y_pred))
    out["f1_macro"] = float(f1_score(y_true, y_pred, average="macro"))
    out["precision_macro"] = float(precision_score(y_true, y_pred, average="macro", zero_division=0))
    out["recall_macro"] = float(recall_score(y_true, y_pred, average="macro", zero_division=0))

    out["confusion_matrix"] = confusion_matrix(y_true, y_pred, labels=labels)
    out["classification_report"] = classification_report(
        y_true, y_pred, labels=labels, output_dict=True, zero_division=0
    )

    # Multiclass ROC-AUC (OVR)
    # y_proba shape: (n, n_classes)
    try:
        out["roc_auc_ovr_macro"] = float(roc_auc_score(y_true, y_proba, multi_class="ovr", average="macro"))
        out["roc_auc_ovr_weighted"] = float(roc_auc_score(y_true, y_proba, multi_class="ovr", average="weighted"))
    except Exception as e:
        out["roc_auc_error"] = str(e)

    return out

def roc_curve_ovr_data(
    y_true: np.ndarray,
    y_proba: np.ndarray,
    labels: Optional[List[Any]] = None,
) -> Dict[str, Any]:
    """
    Returns ROC curve data for each class (OVR) + macro-average.
    """
    if labels is None:
        labels = list(np.unique(y_true))

    # binarize y
    label_to_index = {lab: i for i, lab in enumerate(labels)}
    y_idx = np.array([label_to_index[v] for v in y_true], dtype=int)

    n_classes = len(labels)
    y_bin = np.zeros((len(y_true), n_classes), dtype=int)
    y_bin[np.arange(len(y_true)), y_idx] = 1

    fpr, tpr, roc_auc = {}, {}, {}

    for i, lab in enumerate(labels):
        fpr[i], tpr[i], _ = roc_curve(y_bin[:, i], y_proba[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])

    # Macro-average ROC
    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += np.interp(all_fpr, fpr[i], tpr[i])
    mean_tpr /= n_classes

    fpr["macro"] = all_fpr
    tpr["macro"] = mean_tpr
    roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])

    return {
        "labels": labels,
        "fpr": fpr,
        "tpr": tpr,
        "auc": roc_auc,
    }

def suggest_xgb_params_from_grid(trial: optuna.Trial) -> Dict[str, Any]:
    """
    Discrete choices (grid-like). Adjust ranges as needed.
    """
    return {
        "max_depth": trial.suggest_categorical("max_depth", [3, 4, 5, 6, 8, 10]),
        "learning_rate": trial.suggest_categorical("learning_rate", [0.01, 0.03, 0.05, 0.1, 0.2]),
        "n_estimators": trial.suggest_categorical("n_estimators", [300, 600, 1000, 1500]),
        "subsample": trial.suggest_categorical("subsample", [0.6, 0.8, 1.0]),
        "colsample_bytree": trial.suggest_categorical("colsample_bytree", [0.6, 0.8, 1.0]),
        "min_child_weight": trial.suggest_categorical("min_child_weight", [1, 3, 5, 10]),
        "gamma": trial.suggest_categorical("gamma", [0.0, 0.5, 1.0, 2.0]),
        "reg_alpha": trial.suggest_categorical("reg_alpha", [0.0, 0.1, 1.0, 10.0]),
        "reg_lambda": trial.suggest_categorical("reg_lambda", [1.0, 5.0, 10.0, 20.0]),
    }


def xgb_supports_gpu() -> bool:
    """
    Returns True if this XGBoost build can actually train with GPU.
    We do a tiny fit to avoid false positives.
    """
    try:
        X_small = np.random.randn(32, 4).astype(np.float32)
        y_small = np.random.randint(0, 2, size=32).astype(np.int32)

        m = xgb.XGBClassifier(
            tree_method="gpu_hist",
            predictor="gpu_predictor",
            device="cuda:0",
            n_estimators=1,
            max_depth=2,
            learning_rate=0.3,
        )
        m.fit(X_small, y_small, verbose=False)
        return True
    except Exception:
        return False
    
def get_xgb_device_params(n_gpus: int = 2, gpu_id: int = 0) -> dict:
    """
    Returns execution params. Do NOT set 'predictor' to avoid warnings in some builds.
    """
    if xgb_supports_gpu():
        gpu_id = int(gpu_id) % max(int(n_gpus), 1)
        return {
            "tree_method": "gpu_hist",
            "device": f"cuda:{gpu_id}",
        }
    else:
        return {
            "tree_method": "hist",  # CPU fast histogram
        }


def run_optuna_cv(
    X_train: sparse.csr_matrix,
    y_train: np.ndarray,
    n_classes: int,
    n_trials: int = 40,
    n_splits: int = 5,
    random_state: int = 42,
    n_gpus: int = 2,
) -> Dict[str, Any]:
    """
    Optuna + 5-fold CV. Objective = mean macro-F1 across folds.
    Uses 2 GPUs by assigning trials to cuda:0/cuda:1.
    """
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)

    def objective(trial: optuna.Trial) -> float:
        gpu_id = trial.number % n_gpus
        params = suggest_xgb_params_from_grid(trial)

        device_params = get_xgb_device_params(n_gpus=n_gpus, gpu_id=gpu_id)
        
        model = xgb.XGBClassifier(
            objective="multi:softprob",
            num_class=n_classes,
            eval_metric="mlogloss",
            n_jobs=4,
            **device_params,
            **params,
        )
        # Fixed multiclass + GPU settings
        # model = xgb.XGBClassifier(
        #     objective="multi:softprob",
        #     num_class=n_classes,
        #     tree_method="gpu_hist",
        #     predictor="gpu_predictor",
        #     device=f"cuda:{gpu_id}",
        #     eval_metric="mlogloss",
        #     n_jobs=4,  # CPU threads (data prep / overhead); adjust as needed
        #     **params,
        # )

        fold_scores = []
        for tr_idx, va_idx in skf.split(X_train, y_train):
            X_tr, X_va = X_train[tr_idx], X_train[va_idx]
            y_tr, y_va = y_train[tr_idx], y_train[va_idx]

            w_tr = compute_sample_weight(y_tr)

            model.fit(
                X_tr, y_tr,
                sample_weight=w_tr,
                verbose=False,
            )

            y_va_pred = model.predict(X_va)
            score = f1_score(y_va, y_va_pred, average="macro")
            fold_scores.append(score)

        return float(np.mean(fold_scores))

    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=n_trials, show_progress_bar=True)

    return {
        "study": study,
        "best_params": study.best_params,
        "best_value": study.best_value,
    }

def crossval_diagnostics(
    X_train: sparse.csr_matrix,
    y_train: np.ndarray,
    best_params: Dict[str, Any],
    n_classes: int,
    n_splits: int = 5,
    random_state: int = 42,
    n_gpus: int = 2,
) -> Dict[str, Any]:
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    fold_metrics = []

    for fold, (tr_idx, va_idx) in enumerate(skf.split(X_train, y_train), start=1):
        gpu_id = (fold - 1) % n_gpus

        device_params = get_xgb_device_params(n_gpus=n_gpus, gpu_id=gpu_id)
        model = xgb.XGBClassifier(
            objective="multi:softprob",
            num_class=n_classes,
            eval_metric="mlogloss",
            n_jobs=4,
            **device_params,
            **best_params,
        )

        X_tr, X_va = X_train[tr_idx], X_train[va_idx]
        y_tr, y_va = y_train[tr_idx], y_train[va_idx]
        w_tr = compute_sample_weight(y_tr)

        model.fit(X_tr, y_tr, sample_weight=w_tr, verbose=False)

        y_va_pred = model.predict(X_va)
        y_va_proba = model.predict_proba(X_va)

        fold_out = evaluate_multiclass(y_va, y_va_pred, y_va_proba)
        fold_out["fold"] = fold
        fold_metrics.append(fold_out)

    # Aggregate key macro metrics
    agg = {
        "f1_macro_mean": float(np.mean([m["f1_macro"] for m in fold_metrics])),
        "f1_macro_std": float(np.std([m["f1_macro"] for m in fold_metrics])),
        "precision_macro_mean": float(np.mean([m["precision_macro"] for m in fold_metrics])),
        "recall_macro_mean": float(np.mean([m["recall_macro"] for m in fold_metrics])),
    }

    return {"fold_metrics": fold_metrics, "aggregate": agg}

def fit_final_model(
    X_train: sparse.csr_matrix,
    y_train: np.ndarray,
    best_params: Dict[str, Any],
    n_classes: int,
    gpu_id: int = 0,
) -> xgb.XGBClassifier:
    

    device_params = get_xgb_device_params(n_gpus=1, gpu_id=gpu_id)

    model = xgb.XGBClassifier(
        objective="multi:softprob",
        num_class=n_classes,
        eval_metric="mlogloss",
        n_jobs=4,
        **device_params,
        **best_params,
    )

    w_train = compute_sample_weight(y_train)
    model.fit(X_train, y_train, sample_weight=w_train, verbose=False)
    return model

from scipy import sparse
import numpy as np
import xgboost as xgb

def _sanitize_csr_for_xgb(X_csr: sparse.csr_matrix) -> sparse.csr_matrix:
    if not sparse.isspmatrix_csr(X_csr):
        X_csr = X_csr.tocsr()

    # XGBoost DMatrix is happiest with float32
    if X_csr.dtype != np.float32:
        X_csr = X_csr.astype(np.float32)

    X_csr.sort_indices()

    # Some builds require int32 indices
    if X_csr.indices.dtype != np.int32:
        X_csr.indices = X_csr.indices.astype(np.int32, copy=False)
    if X_csr.indptr.dtype != np.int32:
        X_csr.indptr = X_csr.indptr.astype(np.int32, copy=False)

    # You said you filled NaN with -1, so we should not have NaN/Inf now,
    # but we keep a hard check to fail fast if upstream changes later.
    d = X_csr.data
    if np.isnan(d).any() or np.isinf(d).any():
        raise ValueError("X contains NaN/Inf in sparse data. Fix before SHAP contribs.")

    return X_csr

def _normalize_pred_contribs(contribs: np.ndarray, n_classes: int, n_features: int) -> np.ndarray:
    """
    Normalize XGBoost pred_contribs output to shape: (n_samples, n_classes, n_features+1).

    Expected shapes seen in the wild:
      - (n, K, p+1)
      - (n, K*(p+1))  # flattened
    """
    contribs = np.asarray(contribs)
    p1 = n_features + 1

    if contribs.ndim == 3:
        # (n, K, p+1)
        if contribs.shape[1] != n_classes or contribs.shape[2] != p1:
            raise ValueError(f"Unexpected 3D contribs shape {contribs.shape}, expected (n,{n_classes},{p1})")
        return contribs

    if contribs.ndim == 2:
        # (n, K*(p+1)) flattened
        expected = n_classes * p1
        if contribs.shape[1] != expected:
            raise ValueError(f"Unexpected 2D contribs shape {contribs.shape}, expected second dim {expected}")
        return contribs.reshape(contribs.shape[0], n_classes, p1)

    raise ValueError(f"Unrecognized contribs shape: {contribs.shape}")

def shap_analysis_multiclass(
    model: xgb.XGBClassifier,
    X_any: sparse.csr_matrix,
    feature_names: List[str],
    class_names: List[str] | None = None,
    sample_size: int = 2000,
    random_state: int = 42,
    approx_contribs: bool = True,
    batch_size: int = 256,
    show_progress: bool = True,
) -> Dict[str, Any]:
    """
    Fast, multiclass-safe SHAP analysis using XGBoost native pred_contribs,
    with an optional progress bar by computing in batches.

    Returns:
      - contribs: (n_sample, K, p+1)   # last col is bias
      - shap_values: (n_sample, K, p)
      - global_mean_abs: (p,)
      - mean_abs_per_class: (K, p)
    """
    rng = np.random.default_rng(random_state)
    n = X_any.shape[0]
    idx = rng.choice(n, size=min(sample_size, n), replace=False)

    X_s = X_any[idx]
    if not sparse.issparse(X_s):
        X_s = sparse.csr_matrix(X_s)
    X_s = _sanitize_csr_for_xgb(X_s)

    booster = model.get_booster()

    # infer class count
    if class_names is not None:
        n_classes = len(class_names)
    else:
        n_classes = int(model.predict_proba(X_s[:1]).shape[1])
        class_names = [f"class_{k}" for k in range(n_classes)]

    p = len(feature_names)
    n_s = X_s.shape[0]

    # Batch loop with tqdm
    n_batches = (n_s + batch_size - 1) // batch_size
    iterator = range(n_batches)
    if show_progress:
        iterator = tqdm(iterator, total=n_batches, desc="XGB pred_contribs (SHAP)", leave=True)

    contrib_chunks = []
    for b in iterator:
        start = b * batch_size
        end = min((b + 1) * batch_size, n_s)

        X_b = X_s[start:end]
        dmat = xgb.DMatrix(X_b)

        try:
            contrib_b = booster.predict(
                dmat,
                pred_contribs=True,
                approx_contribs=approx_contribs,
                strict_shape=True,
            )
        except TypeError:
            contrib_b = booster.predict(
                dmat,
                pred_contribs=True,
                approx_contribs=approx_contribs,
            )

        contrib_chunks.append(contrib_b)

    contribs = np.concatenate(contrib_chunks, axis=0)

    # Normalize to (n, K, p+1)
    contribs = _normalize_pred_contribs(contribs, n_classes=n_classes, n_features=p)

    shap_vals = contribs[:, :, :p]  # (n, K, p)
    bias_vals = contribs[:, :, p]   # (n, K)

    mean_abs_per_class = np.mean(np.abs(shap_vals), axis=0)  # (K, p)
    global_mean_abs = np.mean(mean_abs_per_class, axis=0)    # (p,)

    return {
        "sample_index": idx,
        "feature_names": feature_names,
        "class_names": class_names,
        "contribs": contribs,
        "shap_values": shap_vals,
        "bias_values": bias_vals,
        "global_mean_abs": global_mean_abs,
        "mean_abs_per_class": mean_abs_per_class,
        "approx_contribs": approx_contribs,
        "batch_size": batch_size,
    }

def xgb_optuna_pipeline(
    df: pd.DataFrame,
    X: Optional[np.ndarray] = None,
    use_X: bool = False,
    cat_cols: Optional[List[str]] = None,
    target_col: str = "sentiment",
    test_size: float = 0.2,
    random_state: int = 42,
    n_trials: int = 40,
    n_splits: int = 5,
    n_gpus: int = 2,
    shap_sample_size: int = 2000,
) -> Dict[str, Any]:
    if cat_cols is None:
        cat_cols = []

    # 1) split
    df_train, df_test, y_train, y_test = stratified_split(
        df, target_col=target_col, test_size=test_size, random_state=random_state
    )

    # inside your pipeline, right after split:
    train_index = df_train.index.to_numpy()
    test_index = df_test.index.to_numpy()


    # If embeddings are used, split them in the same way by index alignment
    # use_X = bool(use_X)  # None -> False, 0 -> False, 1 -> True
    if use_X:
        if X is None:
            raise ValueError("use_X=True but X is None.")
        X_train_embed = X[df_train.index]
        X_test_embed = X[df_test.index]
    else:
        X_train_embed, X_test_embed = None, None

    # 2) fit/transform features
    X_train_all, feat_art = fit_transform_features(
        df_train, cat_cols=cat_cols, X_embed=X_train_embed, use_X_embed=use_X
    )
    X_test_all = transform_features(
        df_test, artifacts=feat_art, X_embed=X_test_embed, use_X_embed=use_X
    )

    # 3) class count / classes
    classes = list(np.unique(y_train))
    n_classes = len(classes)

    # 4) optuna CV to find best params
    tuning = run_optuna_cv(
        X_train=X_train_all,
        y_train=y_train,
        n_classes=n_classes,
        n_trials=n_trials,
        n_splits=n_splits,
        random_state=random_state,
        n_gpus=n_gpus,
    )

    best_params = tuning["best_params"]
    study = tuning["study"]

    # 5) store CV diagnostics (fold-wise metrics)
    cv_diag = crossval_diagnostics(
        X_train=X_train_all,
        y_train=y_train,
        best_params=best_params,
        n_classes=n_classes,
        n_splits=n_splits,
        random_state=random_state,
        n_gpus=n_gpus,
    )

    # 6) train final model on full train set
    final_model = fit_final_model(
        X_train=X_train_all,
        y_train=y_train,
        best_params=best_params,
        n_classes=n_classes,
        gpu_id=0,  # final fit can stay on cuda:0
    )

    # 7) evaluate test
    y_test_pred = final_model.predict(X_test_all)
    y_test_proba = final_model.predict_proba(X_test_all)

    test_metrics = evaluate_multiclass(y_test, y_test_pred, y_test_proba, labels=classes)
    roc_data = roc_curve_ovr_data(y_test, y_test_proba, labels=classes)

    # 8) SHAP (optional; may be heavy). Wrap to avoid killing the pipeline.
    shap_payload = None
    try:
        shap_payload = shap_analysis_multiclass(
            model=final_model,
            X_any=X_train_all,
            feature_names=feat_art.feature_names,
            class_names=classes,     # your 4 labels
            sample_size=2000,
            batch_size=256,          # adjust: 128/256/512
            show_progress=True,
            approx_contribs=True,
        )

    except Exception as e:
        shap_payload = {"error": str(e)}

    return {
        "classes": classes,
        "preprocessor": feat_art.preprocessor,
        "feature_names": feat_art.feature_names,
        "study": study,
        "best_params": best_params,
        "cv": cv_diag,
        "final_model": final_model,
        "test_metrics": test_metrics,
        "roc_data": roc_data,
        "shap": shap_payload,
        "data_shapes": {
            "X_train": tuple(X_train_all.shape),
            "X_test": tuple(X_test_all.shape),
            "y_train": int(len(y_train)),
            "y_test": int(len(y_test)),
        },
        "split_index": {
            "train_index": train_index,
            "test_index": test_index,
            "test_size": test_size,
            "random_state": random_state,
        },
    }
