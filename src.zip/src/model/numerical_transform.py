import numpy as np
import pandas as pd
from typing import List

import numpy as np
import pandas as pd
from typing import List, Literal


def log1p_transform(
    df: pd.DataFrame,
    col_to_transform: List[str],
    fill_method: Literal["mean", "median"] = "median",
) -> pd.DataFrame:
    """
    Apply log1p transform to specified columns and replace them
    with new columns suffixed by '_log'.

    Safety:
    - log1p(x) is only valid for x > -1
    - Any values <= -1 are replaced using mean/median (user-controlled)

    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe.
    col_to_transform : List[str]
        List of column names to apply log1p transform.
    fill_method : {"mean", "median"}, default="median"
        How to replace invalid values (<= -1) before log1p.

    Returns
    -------
    pd.DataFrame
        DataFrame with transformed columns replacing originals.
    """
    df_out = df.copy()

    for col in col_to_transform:
        if col not in df_out.columns:
            print(f"[WARN] Column '{col}' not found. Skipped.")
            continue

        # ---- Step 1: detect invalid values ----
        invalid_mask = df_out[col] <= -1
        n_invalid = invalid_mask.sum()

        if n_invalid > 0:
            # compute replacement value from valid subset only
            valid_values = df_out.loc[~invalid_mask, col]

            if valid_values.empty:
                raise ValueError(
                    f"Column '{col}' has no valid values (> -1). Cannot apply log1p."
                )

            if fill_method == "mean":
                fill_value = valid_values.mean()
            elif fill_method == "median":
                fill_value = valid_values.median()
            else:
                raise ValueError("fill_method must be 'mean' or 'median'")

            print(
                f"[INFO] Column '{col}': Found {n_invalid} values <= -1. "
                f"Replacing with {fill_method}={fill_value:.4f}"
            )

            # replace invalid values
            df_out.loc[invalid_mask, col] = fill_value

        # ---- Step 2: apply safe log1p ----
        df_out[f"{col}_log"] = np.log1p(df_out[col])

        # ---- Step 3: drop original column ----
        df_out.drop(columns=col, inplace=True)

    return df_out


def cyclic_sin_cos_transform(
    df: pd.DataFrame,
    col_to_transform: List[str],
    period: int = 24,
    drop_original: bool = True,
) -> pd.DataFrame:
    """
    Apply sin/cos cyclic transformation to specified columns.

    Adds:
      - {col}_sin
      - {col}_cos

    Parameters
    ----------
    df : pd.DataFrame
    col_to_transform : list[str]
        Columns representing cyclic variables.
    period : int
        Period of the cycle (e.g., 24 for hour_of_day).
    drop_original : bool
        Whether to drop the original column.

    Returns
    -------
    pd.DataFrame
    """
    df_out = df.copy()

    for col in col_to_transform:
        if col not in df_out.columns:
            print(f"[WARN] Column '{col}' not found. Skipped.")
            continue

        angle = 2 * np.pi * df_out[col] / period
        df_out[f"{col}_sin"] = np.sin(angle)
        df_out[f"{col}_cos"] = np.cos(angle)

        if drop_original:
            df_out.drop(columns=col, inplace=True)

    return df_out
