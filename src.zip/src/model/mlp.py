from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import pandas as pd
import torch
import torch.nn as nn


# ============================================================
# Torch helpers: small, clean MLPs
# ============================================================

def _make_mlp(
    d_in: int,
    d_hidden: int,
    d_out: int,
    n_layers: int = 2,
    dropout: float = 0.1,
) -> nn.Module:
    """
    Build a small MLP:
      - n_layers=1: Linear -> LayerNorm -> GELU -> Dropout -> Linear(d_hidden->d_out)  (still 2 linears)
      - n_layers=2: (Linear->LN->GELU->Dropout) x2 + Linear_out
      - n_layers=3: (Linear->LN->GELU->Dropout) x3 + Linear_out

    For research simplicity:
    - uses LayerNorm (batch-size agnostic)
    - uses GELU (works well in Transformer ecosystems)
    """
    if n_layers < 1 or n_layers > 3:
        raise ValueError("n_layers must be 1, 2, or 3")

    layers: List[nn.Module] = []

    # First block
    layers += [
        nn.Linear(d_in, d_hidden),
        nn.LayerNorm(d_hidden),
        nn.GELU(),
        nn.Dropout(dropout),
    ]

    # Optional additional hidden blocks
    for _ in range(n_layers - 1):
        layers += [
            nn.Linear(d_hidden, d_hidden),
            nn.LayerNorm(d_hidden),
            nn.GELU(),
            nn.Dropout(dropout),
        ]

    # Output layer (no activation; leave it to downstream)
    layers += [nn.Linear(d_hidden, d_out)]

    return nn.Sequential(*layers)


def _df_to_tensor(
    df: pd.DataFrame,
    cols: List[str],
    device: Optional[torch.device] = None,
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    """
    Convert df[cols] to a float tensor.
    - No scaling/imputation here (per your request).
    - Ensures consistent column ordering (important for learnable weights).
    """
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise KeyError(f"These cols are not in df.columns: {missing}")

    x = torch.tensor(df[cols].to_numpy(), dtype=dtype, device=device)
    return x


# ============================================================
# 2) Within-group MLP encoder (trainable torch module)
# ============================================================

class WithinGroupMLPEncoder(nn.Module):
    """
    Trainable within-group encoder.
    Input: numeric features for one group
    Output: group embedding h^(g)

    You pass the full df at forward-time; the module selects `cols_features`.
    This keeps the interface close to your research workflow.

    Typical usage:
        enc = WithinGroupMLPEncoder(cols_features=temporal_cols, d_out=128)
        h_tmp = enc(df_batch)  # (B, 128)
    """

    def __init__(
        self,
        cols_features: List[str],
        d_hidden: int = 256,
        d_out: int = 128,
        n_layers: int = 2,
        dropout: float = 0.1,
        device: Optional[torch.device] = None,
    ):
        super().__init__()
        if not isinstance(cols_features, list) or len(cols_features) == 0:
            raise ValueError("cols_features must be a non-empty list of column names")

        self.cols_features = cols_features
        self.device_ = device

        d_in = len(cols_features)
        self.encoder = _make_mlp(
            d_in=d_in,
            d_hidden=d_hidden,
            d_out=d_out,
            n_layers=n_layers,
            dropout=dropout,
        )

    def forward(self, df: pd.DataFrame) -> torch.Tensor:
        x = _df_to_tensor(df, self.cols_features, device=self.device_)
        h = self.encoder(x)
        return h


def build_within_group_mlp(
    df: pd.DataFrame,
    cols_features: List[str],
    d_hidden: int = 256,
    d_out: int = 128,
    n_layers: int = 2,
    dropout: float = 0.1,
    device: Optional[torch.device] = None,
) -> WithinGroupMLPEncoder:
    """
    Factory function to create a trainable within-group MLP encoder.

    This returns an nn.Module with parameters, so it is trainable once you
    include it in a larger model and pass its parameters to an optimizer.

    df is included only to validate columns early (research convenience).
    """
    # Early validation against df
    missing = [c for c in cols_features if c not in df.columns]
    if missing:
        raise KeyError(f"These cols_features are not in df.columns: {missing}")

    return WithinGroupMLPEncoder(
        cols_features=cols_features,
        d_hidden=d_hidden,
        d_out=d_out,
        n_layers=n_layers,
        dropout=dropout,
        device=device,
    )


# ============================================================
# 3) Overall fusion MLP (trainable torch module)
# ============================================================

class FusionMLP(nn.Module):
    """
    Trainable fusion MLP that takes multiple group embeddings and outputs a
    single fused structured embedding s_tilde.

    You can feed it:
      - a list of tensors [h_tmp, h_lin, h_psy]
      - or a dict {"temporal": h_tmp, ...} with an explicit order

    Typical usage:
        fusion = FusionMLP(d_in=sum(d_out_groups), d_out=256)
        s_tilde = fusion([h_tmp, h_lin, h_llm])  # (B, 256)
    """

    def __init__(
        self,
        d_in: int,
        d_hidden: int = 256,
        d_out: int = 256,
        n_layers: int = 2,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.fuser = _make_mlp(
            d_in=d_in,
            d_hidden=d_hidden,
            d_out=d_out,
            n_layers=n_layers,
            dropout=dropout,
        )

    def forward(self, group_embeds: List[torch.Tensor]) -> torch.Tensor:
        if not isinstance(group_embeds, list) or len(group_embeds) == 0:
            raise ValueError("group_embeds must be a non-empty list of tensors")

        # Basic shape checks
        batch_sizes = [t.shape[0] for t in group_embeds]
        if len(set(batch_sizes)) != 1:
            raise ValueError(f"All group embeddings must share batch size. Got: {batch_sizes}")

        x = torch.cat(group_embeds, dim=1)
        return self.fuser(x)


def build_fusion_mlp(
    d_in: int,
    d_hidden: int = 256,
    d_out: int = 256,
    n_layers: int = 2,
    dropout: float = 0.1,
) -> FusionMLP:
    """
    Factory function to create a trainable fusion MLP.
    """
    return FusionMLP(
        d_in=d_in,
        d_hidden=d_hidden,
        d_out=d_out,
        n_layers=n_layers,
        dropout=dropout,
    )
