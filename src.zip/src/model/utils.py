import joblib
from pathlib import Path
import argparse
import os


def save_artifacts_onefile(artifacts: dict, filepath: str, compress: int = 3):
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(artifacts, path, compress=compress)
    print(f"Saved artifacts to: {path.resolve()}")

def parse_args():
    parser = argparse.ArgumentParser(
        description="Run XGBoost Optuna pipeline with named YAML config"
    )
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Config name only (e.g., linguistic_concepts, temporal_only)",
    )
    return parser.parse_args()
