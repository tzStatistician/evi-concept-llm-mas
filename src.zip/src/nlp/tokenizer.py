import os
import pickle
import nltk
import pandas as pd
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import TreebankWordTokenizer

def nltk_tokenize_pipeline(
    df: pd.DataFrame,
    text_col: str = "cleaned_text",
    base_path: str | None = None,
    nltk_data_dirname: str = "nltk_data",
    punkt_relpath: str = os.path.join("tokenizers", "punkt", "english.pickle"),
    out_tokens_col: str = "tokens",
    out_no_stop_col: str = "tokens_no_stop",
    out_lemma_col: str = "final_tokens",
    lowercase: bool = True,
    keep_alpha_numeric_only: bool = False,
) -> pd.DataFrame:
    """
    Apply an NLTK tokenization -> stopword removal -> lemmatization pipeline to a dataframe.

    Key behavior:
    - Force-load punkt sentence tokenizer via pickle to bypass nltk.data.load restricted error.
    - Uses TreebankWordTokenizer for word tokenization (no download needed).
    - Attempts to load stopwords + WordNet lemmatizer; falls back gracefully if missing.

    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe.
    text_col : str
        Column containing raw/cleaned text.
    base_path : str | None
        Base path where `nltk_data` folder exists. Defaults to os.getcwd().
    nltk_data_dirname : str
        Folder name under base_path holding NLTK data.
    punkt_relpath : str
        Relative path (under nltk_data) to punkt english.pickle.
    out_tokens_col, out_no_stop_col, out_lemma_col : str
        Output column names.
    lowercase : bool
        Whether to lowercase tokens.
    keep_alpha_numeric_only : bool
        If True, keep tokens where token.isalnum().

    Returns
    -------
    pd.DataFrame
        A copy of df with new columns added.
    """

    if base_path is None:
        base_path = os.getcwd()

    df_out = df.copy()

    # ------------------------------------------
    # 1) SETUP NLTK PATHS & FORCE LOAD PUNKT
    # ------------------------------------------
    nltk_data_dir = os.path.join(base_path, nltk_data_dirname)
    if nltk_data_dir not in nltk.data.path:
        nltk.data.path.append(nltk_data_dir)

    punkt_path = os.path.join(nltk_data_dir, punkt_relpath)

    # Force-load punkt tokenizer via pickle (bypass restricted error)
    try:
        with open(punkt_path, "rb") as f:
            custom_sent_tokenizer = pickle.load(f)
            print(f"Tokenizer loaded successfully via pickle from {punkt_path}!")
    except FileNotFoundError:
        # Fallback to naive tokenizer if missing
        class DummyTokenizer:
            def tokenize(self, t):  # noqa: N802
                return [t]

        custom_sent_tokenizer = DummyTokenizer()

    word_tokenizer = TreebankWordTokenizer()

    # Stopwords + Lemmatizer (graceful fallback)
    try:
        stop_words = set(stopwords.words("english"))
        lemmatizer = WordNetLemmatizer()
        print("✅ Stopwords and Lemmatizer loaded.")
    except LookupError:
        stop_words = set()
        lemmatizer = None

    # ------------------------------------------
    # 2) DEFINE INNER TRANSFORMS
    # ------------------------------------------
    def step1_force_nltk(text):
        if not isinstance(text, str):
            return []

        sentences = custom_sent_tokenizer.tokenize(text)

        tokens = []
        for sent in sentences:
            tokens.extend(word_tokenizer.tokenize(sent))

        if lowercase:
            tokens = [t.lower() for t in tokens]

        if keep_alpha_numeric_only:
            tokens = [t for t in tokens if t.isalnum()]

        return tokens

    def step2_remove_stops(token_list):
        if not isinstance(token_list, list):
            return []
        if not stop_words:
            return token_list
        return [w for w in token_list if w not in stop_words]

    def step3_lemmatize(token_list):
        if not isinstance(token_list, list):
            return []
        if lemmatizer is None:
            return token_list
        return [lemmatizer.lemmatize(w) for w in token_list]

    # ------------------------------------------
    # 3) RUN PIPELINE
    # ------------------------------------------
    if text_col not in df_out.columns:
        raise KeyError(f"Column '{text_col}' not found in df")

    print("1. Tokenizing (NLTK)...")
    df_out[out_tokens_col] = df_out[text_col].apply(step1_force_nltk)
    print("2. Removing Stopwords...")
    df_out[out_no_stop_col] = df_out[out_tokens_col].apply(step2_remove_stops)
    print("3. Lemmatizing...")
    df_out[out_lemma_col] = df_out[out_no_stop_col].apply(step3_lemmatize)

    return df_out