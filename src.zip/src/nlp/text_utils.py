import pandas as pd
import numpy as np
import ast
import re
import string
from typing import List

def clean_text_head(text):
    if not isinstance(text, str): return ""
    text = text.lower()
    # Note: Adding curly quote ’ to punctuation list just in case
    custom_punctuation = string.punctuation + "’" 
    text = re.sub(f"[{re.escape(custom_punctuation)}]", " ", text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

# ----------------------------
# Convert token columns to token list
# ----------------------------

def normalize_list_columns(df: pd.DataFrame, col_list: List[str] = ['tokens', 'tokens_no_stop', 'final_tokens']) -> pd.DataFrame:
    """
    Normalize specified columns so every cell contains a Python list.

    Handles:
    - list
    - numpy.ndarray
    - stringified lists
    - malformed token strings: [one, two, three]
    - NaN / None

    Raises on unsupported types.
    """

    df = df.copy()

    for col in col_list:
        if col not in df.columns:
            raise KeyError(f"Column '{col}' not found in DataFrame")

        def _to_list(x):
            # Case 1: already a Python list
            if isinstance(x, list):
                return x

            # Case 2: numpy array
            if isinstance(x, np.ndarray):
                return x.tolist()

            # Case 3: None / NaN (scalar only)
            if x is None:
                return []

            if isinstance(x, float) and pd.isna(x):
                return []

            # Case 4: string
            if isinstance(x, str):
                x = x.strip()

                # Try safe literal evaluation
                try:
                    parsed = ast.literal_eval(x)
                    if isinstance(parsed, list):
                        return parsed
                except Exception:
                    pass

                # Handle malformed token strings
                if x.startswith("[") and x.endswith("]"):
                    x = x[1:-1]

                return [t.strip() for t in x.split(",") if t.strip()]

            # Anything else is a bug upstream
            raise TypeError(
                f"Unsupported type in column '{col}': {type(x)}"
            )

        df[col] = df[col].apply(_to_list)

    return df

import pandas as pd

# ----------------------------
# Check whether a token column contain only list values
# ----------------------------

def check_list_columns(
    df: pd.DataFrame,
    col_to_check: list = ['tokens', 'tokens_no_stop', 'final_tokens']
):
    for col in col_to_check:
        if col not in df.columns:
            print(f"[ERROR] Column missing: {col}")
            continue

        is_list = df[col].apply(lambda x: isinstance(x, list))
        n_bad = (~is_list).sum()

        if n_bad == 0:
            print(f"[OK] {col}: all {len(df)} rows are lists")
        else:
            print(f"[FAIL] {col}: {n_bad}/{len(df)} rows are NOT lists")


# ----------------------------
# Print NaN summary table
# ----------------------------

def print_nan_columns(df: pd.DataFrame) -> None:
    """
    Print columns that contain NaN values, with counts and proportions.
    """
    if not isinstance(df, pd.DataFrame):
        raise TypeError("Input must be a pandas DataFrame")

    nan_summary = (
        df.isna()
          .sum()
          .to_frame("nan_count")
          .assign(
              nan_ratio=lambda x: x["nan_count"] / len(df)
          )
          .query("nan_count > 0")
          .sort_values("nan_count", ascending=False)
    )

    if nan_summary.empty:
        print("No NaN values found in any column.")
        return

    print("Columns containing NaN values:")
    print(nan_summary)

# ----------------------------
# Check whether columns contain string
# ----------------------------

def inspect_string_columns(
    df: pd.DataFrame,
    cols_to_check: List[str],
) -> None:
    """
    Inspect columns and report only those that contain string values.
    """

    for col in cols_to_check:
        if col not in df.columns:
            continue

        values = df[col].dropna().unique()
        str_values = sorted({v for v in values if isinstance(v, str)})

        if not str_values:
            continue

        print(f"\n=== Column: {col} ===")