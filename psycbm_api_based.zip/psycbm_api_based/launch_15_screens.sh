#!/usr/bin/env bash
set -euo pipefail

CONFIG=${1:-configs/api_concept_extraction.yaml}
NUM_SPLITS=${2:-15}
RUN_ID=${RUN_ID:-api_$(date +%Y%m%d_%H%M%S)}
PROJECT_DIR=$(cd "$(dirname "$0")" && pwd)
CONDA_ENV=${CONDA_ENV:-concepts}

mkdir -p "${PROJECT_DIR}/logs"

echo "Launching ${NUM_SPLITS} screen sessions"
echo "Project: ${PROJECT_DIR}"
echo "Config: ${CONFIG}"
echo "Run ID prefix: ${RUN_ID}"
echo "Conda env: ${CONDA_ENV}"

for i in $(seq 0 $((NUM_SPLITS - 1))); do
  SESSION="concepts_api_${i}"
  SPLIT_RUN_ID="${RUN_ID}_split$(printf '%02d' "$i")"
  LOG_FILE="logs/${SPLIT_RUN_ID}.log"

  if screen -list | grep -q "\.${SESSION}[[:space:]]"; then
    echo "Session ${SESSION} already exists; skipping."
    continue
  fi

  screen -dmS "${SESSION}" bash -lc "
    set -euo pipefail
    cd '${PROJECT_DIR}'
    conda activate '${CONDA_ENV}'
    export RUN_ID='${SPLIT_RUN_ID}'
    bash run_extraction.sh '${CONFIG}' '${i}' '${NUM_SPLITS}' 2>&1 | tee '${LOG_FILE}'
  "
  echo "Started ${SESSION}: split ${i}/${NUM_SPLITS}, log=${LOG_FILE}"
done

echo "Use: screen -ls"
echo "Attach example: screen -r concepts_api_0"
