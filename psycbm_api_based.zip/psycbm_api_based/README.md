# API-Based Concept Extraction Project

This project extracts concept variables from social-media suicide-risk posts using an OpenAI-compatible chat-completions API.

## Key design

- API-only execution.
- No model weights are loaded by this project.
- API URL, API key, and model name are configured in YAML.
- The input CSV can be split into 15 approximately equal shards.
- `launch_15_screens.sh` opens 15 independent `screen` sessions and runs one shard per session.
- Faster inference settings are used by default:
  - compact one-line JSON output
  - all 84 concepts in one request for normal posts
  - long posts split into 2 concept groups
  - concurrent API requests within each process

## Configure API

Edit:

```bash
configs/api_concept_extraction.yaml
```

Important fields:

```yaml
api:
  base_url: "https://YOUR_API_HOST/v1"
  api_key: "PASTE_YOUR_API_KEY_HERE"
  api_key_env: ""
  model: "YOUR_MODEL_NAME"
  concurrent_requests: 8
```

You can either paste the key into `api_key`, or keep it out of the file and use an environment variable:

```yaml
api:
  api_key: ""
  api_key_env: "MY_API_KEY"
```

Then run:

```bash
export MY_API_KEY="..."
```

## Run one small test

```bash
cd /mnt/disk1/wbjtu/tzbjtu/somental/psycbm_api_based
conda activate concepts

# optional: set sample_size: 20 in configs/api_concept_extraction.yaml first
bash run_extraction.sh configs/api_concept_extraction.yaml
```

## Run 15 parallel splits

```bash
cd /mnt/disk1/wbjtu/tzbjtu/somental/psycbm_api_based
conda activate concepts

bash launch_15_screens.sh configs/api_concept_extraction.yaml 15
```

Monitor:

```bash
screen -ls
screen -r concepts_api_0
```

Logs:

```bash
tail -f logs/api_*.log
```

## Output structure

Each split creates its own timestamped output folder:

```text
outputs/qwen36_concept_sft_api__api_YYYYMMDD_HHMMSS_split00/
├── prepared/input_prepared.csv
├── concept_groups_used.json
├── raw_generations/raw_generations.jsonl
├── validated/validated_long.jsonl
├── matrices/concept_strength_matrix.csv
├── matrices/concept_evidence_matrix.csv
└── reports/*.csv
```

Strength coding in `concept_strength_matrix.csv`:

```text
0 = absent
1 = present
-1 = not_sure
```

## Notes

The canonical concept definitions are in:

```text
concepts/final_concepts.yaml
```

The extraction prompt is in:

```text
prompts/extraction_prompt.yaml
```
