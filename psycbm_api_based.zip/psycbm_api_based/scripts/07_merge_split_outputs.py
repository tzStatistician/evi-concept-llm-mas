from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--outputs-root', default='outputs')
    parser.add_argument('--run-prefix', required=True, help='Example: qwen36_concept_sft_api__api_20260516_220000')
    parser.add_argument('--out-dir', default=None)
    args = parser.parse_args()

    root = Path(args.outputs_root)
    run_dirs = sorted([p for p in root.glob(args.run_prefix + '_split*') if p.is_dir()])
    if not run_dirs:
        raise FileNotFoundError(f'No split output dirs found under {root} with prefix {args.run_prefix}_split*')

    out_dir = Path(args.out_dir) if args.out_dir else root / (args.run_prefix + '_merged')
    out_dir.mkdir(parents=True, exist_ok=True)

    targets = [
        ('matrices/concept_strength_matrix.csv', 'concept_strength_matrix.csv'),
        ('matrices/concept_evidence_matrix.csv', 'concept_evidence_matrix.csv'),
        ('matrices/concept_not_sure_matrix.csv', 'concept_not_sure_matrix.csv'),
        ('validated/validated_long.jsonl', 'validated_long.jsonl'),
        ('raw_generations/raw_generations.jsonl', 'raw_generations.jsonl'),
    ]

    for rel, name in targets:
        files = [d / rel for d in run_dirs if (d / rel).exists()]
        if not files:
            print(f'Skip missing target: {rel}')
            continue
        dest = out_dir / name
        if rel.endswith('.csv'):
            parts = [pd.read_csv(f) for f in files]
            pd.concat(parts, ignore_index=True).to_csv(dest, index=False)
        else:
            with open(dest, 'w', encoding='utf-8') as w:
                for f in files:
                    with open(f, 'r', encoding='utf-8') as r:
                        for line in r:
                            w.write(line)
        print(f'Merged {len(files)} files -> {dest}')


if __name__ == '__main__':
    main()
