from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pandas as pd
from tqdm import tqdm

from utils.api_client import call_chat_completion
from utils.config import load_config_and_paths, load_yaml, parse_common_args, resolve_path
from utils.io_utils import ensure_dir, append_jsonl
from utils.prompt_builder import build_chat_messages


def load_groups(run_dir: Path):
    with open(run_dir / "concept_groups_used.json", "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    args = parse_common_args()
    cfg, root, run_dir = load_config_and_paths(args.config, args.run_id)

    prepared_csv = run_dir / "prepared/input_prepared.csv"
    if not prepared_csv.exists():
        raise FileNotFoundError(
            f"Prepared CSV not found: {prepared_csv}\n"
            "Run scripts/01_prepare_data.py first."
        )

    df = pd.read_csv(prepared_csv)
    if args.limit is not None:
        df = df.head(args.limit).copy()
    if df.empty:
        raise ValueError("Prepared data is empty. Nothing to extract.")

    prompt_cfg = load_yaml(resolve_path(root, cfg["prompt"]["prompt_file"]))
    groups_payload = load_groups(run_dir)
    normal_groups = groups_payload["normal_groups"]
    long_groups = groups_payload["long_groups"]

    threshold = int(cfg["concepts"]["long_post_word_threshold"])
    text_col = cfg["data"]["text_col"]

    required_cols = {"post_id", text_col, "word_count"}
    missing_cols = required_cols - set(df.columns)
    if missing_cols:
        raise ValueError(
            f"Missing required prepared-data columns: {sorted(missing_cols)}\n"
            f"Current columns: {df.columns.tolist()}"
        )

    raw_dir = ensure_dir(run_dir / "raw_generations")
    out_jsonl = raw_dir / "raw_generations.jsonl"
    if out_jsonl.exists():
        out_jsonl.unlink()

    concurrent_requests = int(cfg["api"].get("concurrent_requests", 8))
    save_every = int(cfg["runtime"].get("save_every", 200))

    print("API extraction mode")
    print(f"Run dir: {run_dir}")
    print(f"API base_url: {cfg['api'].get('base_url')}")
    print(f"API model: {cfg['api'].get('model')}")
    print(f"Concurrent requests in this process: {concurrent_requests}")

    tasks = []
    for row in df.itertuples(index=False):
        rowd = row._asdict()
        post_id = str(rowd["post_id"])
        post_text = "" if pd.isna(rowd[text_col]) else str(rowd[text_col])
        word_count = int(rowd.get("word_count", 0))
        groups = long_groups if word_count > threshold else normal_groups
        group_type = "long" if word_count > threshold else "normal"

        for g in groups:
            messages = build_chat_messages(
                post_id=post_id,
                post_text=post_text,
                concepts=g["concepts"],
                prompt_cfg=prompt_cfg,
            )
            meta = {
                "post_id": post_id,
                "group_id": g["group_id"],
                "group_type": group_type,
                "concept_ids": g["concept_ids"],
                "model_name": cfg["api"]["model"],
                "word_count": word_count,
            }
            tasks.append((messages, meta))

    print(f"Total API requests for this split/run: {len(tasks)}")

    def worker(item):
        messages, meta = item
        try:
            text, usage = call_chat_completion(cfg, messages)
            return {
                **meta,
                "raw_response": text,
                "status": "ok",
                "error": None,
                "usage": usage,
            }
        except Exception as e:
            return {
                **meta,
                "raw_response": "",
                "status": "error",
                "error": repr(e),
                "usage": {},
            }

    buffer = []
    done = 0
    with ThreadPoolExecutor(max_workers=concurrent_requests) as ex:
        futures = [ex.submit(worker, t) for t in tasks]
        for fut in tqdm(as_completed(futures), total=len(futures), desc="API extraction"):
            buffer.append(fut.result())
            done += 1
            if len(buffer) >= save_every:
                append_jsonl(buffer, out_jsonl)
                buffer = []
    if buffer:
        append_jsonl(buffer, out_jsonl)

    print(f"Saved raw generations: {out_jsonl}")
    print(f"Total requests finished: {done}")


if __name__ == "__main__":
    main()
