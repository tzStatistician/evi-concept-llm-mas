from __future__ import annotations

import json

import pandas as pd

from utils.config import load_config_and_paths, parse_common_args
from utils.io_utils import ensure_dir, read_jsonl


def code_strength(x):
    if x == 1 or str(x) == '1': return 1
    if x == 0 or str(x) == '0': return 0
    return -1


def main():
    args = parse_common_args()
    cfg, root, run_dir = load_config_and_paths(args.config, args.run_id)
    report_dir = ensure_dir(run_dir / 'reports')
    vals = pd.DataFrame(list(read_jsonl(run_dir / 'validated/validated_long.jsonl')))
    if vals.empty:
        raise RuntimeError('No validated rows found.')
    vals['strength_code'] = vals['strength'].apply(code_strength)

    summary = pd.DataFrame([{
        'run_name': cfg['run']['run_name'],
        'model_name': cfg['model']['model_name'],
        'n_posts': vals['post_id'].nunique(),
        'n_concepts': vals['concept_id'].nunique(),
        'n_cells': len(vals),
        'positive_rate': (vals['strength_code'] == 1).mean(),
        'not_sure_rate': (vals['strength_code'] == -1).mean(),
        'evidence_invalid_rate': (~vals['evidence_valid'].astype(bool)).mean(),
        'parse_invalid_rate': (~vals['parse_valid'].astype(bool)).mean(),
        'schema_invalid_rate': (~vals['schema_valid'].astype(bool)).mean(),
    }])
    summary.to_csv(report_dir / 'extraction_summary.csv', index=False)

    by_concept = vals.groupby('concept_id').agg(
        n=('post_id', 'count'),
        positive_rate=('strength_code', lambda s: (s == 1).mean()),
        absent_rate=('strength_code', lambda s: (s == 0).mean()),
        not_sure_rate=('strength_code', lambda s: (s == -1).mean()),
        invalid_evidence_rate=('evidence_valid', lambda s: (~s.astype(bool)).mean()),
    ).reset_index()
    by_concept.to_csv(report_dir / 'concept_rates.csv', index=False)

    with open(run_dir / 'validated/validation_report.json', 'r', encoding='utf-8') as f:
        val_report = json.load(f)
    pd.DataFrame([val_report]).to_csv(report_dir / 'evidence_validation_report.csv', index=False)
    print(f'Saved reports to: {report_dir}')


if __name__ == '__main__':
    main()
