from __future__ import annotations

import pandas as pd

from utils.config import load_config_and_paths, parse_common_args
from utils.io_utils import ensure_dir, read_jsonl


def code_strength(x):
    if x == 1 or str(x) == '1':
        return 1
    if x == 0 or str(x) == '0':
        return 0
    return -1


def main():
    args = parse_common_args()
    cfg, root, run_dir = load_config_and_paths(args.config, args.run_id)
    base = pd.read_csv(run_dir / 'prepared/input_prepared.csv')
    vals = pd.DataFrame(list(read_jsonl(run_dir / 'validated/validated_long.jsonl')))
    if vals.empty:
        raise RuntimeError('No validated rows found.')

    vals['strength_code'] = vals['strength'].apply(code_strength)
    strength = vals.pivot_table(index='post_id', columns='concept_id', values='strength_code', aggfunc='first').reset_index()
    evidence = vals.pivot_table(index='post_id', columns='concept_id', values='evidence_spans', aggfunc='first').reset_index()
    evidence = evidence.rename(columns={c: f'{c}__evidence' for c in evidence.columns if c != 'post_id'})
    not_sure = vals.assign(not_sure=lambda d: (d['strength'].astype(str) == 'not_sure').astype(int))
    not_sure = not_sure.pivot_table(index='post_id', columns='concept_id', values='not_sure', aggfunc='first').reset_index()
    not_sure = not_sure.rename(columns={c: f'{c}__not_sure' for c in not_sure.columns if c != 'post_id'})

    meta_cols = ['post_id']
    for c in [cfg['data'].get('user_col'), cfg['data'].get('text_col'), cfg['data'].get('label_col'), cfg['data'].get('time_col'), 'word_count']:
        if c and c in base.columns and c not in meta_cols:
            meta_cols.append(c)

    out_dir = ensure_dir(run_dir / 'matrices')
    base_meta = base[meta_cols].copy()
    base_meta['post_id'] = base_meta['post_id'].astype(str)

    strength_mat = base_meta.merge(strength, on='post_id', how='left')
    evidence_mat = base_meta[['post_id']].merge(evidence, on='post_id', how='left')
    not_sure_mat = base_meta[['post_id']].merge(not_sure, on='post_id', how='left')

    strength_mat.to_csv(out_dir / 'concept_strength_matrix.csv', index=False)
    evidence_mat.to_csv(out_dir / 'concept_evidence_matrix.csv', index=False)
    not_sure_mat.to_csv(out_dir / 'concept_not_sure_matrix.csv', index=False)
    print(f'Saved matrices to: {out_dir}')


if __name__ == '__main__':
    main()
