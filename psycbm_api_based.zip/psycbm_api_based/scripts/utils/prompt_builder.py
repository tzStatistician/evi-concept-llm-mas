from __future__ import annotations

from typing import Dict, List


def build_concept_block(concepts: List[Dict], prompt_cfg: Dict) -> str:
    tmpl = prompt_cfg['concept_template']
    blocks = []
    for i, c in enumerate(concepts, start=1):
        blocks.append(tmpl.format(
            idx=i,
            concept_id=c['concept_id'],
            definition=c['definition'],
            mark_1=c.get('mark_1', ''),
            mark_0=c.get('mark_0', ''),
            mark_not_sure=c.get('mark_not_sure', ''),
            exclude=c.get('exclude', ''),
        ).rstrip())
    return '\n\n'.join(blocks)


def build_json_schema(post_id: str, concept_ids: List[str], prompt_cfg: Dict) -> str:
    line_tmpl = prompt_cfg['concept_schema_line_template']
    lines = []
    for i, cid in enumerate(concept_ids):
        line = line_tmpl.format(concept_id=cid)
        if i < len(concept_ids) - 1:
            line += ','
        lines.append(line)
    return prompt_cfg['json_schema_template'].format(
        post_id=post_id,
        concept_schema_lines=''.join(lines)
    ).rstrip()


def build_user_prompt(post_id: str, post_text: str, concepts: List[Dict], prompt_cfg: Dict) -> str:
    return prompt_cfg['user_prompt_template'].format(
        post_id=post_id,
        post_text=post_text,
        concept_block=build_concept_block(concepts, prompt_cfg),
        json_schema=build_json_schema(post_id, [c['concept_id'] for c in concepts], prompt_cfg),
    )


def build_chat_messages(post_id: str, post_text: str, concepts: List[Dict], prompt_cfg: Dict):
    return [
        {'role': 'system', 'content': prompt_cfg['system_prompt']},
        {'role': 'user', 'content': build_user_prompt(post_id, post_text, concepts, prompt_cfg)},
    ]
