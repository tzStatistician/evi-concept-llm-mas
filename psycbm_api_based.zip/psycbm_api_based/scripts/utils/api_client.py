from __future__ import annotations

import os
import time
from typing import Any, Dict, List, Tuple

import requests


def get_api_key(cfg: Dict[str, Any]) -> str:
    api_cfg = cfg["api"]
    env_name = str(api_cfg.get("api_key_env") or "").strip()
    if env_name:
        value = os.environ.get(env_name)
        if value:
            return value
    key = str(api_cfg.get("api_key") or "").strip()
    if not key or key == "PASTE_YOUR_API_KEY_HERE":
        raise ValueError(
            "API key is missing. Set api.api_key in the YAML, or set api.api_key_env "
            "to an environment variable containing the key."
        )
    return key


def build_url(cfg: Dict[str, Any]) -> str:
    api_cfg = cfg["api"]
    base = str(api_cfg["base_url"]).rstrip("/")
    path = str(api_cfg.get("chat_completions_path", "/chat/completions"))
    if not path.startswith("/"):
        path = "/" + path
    return base + path


def build_payload(cfg: Dict[str, Any], messages: List[Dict[str, str]]) -> Dict[str, Any]:
    gen = cfg["generation"]
    payload: Dict[str, Any] = {
        "model": cfg["api"]["model"],
        "messages": messages,
        "temperature": float(gen.get("temperature", 0.0)),
        "top_p": float(gen.get("top_p", 1.0)),
        "max_tokens": int(gen.get("max_tokens", 3072)),
    }

    # Optional provider-specific fields, useful for Qwen-compatible APIs.
    extra_body = gen.get("extra_body") or {}
    if isinstance(extra_body, dict):
        payload.update(extra_body)

    return payload


def call_chat_completion(cfg: Dict[str, Any], messages: List[Dict[str, str]]) -> Tuple[str, Dict[str, Any]]:
    api_cfg = cfg["api"]
    url = build_url(cfg)
    api_key = get_api_key(cfg)
    timeout = int(api_cfg.get("timeout", 180))
    max_retries = int(api_cfg.get("max_retries", 3))
    retry_sleep = float(api_cfg.get("retry_sleep_seconds", 2))

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = build_payload(cfg, messages)

    last_error = None
    for attempt in range(max_retries + 1):
        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=timeout)
            if resp.status_code in {429, 500, 502, 503, 504}:
                last_error = f"HTTP {resp.status_code}: {resp.text[:500]}"
                if attempt < max_retries:
                    time.sleep(retry_sleep * (attempt + 1))
                    continue
            resp.raise_for_status()
            data = resp.json()
            content = data["choices"][0]["message"].get("content", "")
            usage = data.get("usage", {})
            return content, usage
        except Exception as e:
            last_error = repr(e)
            if attempt < max_retries:
                time.sleep(retry_sleep * (attempt + 1))
                continue
    raise RuntimeError(f"API request failed after retries: {last_error}")
