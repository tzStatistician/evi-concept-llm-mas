from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Tuple


def extract_json_object(text: str) -> Tuple[Dict[str, Any] | None, str | None]:
    if text is None:
        return None, 'empty_response'
    t = text.strip()
    try:
        return json.loads(t), None
    except Exception:
        pass
    start = t.find('{')
    end = t.rfind('}')
    if start == -1 or end == -1 or end <= start:
        return None, 'no_json_object_found'
    candidate = t[start:end + 1]
    try:
        return json.loads(candidate), None
    except Exception as e:
        return None, f'json_parse_error: {e}'


def normalize_strength(x):
    if x in [0, 1, 'not_sure']:
        return x, True
    if isinstance(x, str):
        xs = x.strip().lower()
        if xs == '0': return 0, True
        if xs == '1': return 1, True
        if xs in ['not sure', 'not_sure', 'unsure', 'uncertain']:
            return 'not_sure', True
    return 'not_sure', False


def split_spans(evidence: Any) -> List[str]:
    if evidence is None:
        return []
    if isinstance(evidence, list):
        spans = []
        for x in evidence:
            spans.extend(split_spans(x))
        return spans
    evidence = str(evidence)
    if evidence.strip() == '':
        return []
    return [s.strip() for s in evidence.split(';') if s.strip()]


def evidence_is_valid(evidence: Any, post_text: str, strength: Any) -> bool:
    spans = split_spans(evidence)
    if strength == 0:
        return len(spans) == 0
    if strength == 1 and len(spans) == 0:
        return False
    for s in spans:
        if s not in post_text:
            return False
    return True


def validate_one_response(raw_response: str, post_id: str, post_text: str, expected_concept_ids: List[str], model_name: str, group_id: str, clear_invalid_evidence: bool = True):
    obj, parse_error = extract_json_object(raw_response)
    rows = []
    errors = []
    if obj is None:
        errors.append({'post_id': post_id, 'group_id': group_id, 'error_type': 'parse_error', 'error': parse_error, 'raw_response': raw_response})
        for cid in expected_concept_ids:
            rows.append({'post_id': post_id, 'group_id': group_id, 'concept_id': cid, 'strength': 'not_sure', 'evidence_spans': '', 'evidence_valid': False, 'parse_valid': False, 'schema_valid': False, 'model_name': model_name})
        return rows, errors

    concepts = obj.get('concepts', {}) if isinstance(obj, dict) else {}
    schema_valid = isinstance(concepts, dict)
    if not schema_valid:
        errors.append({'post_id': post_id, 'group_id': group_id, 'error_type': 'schema_error', 'error': 'missing_or_invalid_concepts_object', 'raw_response': raw_response})
        concepts = {}

    for cid in expected_concept_ids:
        item = concepts.get(cid, None)
        if item is None:
            errors.append({'post_id': post_id, 'group_id': group_id, 'concept_id': cid, 'error_type': 'missing_concept_key', 'error': cid})
            strength, evidence = 'not_sure', ''
            valid_strength = False
        elif isinstance(item, list) and len(item) >= 2:
            strength, valid_strength = normalize_strength(item[0])
            evidence = str(item[1]) if item[1] is not None else ''
        elif isinstance(item, dict):
            strength, valid_strength = normalize_strength(item.get('strength', 'not_sure'))
            evidence = str(item.get('evidence_spans', '') or '')
        else:
            strength, evidence = 'not_sure', ''
            valid_strength = False

        if not valid_strength:
            errors.append({'post_id': post_id, 'group_id': group_id, 'concept_id': cid, 'error_type': 'invalid_strength', 'error': str(item)})

        ev_valid = evidence_is_valid(evidence, post_text, strength)
        if not ev_valid:
            errors.append({'post_id': post_id, 'group_id': group_id, 'concept_id': cid, 'error_type': 'invalid_evidence', 'error': evidence})
            if clear_invalid_evidence:
                evidence = ''

        rows.append({
            'post_id': post_id,
            'group_id': group_id,
            'concept_id': cid,
            'strength': strength,
            'evidence_spans': evidence,
            'evidence_valid': ev_valid,
            'parse_valid': True,
            'schema_valid': schema_valid,
            'model_name': model_name,
        })
    return rows, errors
