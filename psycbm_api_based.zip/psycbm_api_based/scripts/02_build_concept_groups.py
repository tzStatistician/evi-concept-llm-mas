from __future__ import annotations

from utils.config import load_config_and_paths, load_yaml, parse_common_args, resolve_path, write_json


def chunk(items, size):
    return [items[i:i+size] for i in range(0, len(items), size)]


def make_groups(concepts, size, prefix):
    groups = []
    for i, part in enumerate(chunk(concepts, size)):
        groups.append({
            'group_id': f'{prefix}_{i:03d}',
            'concept_ids': [c['concept_id'] for c in part],
            'concepts': part,
        })
    return groups


def main():
    args = parse_common_args()
    cfg, root, run_dir = load_config_and_paths(args.config, args.run_id)
    concept_path = resolve_path(root, cfg['concepts']['concept_file'])
    concept_doc = load_yaml(concept_path)
    concepts = concept_doc['concepts']

    normal_size = int(cfg['concepts']['normal_group_size'])
    long_size = int(cfg['concepts']['long_post_group_size'])

    payload = {
        'metadata': {
            'n_concepts': len(concepts),
            'normal_group_size': normal_size,
            'long_post_group_size': long_size,
            'long_post_word_threshold': int(cfg['concepts']['long_post_word_threshold']),
        },
        'normal_groups': make_groups(concepts, normal_size, 'normal_group'),
        'long_groups': make_groups(concepts, long_size, 'long_group'),
    }
    out = run_dir / 'concept_groups_used.json'
    write_json(payload, out)
    print(f'Saved concept groups: {out}')


if __name__ == '__main__':
    main()
