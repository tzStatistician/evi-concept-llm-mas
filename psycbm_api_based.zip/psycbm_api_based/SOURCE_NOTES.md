# Source notes for concept definitions

This project uses concise operational concept definitions for model-based extraction. They are designed to be faithful to source frameworks while remaining simple enough for reliable LLM extraction.

## 3ST BioPortal ontology

Source: NCBO BioPortal `THREE-ST` ontology.

The ontology description states that its classes map onto the 3-Step Theory of suicide factors: psychological pain, hopelessness, connectedness, and capacity for suicide. It also states that these classes are intended for NLP extraction from clinical notes. BioPortal reports that the ontology classes have no per-class textual definitions, so this project uses the class names as the canonical source and writes short operational definitions for extraction.

## C-SSRS

Sources: C-SSRS Lifetime/Recent clinical scale and Basic Clinical Scoring Guide for the C-SSRS.

The C-SSRS materials define five increasing levels of suicidal ideation, intensity features including frequency, duration, controllability, deterrents, and reasons for ideation, behavior categories including actual, interrupted, aborted/self-interrupted attempts and preparatory acts, and actual/potential lethality ratings. This project converts selected C-SSRS items into binary extraction variables with evidence-span requirements.

## Reddit C-SSRS PLOS ONE framework

Source: Gaur et al. 2021, `Characterization of time-variant and time-invariant assessment of suicidality on Reddit using C-SSRS`, PLOS ONE.

The paper studies suicide-risk severity and temporality from Reddit data using C-SSRS-based annotation, with time-variant and time-invariant user-level modeling. It emphasizes temporality, user-level context, supportive users/posts, high-risk language, throwaway accounts, and cross-post drift/fluctuation. This project converts these ideas into temporal and social-media context variables.
