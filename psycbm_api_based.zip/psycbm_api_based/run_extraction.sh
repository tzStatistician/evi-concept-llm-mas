#!/usr/bin/env bash
set -euo pipefail

CONFIG=${1:-configs/api_concept_extraction.yaml}
RUN_ID=${RUN_ID:-$(python - <<'PY'
from datetime import datetime
print(datetime.now().strftime('%Y%m%d_%H%M%S'))
PY
)}

# Optional split args. Usage:
#   bash run_extraction.sh CONFIG SPLIT_INDEX NUM_SPLITS
SPLIT_INDEX=${2:-}
NUM_SPLITS=${3:-}
EXTRA_ARGS=()
if [[ -n "${SPLIT_INDEX}" || -n "${NUM_SPLITS}" ]]; then
  if [[ -z "${SPLIT_INDEX}" || -z "${NUM_SPLITS}" ]]; then
    echo "Both SPLIT_INDEX and NUM_SPLITS must be provided." >&2
    exit 1
  fi
  EXTRA_ARGS+=(--split-index "${SPLIT_INDEX}" --num-splits "${NUM_SPLITS}")
fi

mkdir -p logs

echo "Using config: ${CONFIG}"
echo "Run ID: ${RUN_ID}"
if [[ -n "${SPLIT_INDEX}" ]]; then
  echo "Split: ${SPLIT_INDEX}/${NUM_SPLITS}"
fi

python scripts/01_prepare_data.py --config "${CONFIG}" --run_id "${RUN_ID}" "${EXTRA_ARGS[@]}"
python scripts/02_build_concept_groups.py --config "${CONFIG}" --run_id "${RUN_ID}"
python scripts/03_run_extraction.py --config "${CONFIG}" --run_id "${RUN_ID}"
python scripts/04_validate_outputs.py --config "${CONFIG}" --run_id "${RUN_ID}"
python scripts/05_build_matrix.py --config "${CONFIG}" --run_id "${RUN_ID}"
python scripts/06_make_report.py --config "${CONFIG}" --run_id "${RUN_ID}"

echo "Done."
