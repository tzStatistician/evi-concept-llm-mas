# Qwen CBM True 2-Phase Training

This project implements a **true 2-phase** concept bottleneck workflow.

## Phase 1: Concept-only training

Train the text → concept model only:

$$
x \rightarrow \hat c
$$

using only concept regression loss:

$$
\mathcal{L}_{\text{phase1}} = \mathcal{L}_{\text{concept}}
$$

No label loss is used in phase 1.

Outputs include:
- predicted concepts for train / val / test
- concept metrics
- logits are **not** used because there is no label head in phase 1
- LoRA adapter + concept head weights
- metadata and label mapping for downstream phase 2

## Phase 2: Linear / logistic final head

Freeze the concept model outputs and fit a post-hoc linear classifier:

$$
\hat c \rightarrow y
$$

The provided phase-2 script runs the four linear-head trials:
- balanced L2
- balanced L1
- balanced elastic-net
- manual elastic-net

Selection is based on validation macro-F1.

## What is different from the earlier inspection pipeline?

Earlier, the predicted concepts were produced by an end-to-end model that already used label loss.  
This project removes that issue by training the concept predictor in a **pure concept-only** phase.

## Storage policy

This project tries to be storage-efficient:

- arrays → `.npy`
- metrics / configs → `.json`
- coefficient tables → `.csv`

It avoids saving the same artifact in both `.csv` and `.npy` unless there is a clear reason.

## Main scripts

- `phase1_train_concepts.py`
- `phase2_run_logreg_trials.py`

## Typical workflow

### Phase 1
```bash
accelerate launch --num_processes 4 --mixed_precision bf16 phase1_train_concepts.py \
  --csv_path /path/to/data.csv \
  --text_col text \
  --label_col sentiment \
  --model_name_or_path /path/to/Qwen3.5-9B \
  --output_dir /path/to/output_phase1 \
  --load_in_4bit \
  --bnb_4bit_use_double_quant \
  --gradient_checkpointing \
  --pooling mean \
  --concept_head_type linear \
  --num_epochs 3 \
  --train_batch_size 1 \
  --eval_batch_size 2 \
  --gradient_accumulation_steps 16 \
  --lr_lora 2e-4 \
  --lr_heads 2e-4 \
  --weight_decay 0.01 \
  --max_length 512 \
  --lora_r 16 \
  --lora_alpha 32 \
  --lora_dropout 0.05
```

### Phase 2
```bash
python phase2_run_logreg_trials.py \
  --run_dir /path/to/output_phase1 \
  --output_dir /path/to/output_phase1/logreg_trials \
  --manual_class_weights '{"Indicator":1.0,"Ideation":0.9,"Behavior":1.8,"Attempt":3.0}'
```
