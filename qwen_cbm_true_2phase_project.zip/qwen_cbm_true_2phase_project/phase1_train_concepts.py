from __future__ import annotations

import argparse
import json
import math
import os
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from accelerate import Accelerator
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from torch.optim import AdamW
from torch.utils.data import DataLoader, Dataset
from tqdm.auto import tqdm
from transformers import (
    AutoConfig,
    AutoModel,
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    get_linear_schedule_with_warmup,
)


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def find_backbone_module(model: nn.Module) -> nn.Module:
    candidates = ["model", "language_model", "transformer", "backbone"]
    for name in candidates:
        if hasattr(model, name):
            return getattr(model, name)
    return model


class TextConceptDataset(Dataset):
    def __init__(
        self,
        df: pd.DataFrame,
        tokenizer,
        text_col: str,
        concept_cols: List[str],
        label_col: str,
        max_length: int,
    ):
        self.df = df.reset_index(drop=True)
        self.tokenizer = tokenizer
        self.text_col = text_col
        self.concept_cols = concept_cols
        self.label_col = label_col
        self.max_length = max_length

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        text = str(row[self.text_col])
        enc = self.tokenizer(
            text,
            truncation=True,
            max_length=self.max_length,
            padding=False,
            return_tensors=None,
        )
        item = {
            "input_ids": enc["input_ids"],
            "attention_mask": enc["attention_mask"],
            "concept_targets": row[self.concept_cols].astype(float).values.astype(np.float32),
            "labels": str(row[self.label_col]),
        }
        return item


class Collator:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def __call__(self, batch):
        input_features = [{"input_ids": x["input_ids"], "attention_mask": x["attention_mask"]} for x in batch]
        padded = self.tokenizer.pad(input_features, padding=True, return_tensors="pt")
        concept_targets = torch.tensor(np.stack([x["concept_targets"] for x in batch]), dtype=torch.float32)
        labels = [x["labels"] for x in batch]
        padded["concept_targets"] = concept_targets
        padded["labels"] = labels
        return padded


class LinearConceptHead(nn.Module):
    def __init__(self, hidden_size: int, num_concepts: int):
        super().__init__()
        self.proj = nn.Linear(hidden_size, num_concepts)

    def forward(self, x):
        return torch.sigmoid(self.proj(x))


class MLPConceptHead(nn.Module):
    def __init__(self, hidden_size: int, num_concepts: int, concept_hidden_dim: int = 512, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(hidden_size, concept_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(concept_hidden_dim, num_concepts),
        )

    def forward(self, x):
        return torch.sigmoid(self.net(x))


class QwenConceptModel(nn.Module):
    def __init__(self, backbone: nn.Module, hidden_size: int, num_concepts: int, pooling: str = "mean",
                 concept_head_type: str = "linear", concept_hidden_dim: int = 512, dropout: float = 0.1):
        super().__init__()
        self.backbone = backbone
        self.pooling = pooling
        if concept_head_type == "linear":
            self.concept_head = LinearConceptHead(hidden_size, num_concepts)
        elif concept_head_type == "mlp":
            self.concept_head = MLPConceptHead(hidden_size, num_concepts, concept_hidden_dim, dropout)
        else:
            raise ValueError(f"Unsupported concept_head_type: {concept_head_type}")

    def pool_hidden(self, hidden_states: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        if self.pooling == "mean":
            mask = attention_mask.unsqueeze(-1).to(hidden_states.dtype)
            summed = (hidden_states * mask).sum(dim=1)
            denom = mask.sum(dim=1).clamp(min=1.0)
            return summed / denom
        elif self.pooling == "last_non_pad":
            lengths = attention_mask.sum(dim=1) - 1
            idx = lengths.clamp(min=0)
            batch_idx = torch.arange(hidden_states.size(0), device=hidden_states.device)
            return hidden_states[batch_idx, idx]
        else:
            raise ValueError(f"Unsupported pooling: {self.pooling}")

    def forward(self, input_ids, attention_mask):
        outputs = self.backbone(input_ids=input_ids, attention_mask=attention_mask, output_hidden_states=False, use_cache=False)
        hidden = outputs.last_hidden_state
        pooled = self.pool_hidden(hidden, attention_mask)
        pred_concepts = self.concept_head(pooled)
        return {"pred_concepts": pred_concepts}


def compute_concept_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    return {
        "concept_mse": float(mean_squared_error(y_true, y_pred)),
        "concept_mae": float(mean_absolute_error(y_true, y_pred)),
    }


def build_model(args, num_concepts: int):
    trust_remote_code = True

    quant_config = None
    if args.load_in_4bit:
        compute_dtype = {
            "bf16": torch.bfloat16,
            "fp16": torch.float16,
            "float16": torch.float16,
            "float32": torch.float32,
        }[args.bnb_4bit_compute_dtype]
        quant_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type=args.bnb_4bit_quant_type,
            bnb_4bit_use_double_quant=args.bnb_4bit_use_double_quant,
            bnb_4bit_compute_dtype=compute_dtype,
        )

    config = AutoConfig.from_pretrained(args.model_name_or_path, trust_remote_code=trust_remote_code)

    # Try causal LM wrapper first, then plain backbone
    model = None
    load_errors = []
    for cls in [AutoModelForCausalLM, AutoModel]:
        try:
            model = cls.from_pretrained(
                args.model_name_or_path,
                config=config,
                trust_remote_code=trust_remote_code,
                quantization_config=quant_config,
                low_cpu_mem_usage=True,
                torch_dtype=torch.bfloat16 if args.mixed_precision == "bf16" else torch.float16 if args.mixed_precision == "fp16" else None,
            )
            break
        except Exception as e:
            load_errors.append(f"{cls.__name__}: {repr(e)}")
    if model is None:
        raise RuntimeError("Failed to load model. Errors:\\n" + "\\n".join(load_errors))

    backbone = find_backbone_module(model)

    if args.load_in_4bit:
        backbone = prepare_model_for_kbit_training(backbone)

    if args.gradient_checkpointing and hasattr(backbone, "gradient_checkpointing_enable"):
        backbone.gradient_checkpointing_enable()

    lora_targets = [x.strip() for x in args.lora_target_modules.split(",") if x.strip()]
    lora_cfg = LoraConfig(
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        target_modules=lora_targets,
        lora_dropout=args.lora_dropout,
        bias="none",
        task_type="FEATURE_EXTRACTION",
    )
    backbone = get_peft_model(backbone, lora_cfg)

    hidden_size = None
    for attr in ["hidden_size", "d_model", "embed_dim"]:
        if hasattr(config, attr):
            hidden_size = getattr(config, attr)
            break
    if hidden_size is None:
        raise ValueError("Could not infer hidden size from model config.")

    full_model = QwenConceptModel(
        backbone=backbone,
        hidden_size=hidden_size,
        num_concepts=num_concepts,
        pooling=args.pooling,
        concept_head_type=args.concept_head_type,
        concept_hidden_dim=args.concept_hidden_dim,
        dropout=args.dropout,
    )
    return full_model, model


def save_phase1_predictions(path: Path, df: pd.DataFrame, true_labels, pred_labels, row_indices):
    out = pd.DataFrame({
        "row_idx": row_indices,
        "true_label": true_labels,
        "pred_label_placeholder": pred_labels,  # phase 1 has no trained final head; keep placeholder for phase 2 compatibility
    })
    out.to_csv(path, index=False)


def main():
    ap = argparse.ArgumentParser(description="Phase 1: concept-only training for Qwen CBM")
    ap.add_argument("--csv_path", type=str, required=True)
    ap.add_argument("--text_col", type=str, default="text")
    ap.add_argument("--label_col", type=str, default="sentiment")
    ap.add_argument("--concept_suffix", type=str, default="__calibrated")
    ap.add_argument("--output_dir", type=str, required=True)
    ap.add_argument("--train_size", type=float, default=0.8)
    ap.add_argument("--val_size", type=float, default=0.1)
    ap.add_argument("--test_size", type=float, default=0.1)
    ap.add_argument("--random_seed", type=int, default=42)

    ap.add_argument("--model_name_or_path", type=str, required=True)
    ap.add_argument("--max_length", type=int, default=512)
    ap.add_argument("--pooling", type=str, choices=["mean", "last_non_pad"], default="mean")
    ap.add_argument("--concept_head_type", type=str, choices=["linear", "mlp"], default="linear")
    ap.add_argument("--concept_hidden_dim", type=int, default=512)
    ap.add_argument("--dropout", type=float, default=0.1)

    ap.add_argument("--load_in_4bit", action="store_true")
    ap.add_argument("--lora_r", type=int, default=16)
    ap.add_argument("--lora_alpha", type=int, default=32)
    ap.add_argument("--lora_dropout", type=float, default=0.05)
    ap.add_argument("--lora_target_modules", type=str, default="q_proj,k_proj,v_proj,o_proj")
    ap.add_argument("--bnb_4bit_quant_type", type=str, default="nf4")
    ap.add_argument("--bnb_4bit_compute_dtype", type=str, default="bf16", choices=["bf16", "fp16", "float16", "float32"])
    ap.add_argument("--bnb_4bit_use_double_quant", action="store_true")

    ap.add_argument("--num_epochs", type=int, default=3)
    ap.add_argument("--train_batch_size", type=int, default=1)
    ap.add_argument("--eval_batch_size", type=int, default=2)
    ap.add_argument("--gradient_accumulation_steps", type=int, default=16)
    ap.add_argument("--lr_lora", type=float, default=2e-4)
    ap.add_argument("--lr_heads", type=float, default=2e-4)
    ap.add_argument("--weight_decay", type=float, default=0.01)
    ap.add_argument("--warmup_ratio", type=float, default=0.03)
    ap.add_argument("--max_grad_norm", type=float, default=1.0)
    ap.add_argument("--mixed_precision", type=str, choices=["no", "fp16", "bf16"], default="bf16")
    ap.add_argument("--gradient_checkpointing", action="store_true")
    ap.add_argument("--num_workers", type=int, default=2)

    args = ap.parse_args()

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    set_seed(args.random_seed)
    accelerator = Accelerator(mixed_precision=args.mixed_precision if args.mixed_precision != "no" else None)

    df = pd.read_csv(args.csv_path)
    concept_cols = [c for c in df.columns if c.endswith(args.concept_suffix)]
    if not concept_cols:
        raise ValueError(f"No concept columns found with suffix {args.concept_suffix}")

    label_encoder = LabelEncoder()
    y_all = label_encoder.fit_transform(df[args.label_col].astype(str).values)
    df = df.copy()
    df["__label_id__"] = y_all
    df["__row_idx__"] = np.arange(len(df))

    train_df, temp_df = train_test_split(
        df,
        test_size=(1.0 - args.train_size),
        random_state=args.random_seed,
        stratify=df["__label_id__"],
    )
    rel_test = args.test_size / (args.val_size + args.test_size)
    val_df, test_df = train_test_split(
        temp_df,
        test_size=rel_test,
        random_state=args.random_seed,
        stratify=temp_df["__label_id__"],
    )

    tokenizer = AutoTokenizer.from_pretrained(args.model_name_or_path, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    train_ds = TextConceptDataset(train_df, tokenizer, args.text_col, concept_cols, args.label_col, args.max_length)
    val_ds = TextConceptDataset(val_df, tokenizer, args.text_col, concept_cols, args.label_col, args.max_length)
    test_ds = TextConceptDataset(test_df, tokenizer, args.text_col, concept_cols, args.label_col, args.max_length)
    collator = Collator(tokenizer)

    train_loader = DataLoader(train_ds, batch_size=args.train_batch_size, shuffle=True, collate_fn=collator, num_workers=args.num_workers)
    val_loader = DataLoader(val_ds, batch_size=args.eval_batch_size, shuffle=False, collate_fn=collator, num_workers=args.num_workers)
    test_loader = DataLoader(test_ds, batch_size=args.eval_batch_size, shuffle=False, collate_fn=collator, num_workers=args.num_workers)

    model, base_model = build_model(args, len(concept_cols))

    # Two param groups
    head_params = list(model.concept_head.parameters())
    lora_params = [p for n, p in model.named_parameters() if p.requires_grad and all(p is not hp for hp in head_params)]

    optimizer = AdamW(
        [
            {"params": lora_params, "lr": args.lr_lora, "weight_decay": args.weight_decay},
            {"params": head_params, "lr": args.lr_heads, "weight_decay": args.weight_decay},
        ]
    )
    num_update_steps_per_epoch = math.ceil(len(train_loader) / args.gradient_accumulation_steps)
    max_train_steps = args.num_epochs * num_update_steps_per_epoch
    num_warmup_steps = int(args.warmup_ratio * max_train_steps)
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps, max_train_steps)

    model, optimizer, train_loader, val_loader, test_loader, scheduler = accelerator.prepare(
        model, optimizer, train_loader, val_loader, test_loader, scheduler
    )

    history = []
    best_val_mse = float("inf")
    best_state = None

    def run_eval(dataloader, split_name: str):
        model.eval()
        preds = []
        trues = []
        labels = []
        row_count = 0
        with torch.no_grad():
            for batch in dataloader:
                labels.extend(batch["labels"])
                outputs = model(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"])
                pred = outputs["pred_concepts"]
                true = batch["concept_targets"].to(pred.device)
                preds.append(accelerator.gather_for_metrics(pred).cpu().numpy())
                trues.append(accelerator.gather_for_metrics(true).cpu().numpy())
                row_count += len(batch["labels"])
        pred_arr = np.concatenate(preds, axis=0)
        true_arr = np.concatenate(trues, axis=0)
        metrics = compute_concept_metrics(true_arr, pred_arr)
        metrics["split"] = split_name
        return pred_arr, true_arr, labels, metrics

    for epoch in range(1, args.num_epochs + 1):
        model.train()
        losses = []
        progress = tqdm(train_loader, disable=not accelerator.is_local_main_process, desc=f"Epoch {epoch}/{args.num_epochs}")
        for step, batch in enumerate(progress, start=1):
            with accelerator.accumulate(model):
                outputs = model(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"])
                pred = outputs["pred_concepts"]
                true = batch["concept_targets"].to(pred.device)
                loss = F.mse_loss(pred, true)
                accelerator.backward(loss)
                if accelerator.sync_gradients:
                    accelerator.clip_grad_norm_(model.parameters(), args.max_grad_norm)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()

            losses.append(loss.detach().float().item())
            if accelerator.is_local_main_process:
                progress.set_postfix({"train_mse": f"{np.mean(losses):.5f}"})

        # Eval val
        val_pred, val_true, val_labels, val_metrics = run_eval(val_loader, "val")
        train_pred, train_true, train_labels, train_metrics = run_eval(train_loader, "train")

        history.append({
            "epoch": epoch,
            "train_mse": train_metrics["concept_mse"],
            "train_mae": train_metrics["concept_mae"],
            "val_mse": val_metrics["concept_mse"],
            "val_mae": val_metrics["concept_mae"],
        })

        if accelerator.is_main_process:
            with open(out_dir / f"phase1_metrics_val_epoch{epoch}.json", "w") as f:
                json.dump(val_metrics, f, indent=2)
            if val_metrics["concept_mse"] < best_val_mse:
                best_val_mse = val_metrics["concept_mse"]
                unwrapped = accelerator.unwrap_model(model)
                best_state = {
                    "concept_head": unwrapped.concept_head.state_dict(),
                    "epoch": epoch,
                    "best_val_mse": best_val_mse,
                }

    # Final eval on all splits
    train_pred, train_true, train_labels, train_metrics = run_eval(train_loader, "train")
    val_pred, val_true, val_labels, val_metrics = run_eval(val_loader, "val")
    test_pred, test_true, test_labels, test_metrics = run_eval(test_loader, "test")

    if accelerator.is_main_process:
        np.save(out_dir / "predicted_concepts_train.npy", train_pred)
        np.save(out_dir / "predicted_concepts_val.npy", val_pred)
        np.save(out_dir / "predicted_concepts_test.npy", test_pred)

        np.save(out_dir / "gold_concepts_train.npy", train_true)
        np.save(out_dir / "gold_concepts_val.npy", val_true)
        np.save(out_dir / "gold_concepts_test.npy", test_true)

        # Keep phase-2 compatible CSVs
        train_out = pd.DataFrame({"row_idx": train_df["__row_idx__"].values, "true_label": train_df["__label_id__"].astype(str).values})
        val_out = pd.DataFrame({"row_idx": val_df["__row_idx__"].values, "true_label": val_df["__label_id__"].astype(str).values})
        test_out = pd.DataFrame({"row_idx": test_df["__row_idx__"].values, "true_label": test_df["__label_id__"].astype(str).values})
        train_out.to_csv(out_dir / "predictions_train.csv", index=False)
        val_out.to_csv(out_dir / "predictions_val.csv", index=False)
        test_out.to_csv(out_dir / "predictions_test.csv", index=False)

        # Save metrics
        with open(out_dir / "phase1_metrics_train.json", "w") as f:
            json.dump(train_metrics, f, indent=2)
        with open(out_dir / "phase1_metrics_val.json", "w") as f:
            json.dump(val_metrics, f, indent=2)
        with open(out_dir / "phase1_metrics_test.json", "w") as f:
            json.dump(test_metrics, f, indent=2)
        with open(out_dir / "phase1_training_history.json", "w") as f:
            json.dump(history, f, indent=2)

        with open(out_dir / "label_mapping.json", "w") as f:
            json.dump({"classes": label_encoder.classes_.tolist()}, f, indent=2)

        with open(out_dir / "data_metadata.json", "w") as f:
            json.dump({
                "concept_cols": concept_cols,
                "text_col": args.text_col,
                "label_col": args.label_col,
                "num_concepts": len(concept_cols),
                "num_classes": len(label_encoder.classes_),
            }, f, indent=2)

        with open(out_dir / "phase1_run_config.json", "w") as f:
            json.dump(vars(args), f, indent=2)

        unwrapped = accelerator.unwrap_model(model)
        tokenizer.save_pretrained(out_dir / "phase1_tokenizer")
        if hasattr(unwrapped.backbone, "save_pretrained"):
            unwrapped.backbone.save_pretrained(out_dir / "phase1_lora_adapter")
        torch.save(unwrapped.concept_head.state_dict(), out_dir / "phase1_concept_head_final.pt")
        if best_state is not None:
            torch.save(best_state, out_dir / "phase1_concept_head_best.pt")

        print("Phase 1 finished.")
        print("Saved outputs to:", out_dir)
        print("Final test concept MSE:", test_metrics["concept_mse"])
        print("Final test concept MAE:", test_metrics["concept_mae"])


if __name__ == "__main__":
    main()
