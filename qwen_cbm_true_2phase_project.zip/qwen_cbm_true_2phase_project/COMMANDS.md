# Commands

## Phase 1 (true concept-only training)

```bash
conda activate sft
cd /mnt/disk1/wbjtu/tzbjtu/somental/qwen_cbm_true_2phase

CUDA_VISIBLE_DEVICES=0,1,2,3 accelerate launch \
  --num_processes 4 \
  --mixed_precision bf16 \
  phase1_train_concepts.py \
  --csv_path /mnt/disk1/wbjtu/tzbjtu/somental/data/rsd15_evidence_aware_concepts72_cleaned.csv \
  --text_col text \
  --label_col sentiment \
  --output_dir /mnt/disk1/wbjtu/tzbjtu/somental/qwen_cbm_true_2phase/outputs/phase1_run1 \
  --model_name_or_path /mnt/disk1/wbjtu/tzbjtu/somental/models/Qwen3.5-9B \
  --load_in_4bit \
  --bnb_4bit_use_double_quant \
  --gradient_checkpointing \
  --pooling mean \
  --concept_head_type linear \
  --num_epochs 3 \
  --train_batch_size 1 \
  --eval_batch_size 2 \
  --gradient_accumulation_steps 16 \
  --lr_lora 2e-4 \
  --lr_heads 2e-4 \
  --weight_decay 0.01 \
  --max_length 512 \
  --lora_r 16 \
  --lora_alpha 32 \
  --lora_dropout 0.05
```

## Phase 2 (post-hoc linear head)

```bash
conda activate sft
cd /mnt/disk1/wbjtu/tzbjtu/somental/qwen_cbm_true_2phase

python phase2_run_logreg_trials.py \
  --run_dir /mnt/disk1/wbjtu/tzbjtu/somental/qwen_cbm_true_2phase/outputs/phase1_run1 \
  --output_dir /mnt/disk1/wbjtu/tzbjtu/somental/qwen_cbm_true_2phase/outputs/phase1_run1/logreg_trials \
  --manual_class_weights '{"Indicator":1.0,"Ideation":0.9,"Behavior":1.8,"Attempt":3.0}'
```
